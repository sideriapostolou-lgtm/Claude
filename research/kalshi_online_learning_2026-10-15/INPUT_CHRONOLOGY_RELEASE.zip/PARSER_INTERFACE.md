# Offline parser interface (fixed first full-window declaration)

Frozen parser: `audit_capture.py`, SHA256
`0cf1647314077009703f3248e21f97312df512f789ab58cff91bf7abae1532a3`.
V2 fixes only the exact-source plaintext feed-gap warning format. Syntax and Ruff
exit0 receipts and source/dependency identities are saved separately. Independent
exact-byte V2 source-format review accepted this hash; final raw-data review is separate. The fixed originals have now been audited offline;
see `AUDIT-20261015T161850913689Z.json` and `PARSER-v2-comparison.json`.

After16:17UTC and root has saved originals:

```sh
/workspace/shared/nightcrawler-venv/bin/python /workspace/shared/kalshi-chronology-release-20261015/audit_capture.py --input-dir /workspace/shared/kalshi-chronology-release-20261015
```

Input files are `CAPTURE-*.json`, including arbitrary split suffixes. Each has
`observedAt` (ISO timestamp at/after requested end), `query` (exact declaration
arguments), and `result` (untouched Railway tool result with structuredContent).
The exact quoted declaration filter determines the event family, not the filename.
The parser preserves raw bytes, validates original logger/event and scopes, and
only analyzes uncapped responses. Capped parents and incomplete child coverage
remain explicit. Failure produces a unique `AUDIT-<timestamp>-FAILURE.json`
and exit1; successful parsing produces a unique `AUDIT-<timestamp>.json` and
exit0. Exit0 is not a claim of complete source coverage or a satisfied gate.
No path overwrites any original, earlier audit, gate or declaration.

Gate input is existing root-owned `CAPTURE_GATE.json`. The explicit
`root_verified_readiness_before_window_start:false` remains a failed declaration
gate regardless of healthy earlier original readiness. Exact source/deployment,
deployment_success_at, original_readiness_log_timestamp, original_account_live_ready,
root_checked_at, that timeliness Boolean, ticker_metadata_verified and optional
`window:{ticker,start,end}` are checked separately. No old gate history is reset.
Actual fixed-window accounting can still be reported with the failed gate stated.

Completion marker content schemas (root-owned):

```json
{
  "source_commit": "153a12214f8763b9bf9382697fe6d6810ab04860",
  "deployment_id": "e641cdf8-f9e1-43b2-9309-56fd70827d25",
  "fixed_start": "2026-10-15T16:00:00Z",
  "fixed_end": "2026-10-15T16:15:00Z",
  "fixed_tail": "2026-10-15T16:17:00Z"
}
```

`CAPTURE_COMPLETE.json` adds actual `completed_at` at/after16:17 and
`families_completed` equal the14declared names: order,fill,settlement,cancel,reject,
timing,feed-timing,feed-gap,reconcile,boundary-status,learning-forecast,
learning-scored,learning-unknown,learning-status. These identify completed query
attempts, not a promise of uncapped/error-free venue data; query checks are separate.
`CAPTURE_STOPPED.json` adds actual `stopped_at` at/after16:17,
`collector_running:false` and `query_tail_extended:false`.
Presence alone cannot satisfy completion. Missing/invalid markers stay explicit.

Reports use exact Decimal strings. Settlement arithmetic, global audit flags,
query coverage, failed declaration gate, missing data, role/kind accounting,
request→reply cancel timing and unconfirmed terminal state remain separate.
Accepted source ages exclude not-sent/rejected intents. Sampled diagnostics split
reader identity, event, receipt status and measured wall intervals. Learning
originals remain separate from money. No venue-completeness, cash, simulated-fill,
alternate-policy or profitability inference is made.

Only static checks were run before the tail. Initial lint findings and a safely
failed intermediate-hash assertion are retained, with resolutions. Exclude
`__pycache__/` from an evidence archive; bytecode is not an original receipt.

## V2 source-format correction

V1 parser, manifest and interface are preserved under `_v1_preserved` names;
`AUDIT-20261015T161724972248Z.json` retains its78original flags. Source commit153a
`speeddesk_kalshi_ws.py:373` logs feed gaps as anchored plaintext reason/reader
identity fields, not JSON. V2 recognizes only that bounded exact field shape.
All78valid warnings now count as publication-only originals:74fixed-window
publications and4tail publications. Reader identity/session and literal reasons
are retained. Embedded age text is not converted into a measured interval or a
new numeric latency sample. Other malformed JSON still produces explicit flags.
All14raw hashes and financial/gate/latency fields match V1 exactly.
The strict pre-window root verification gate remains false; no waiver is applied.
Two isolated synthetic malformed-input checks are test evidence only, not financial
observations, and their temporary fixtures were deleted. No new query occurred.
