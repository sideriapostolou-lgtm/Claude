# Fixed first full-window audit declaration

Declared source `153a12214f8763b9bf9382697fe6d6810ab04860`, deployment
`e641cdf8-f9e1-43b2-9309-56fd70827d25`. Assignment reported BUILDING;
root must verify exact SUCCESS/startup readiness. This worker made no network,
production, trading, financial control or source change.

The fixed cohort is **October15,9:00–9:15AM PDT (16:00–16:15UTC)**, with
publication tail **9:17AM PDT (16:17UTC)**. Expected exact ticker is
`KXBTC15M-26OCT151215-15`, subject to original start/end metadata validation.
Startup windows and next-window16:15–16:17 activity stay outside trial P&L.
If deployment readiness misses16:00, report the limitation; do not move bounds.

`CAPTURE_DECLARATION.json` contains all exact quoted Railway filters and scoped
query parameters: nine existing event families, optionally original live status
and four learner events. Query once retrospectively after the fixed tail; reuse
already saved originals. Retain capped500-row parents, split with depth/span
limits, preserve failures, and stop rather than extending the tail.

Reuse the previous reviewed `audit.py` and `timing_audit.py` offline, adapting
their old hardcoded deployment, tickers, two-window bounds, completion assumptions
and output path. Do **not** execute the old timer/collector. The financial parser
already handles Decimal actual costs/fees, fee-inclusive locked/directional
allocation, durable-intent/ack/fill joins, orphan/conflict checks and unknowns.
Add cancel timing summaries: its prior output counted states but did not quantify
cancel latency. Use `decision_to_ack_ms`/`send_to_ack_ms`; a cancel reply or404
retains reservation until reconciliation and is not a terminal receipt.

Validate original logger **and exact event**, deployment/service/environment,
isError, timestamp bounds, duplicates and conflicts before accounting. A settled
zero needs affirmative original settlement and consistent joins/counters; missing
logs stay UNKNOWN. Preserve per-side inventory, role/kind, fees, pair credit versus
net/gross payout, leftover risk and all source/join/cap errors. Boundary cumulative
counters are cross-checks; startup/next-partial changes cannot be silently included
in trial P&L or treated as account cash reconciliation.

Keep sampled timing diagnostics separate by reader identity and actual wall
interval classification; rejected-source coverage, overflow and omitted records
remain explicit. Learner forecast/scored/unknown/status events are observe-only
and separate from real P&L; a missing official label at16:17 stays pending. No
synthetic profitability, source-completeness, counterfactual or latency-causation
claim follows from this one window.

Parser/source hash references are saved separately. Root owns collection and
any final report. This declaration starts no collector or timer.
