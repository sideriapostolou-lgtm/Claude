"""Bounded offline original-log audit. No clients, networking, accounts, or source edits.

Run only after fixed tail and CAPTURE originals arrive. Decimal numbers serialize
as exact strings. Gate metadata is an explicit root attestation, not new evidence.
"""
from __future__ import annotations

import argparse
import calendar
import hashlib
import json
import math
import re
import statistics
from collections import Counter, defaultdict
from datetime import datetime, timezone
from decimal import Decimal as D
from pathlib import Path
from typing import Any

DECLARATION_SHA = '47187813df734a82224eb916c7590c5fdf8f26fb2f0dc688b943d27a65b4b4a5'
MAX_FILES, MAX_FILE_BYTES, MAX_TOTAL_BYTES = 512, 16 * 1024**2, 256 * 1024**2
RX = re.compile(r'^\S+ (?:INFO|WARNING|ERROR) (?P<logger>nightcrawler\.[\w.]+): (?P<event>[\w]+) (?P<body>.*)$')
ISO = re.compile(r'^(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d)(?:\.(\d+))?(Z|[+-]\d\d:\d\d)$')
TOL = D('0.0000001')


def stamp(value: str) -> D:
    m = ISO.fullmatch(value)
    if not m:
        raise ValueError('invalid_timestamp')
    dt = datetime.fromisoformat(m[1] + m[3].replace('Z', '+00:00')).astimezone(timezone.utc)
    return D(calendar.timegm(dt.utctimetuple())) + (D('0.' + m[2]) if m[2] else D(0))


def number(value: Any) -> D:
    if isinstance(value, bool) or not isinstance(value, (int, float, D)):
        raise TypeError('not_numeric')
    result = D(str(value))
    if not result.is_finite():
        raise ValueError('not_finite')
    return result


def quant(values: list[D]) -> dict[str, Any]:
    values = sorted(values)
    return {'n': len(values), 'median': statistics.median(values) if values else None,
            'p95_nearest_rank': values[max(0, math.ceil(.95 * len(values)) - 1)] if values else None,
            'max': max(values) if values else None}


def load(path: Path) -> Any:
    return json.loads(path.read_text(), parse_float=D,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite_json')))


def digest(path: Path) -> dict[str, Any]:
    return {'file': path.name, 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def interval_class(a: D | None, b: D | None, start: D, end: D) -> str:
    if a is None or b is None or b < a:
        return 'unknown_wall_interval'
    if start <= a <= b <= end:
        return 'fixed_window_contained'
    if b < start or a >= end:
        return 'outside_fixed_window_or_tail'
    return 'boundary_covering'


def run(directory: Path, declaration: dict[str, Any]) -> dict[str, Any]:
    fixed = declaration['fixed_window']
    start, end, tail = (stamp(fixed[k]) for k in ('start', 'end', 'publication_tail'))
    ticker = fixed['expected_ticker']
    specs = {q['family']: q for q in declaration['queries'] + declaration['optional_queries']}
    filters = {q['filter']: family for family, q in specs.items()}
    errors: list[dict[str, Any]] = []
    flags: list[dict[str, Any]] = []
    queries: list[dict[str, Any]] = []
    rows_by_family: dict[str, list[dict[str, Any]]] = defaultdict(list)
    covered: dict[str, list[tuple[D, D]]] = defaultdict(list)
    capped: list[dict[str, Any]] = []
    duplicate_rows: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    paths = sorted(directory.glob('CAPTURE-*.json'))
    if not paths:
        raise ValueError('no_capture_originals')
    if len(paths) > MAX_FILES or sum(p.stat().st_size for p in paths) > MAX_TOTAL_BYTES:
        raise ValueError('input_capacity_exceeded')
    for path in paths:
        identity = digest(path)
        entry: dict[str, Any] = {**identity, 'used': False}
        queries.append(entry)
        if identity['bytes'] > MAX_FILE_BYTES:
            errors.append({'file': path.name, 'reason': 'file_capacity_exceeded'})
            continue
        try:
            wrapper = load(path)
            q, result = wrapper['query'], wrapper['result']
            family = filters.get(q.get('filter'))
            if family is None:
                raise ValueError('undeclared_filter')
            entry['family'] = family
            expected = specs[family]
            if any(q.get(k) != expected[k] for k in ('projectId', 'deploymentId', 'environmentId', 'limit', 'types')):
                raise ValueError('query_scope_mismatch')
            a, b = stamp(q['startDate']), stamp(q['endDate'])
            if not start <= a < b <= tail:
                raise ValueError('query_time_mismatch')
            if stamp(wrapper['observedAt']) < b:
                raise ValueError('query_observed_before_requested_end')
            s = result.get('structuredContent')
            if result.get('isError') or not isinstance(s, dict):
                raise ValueError('tool_error_or_missing_structured_content')
            if (s.get('scope') != 'deployment' or s.get('deploymentId') != declaration['deployment_id']
                    or s.get('serviceId') != declaration['expected_service_id']
                    or s.get('environmentId') != expected['environmentId'] or s.get('status') != 'SUCCESS'):
                raise ValueError('response_scope_or_status_mismatch')
            rows = s.get('deploy')
            if not isinstance(rows, list):
                raise TypeError('missing_deploy_rows')
            entry.update(start=q['startDate'], end=q['endDate'], row_count=len(rows), capped=len(rows) >= 500)
            if len(rows) >= 500:
                capped.append({'file': path.name, 'family': family, 'start': a, 'end': b})
                continue  # original parent retained; only uncapped children contribute
            covered[family].append((a, b))
            entry['used'] = True
            phrase = json.loads(expected['filter'])
            logger, event = phrase.split(': ', 1)
            accepted_publications: list[D] = []
            for index, row in enumerate(rows):
                ref = {'file': path.name, 'row': index}
                try:
                    publication = stamp(row['timestamp'])
                    if not a <= publication <= b:
                        raise ValueError('row_outside_query')
                    match = RX.fullmatch(row['message'])
                    if not match or match['logger'] != logger or match['event'] != event:
                        raise ValueError('unexpected_original_signature')
                    payload = json.loads(match['body'], parse_float=D,
                                         parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite_json')))
                    if not isinstance(payload, dict):
                        raise TypeError('nonobject_payload')
                    accepted_publications.append(publication)
                    key = (row['timestamp'], row['message'])
                    if key in seen:
                        duplicate_rows.append(ref)
                        continue
                    seen.add(key)
                    rows_by_family[family].append({'data': payload, 'publication': row['timestamp'], 'ref': ref})
                except (ValueError, TypeError, KeyError) as exc:
                    # Fixed code/class only, never arbitrary exception/payload text.
                    flags.append({**ref, 'reason': str(exc) if type(exc) in (ValueError, TypeError) and str(exc) in {
                        'row_outside_query', 'unexpected_original_signature', 'nonfinite_json',
                        'nonobject_payload'} else 'malformed_original_row'})
            entry['accepted_original_publication_epoch_first'] = min(accepted_publications, default=None)
            entry['accepted_original_publication_epoch_last'] = max(accepted_publications, default=None)
        except (ValueError, TypeError, KeyError, OSError) as exc:
            allowed = {'undeclared_filter', 'query_scope_mismatch', 'query_time_mismatch',
                       'tool_error_or_missing_structured_content', 'response_scope_or_status_mismatch',
                       'missing_deploy_rows', 'query_observed_before_requested_end'}
            errors.append({'file': path.name, 'reason': str(exc) if type(exc) in (ValueError, TypeError) and str(exc) in allowed
                           else 'malformed_query_wrapper'})

    def spans(family: str, a: D, b: D) -> bool:
        cursor = a
        for lo, hi in sorted(covered[family]):
            if lo > cursor:
                return False
            cursor = max(cursor, hi)
            if cursor >= b:
                return True
        return False

    unresolved_caps = [c for c in capped if not spans(c['family'], c['start'], c['end'])]
    coverage = {family: {'queried': any(q.get('family') == family for q in queries),
                         'uncapped_full_query_interval': spans(family, start, tail),
                         'original_rows': len(rows_by_family[family])} for family in specs}
    conflicts: list[dict[str, Any]] = []
    logical_duplicates: list[dict[str, Any]] = []

    def indexed(family: str, key: str, predicate: Any = None) -> dict[str, dict[str, Any]]:
        result: dict[str, dict[str, Any]] = {}
        for item in rows_by_family[family]:
            d = item['data']
            if predicate and not predicate(d):
                continue
            ident = d.get(key)
            if not isinstance(ident, str) or not ident:
                flags.append({**item['ref'], 'reason': 'missing_logical_key', 'key': key})
                continue
            if ident in result:
                target = logical_duplicates if result[ident]['data'] == d else conflicts
                target.append({'family': family, 'key': ident, 'first': result[ident]['ref'], 'other': item['ref']})
                continue
            result[ident] = item
        return result

    intents = indexed('order', 'client_order_id', lambda d: str(d.get('state', '')).startswith('durable intent'))
    acks = indexed('order', 'client_order_id', lambda d: str(d.get('state', '')).startswith('accepted;'))
    not_sent = indexed('order', 'client_order_id', lambda d: str(d.get('state', '')).startswith('not sent;'))
    fills = indexed('fill', 'fill_id')
    settlements = indexed('settlement', 'window')
    rejected = {x['data'].get('client_order_id') for x in rows_by_family['reject']}
    ack_errors: list[dict[str, Any]] = []
    for cid, item in acks.items():
        ack, intent = item['data'], intents.get(cid, {}).get('data')
        if intent is None or intent.get('window') != ack.get('window') or not ack.get('order_id'):
            ack_errors.append({'client_order_id': cid, 'ref': item['ref'],
                               'reason': 'orphan_ack_or_window_order_id_mismatch'})
        elif (number(ack['at']) < number(intent['at'])):
            ack_errors.append({'client_order_id': cid, 'ref': item['ref'], 'reason': 'ack_before_intent'})
    selected_intents = {cid: i['data'] for cid, i in intents.items() if i['data'].get('window') == ticker}
    selected_acks = {cid: i['data'] for cid, i in acks.items() if i['data'].get('window') == ticker}
    lifecycle_errors: list[dict[str, Any]] = []
    for cid in intents:
        states = [name for name, population in (('accepted', acks), ('not_sent', not_sent), ('rejected', rejected)) if cid in population]
        if len(states) > 1:
            lifecycle_errors.append({'client_order_id': cid, 'reason': 'conflicting_lifecycle_outcomes', 'states': states})
    for cid, item in not_sent.items():
        intent = intents.get(cid, {}).get('data')
        if intent is None or intent.get('window') != item['data'].get('window'):
            lifecycle_errors.append({'client_order_id': cid, 'reason': 'orphan_or_mismatched_not_sent', 'ref': item['ref']})
    unassigned_rejects = 0
    for item in rows_by_family['reject']:
        d = item['data']; cid = d.get('client_order_id')
        if cid is None:
            unassigned_rejects += 1  # account/general error receipt; not invented as a rejected intent
            continue
        intent = intents.get(cid, {}).get('data')
        if intent is None or d.get('window') != intent.get('window'):
            lifecycle_errors.append({'client_order_id': cid, 'reason': 'orphan_or_mismatched_reject', 'ref': item['ref']})
    joined, join_errors, valid_fills = [], [], []
    filled_sizes: dict[str, D] = defaultdict(lambda: D(0))
    side = {s: {'shares': D(0), 'cost_usd': D(0), 'fees_usd': D(0)} for s in ('up', 'down')}
    for fid, item in fills.items():
        f = item['data']
        if f.get('window') != ticker:
            continue
        cid = f.get('client_order_id')
        intent, ack = intents.get(cid, {}).get('data'), acks.get(cid, {}).get('data')
        problems: list[str] = []
        try:
            at, size, price, fee = (number(f[k]) for k in ('at', 'size', 'price', 'fee_usd'))
            if f.get('side') not in side or size <= 0 or not D(0) <= price <= D(1):
                raise ValueError('invalid_fill_shape')
            if not start <= at <= end:
                problems.append('venue_fill_time_outside_fixed_window')
            if intent is None:
                problems.append('missing_durable_intent')
            else:
                if any(intent.get(k) != f.get(k) for k in ('window', 'side')):
                    problems.append('intent_window_or_side_mismatch')
                if number(intent['at']) > at:
                    problems.append('fill_before_intent')
                limit = number(intent['price'])
                if price > limit + TOL:
                    problems.append('fill_above_buy_limit')
            if ack is None:
                problems.append('missing_accepted_ack')
            elif ack.get('order_id') != f.get('order_id') or ack.get('window') != f.get('window'):
                problems.append('ack_order_or_window_mismatch')
            if type(f.get('is_taker')) is not bool:
                problems.append('maker_taker_role_unknown')
            h = side[f['side']]
            h['shares'] += size; h['cost_usd'] += size * price; h['fees_usd'] += fee
            valid_fills.append(f)
            filled_sizes[cid] += size
        except (ValueError, KeyError, TypeError):
            problems.append('malformed_fill_or_join_numeric_fields')
        joined.append({'fill': f, 'intent': intent, 'ack': ack, 'problems': problems, 'ref': item['ref']})
        if problems:
            join_errors.append({'fill_id': fid, 'problems': problems})
    for cid, intent in selected_intents.items():
        if not start <= number(intent['at']) < end:
            flags.append({'client_order_id': cid, 'reason': 'intent_time_outside_window'})
        if filled_sizes[cid] > number(intent['size']) + TOL:
            join_errors.append({'client_order_id': cid, 'problems': ['fills_exceed_intended_size']})
    order_ids: dict[str, str] = {}
    for cid, ack in selected_acks.items():
        oid = ack.get('order_id')
        if oid in order_ids and order_ids[oid] != cid:
            ack_errors.append({'client_order_id': cid, 'reason': 'order_id_mapped_to_multiple_clients'})
        order_ids[oid] = cid

    cost = sum((h['cost_usd'] for h in side.values()), D(0))
    fees = sum((h['fees_usd'] for h in side.values()), D(0))
    pairs = min(h['shares'] for h in side.values())
    locked = pairs * (1 - sum(((h['cost_usd'] + h['fees_usd']) / h['shares']
                              if h['shares'] else D(0) for h in side.values()), D(0)))
    settled = settlements.get(ticker, {}).get('data')
    arithmetic, mismatches = None, {}
    if settled:
        try:
            if type(settled['up_wins']) is not bool or number(settled['at']) < end:
                raise ValueError('invalid_settlement')
            if not isinstance(settled.get('settlement_id'), str) or not settled['settlement_id']:
                raise ValueError('invalid_settlement_id')
            payout = side['up' if settled['up_wins'] else 'down']['shares']
            pnl = payout - cost - fees
            arithmetic = {'up_shares': side['up']['shares'], 'down_shares': side['down']['shares'],
                          'cost_usd': cost, 'fee_usd': fees, 'paired_credit_usd': pairs,
                          'net_payout_usd': payout - pairs, 'payout_usd': payout,
                          'pnl_usd': pnl, 'locked_usd': locked, 'direction_usd': pnl - locked}
            for key, computed in arithmetic.items():
                if abs(number(settled[key]) - computed) > TOL:
                    mismatches[key] = {'reported': settled[key], 'computed': computed}
        except (ValueError, KeyError, TypeError):
            flags.append({'reason': 'malformed_settlement'})
            arithmetic = None
    groups: dict[str, dict[str, Any]] = {}
    for name, predicate in [('maker', lambda f: f.get('is_taker') is False),
                            ('taker', lambda f: f.get('is_taker') is True),
                            ('role_unknown', lambda f: type(f.get('is_taker')) is not bool),
                            ('lock', lambda f: selected_intents.get(f.get('client_order_id'), {}).get('kind') == 'lock'),
                            ('nonlock_known', lambda f: f.get('client_order_id') in selected_intents and
                             selected_intents[f['client_order_id']].get('kind') != 'lock')]:
        subset = [f for f in valid_fills if predicate(f)]
        g = {'fill_count': len(subset), 'shares': sum((number(f['size']) for f in subset), D(0)),
             'cost_usd': sum((number(f['size']) * number(f['price']) for f in subset), D(0)),
             'fees_usd': sum((number(f['fee_usd']) for f in subset), D(0))}
        if arithmetic is not None:
            g['actual_fill_signed_settlement_contribution_usd'] = sum((
                (number(f['size']) if (f['side'] == 'up') is settled['up_wins'] else D(0))
                - number(f['size']) * number(f['price']) - number(f['fee_usd']) for f in subset), D(0))
        groups[name] = g

    cancel_rows = [i for i in rows_by_family['cancel'] if i['data'].get('window') == ticker
                   or i['data'].get('client_order_id') in selected_intents]
    cancel_join_errors = []
    cancel_groups: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
    for item in cancel_rows:
        d = item['data']; cid, oid = d.get('client_order_id'), d.get('order_id')
        joined_cid = cid if cid is not None else order_ids.get(oid)
        intent, ack = selected_intents.get(joined_cid), selected_acks.get(joined_cid)
        if (intent is None or ack is None or oid != ack.get('order_id')
                or (d.get('window') is not None and d.get('window') != ticker)):
            cancel_join_errors.append({**item['ref'], 'reason': 'cancel_intent_ack_order_window_join_unknown_or_mismatch'})
        try:
            at = number(d['at'])
            population = ('fixed_window' if start <= at < end else
                          'same_ticker_tail' if end <= at <= tail else 'outside_fixed_event_interval')
            if population == 'outside_fixed_event_interval':
                flags.append({**item['ref'], 'reason': 'cancel_event_time_outside_fixed_interval'})
        except (KeyError, ValueError, TypeError):
            population = 'unknown_event_time'
            flags.append({**item['ref'], 'reason': 'cancel_event_time_unknown'})
        cancel_groups[(str(d.get('state', 'missing')), str(d.get('reason', 'missing')), population)].append(d)
    cancel_summary = []
    for (state, reason, population), values in sorted(cancel_groups.items()):
        metrics: dict[str, Any] = {}
        for metric in ('decision_to_ack_ms', 'send_to_ack_ms'):
            observed, missing = [], 0
            for d in values:
                try:
                    value = number((d.get('timing') or {})[metric])
                    if value < 0:
                        raise ValueError('negative_latency')
                    observed.append(value)
                except (KeyError, TypeError, ValueError):
                    missing += 1
            metrics[metric] = {**quant(observed), 'missing_or_invalid': missing}
        cancel_summary.append({'state': state, 'reason': reason, 'event_time_population': population,
                               'rows': len(values), 'metrics': metrics})
    latency, ack_missing, locks = [], 0, 0
    source_ages: dict[str, list[D]] = defaultdict(list)
    age_counts: Counter[str] = Counter()
    for cid, ack in selected_acks.items():
        if selected_intents.get(cid, {}).get('kind') == 'lock':
            locks += 1; continue
        timing = ack.get('timing') or {}
        try:
            if timing.get('metric') != 'decision_to_ack' or timing.get('status') != 'ok':
                raise ValueError('inapplicable')
            value = number(timing['value_ms'])
            if value < 0:
                raise ValueError('negative')
            latency.append(value)
        except (ValueError, KeyError, TypeError):
            ack_missing += 1
    for cid, intent in selected_intents.items():
        if cid not in selected_acks:
            continue
        for timing in intent.get('timing') or []:
            if not isinstance(timing, dict):
                flags.append({'reason': 'malformed_source_age_timing'}); continue
            metric, status = str(timing.get('metric')), str(timing.get('status'))
            age_counts[metric + ':' + status] += 1
            if status == 'ok':
                try:
                    source_ages[metric].append(number(timing['value_ms']))
                except (ValueError, KeyError, TypeError):
                    flags.append({'reason': 'malformed_source_age_value'})

    diagnostics: dict[str, Any] = {'scope': 'Sampled original receipts only, not full tape.',
                                  'feed_groups': [], 'reconcile_groups': []}
    feed_groups: dict[tuple[Any, ...], list[dict[str, Any]]] = defaultdict(list)
    for item in rows_by_family['feed-timing']:
        d = item['data']; reader, receipt = d.get('reader') or {}, d.get('receipt') or {}
        try:
            a = number(receipt['accepted_wall']) if receipt.get('accepted_wall') is not None else None
            b = number(receipt['received_wall']) if receipt.get('received_wall') is not None else None
        except (ValueError, TypeError):
            a = b = None
        identity = tuple(reader.get(k) for k in ('kind', 'instance', 'process')) + (d.get('session'),)
        cls = interval_class(a, b, start, end)
        feed_groups[identity + (cls, str(d.get('event')), str(receipt.get('status')))].append(d)
    for key, values in feed_groups.items():
        known = []
        for d in values:
            receipt = d.get('receipt') or {}
            if receipt.get('status') == 'known':
                try:
                    known.append(number(receipt['residence_ms']))
                except (KeyError, ValueError, TypeError):
                    flags.append({'reason': 'malformed_known_residence'})
        diagnostics['feed_groups'].append({'reader_kind_instance_process_session': key[:4], 'interval': key[4],
            'event_population': key[5], 'receipt_status_population': key[6],
            'rows': len(values), 'event_counts': dict(Counter(str(d.get('event')) for d in values)),
            'receipt_status_counts': dict(Counter(str((d.get('receipt') or {}).get('status')) for d in values)),
            'known_residence_ms': quant(known), 'event_status_populations_separate': True})
    trace_groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for item in rows_by_family['reconcile']:
        d = item['data']
        try:
            a = number(d['started_at']); b = a + number(d['elapsed_ms']) / 1000
            cls = interval_class(a, b, start, end)
            delays = []
            for read in d.get('reads', []):
                marks = read.get('marks_ms') or {}
                if marks.get('worker_completed') is not None and marks.get('coroutine_resumed') is not None:
                    c, r = number(marks['worker_completed']), number(marks['coroutine_resumed'])
                    if interval_class(a + c / 1000, a + r / 1000, start, end) == 'fixed_window_contained':
                        delays.append(r - c)
            trace_groups[cls].append({'reads': len(d.get('reads', [])), 'delays': delays,
                                     'reads_omitted': d.get('reads_omitted'), 'new_fills_omitted': d.get('new_fills_omitted')})
        except (ValueError, KeyError, TypeError):
            flags.append({**item['ref'], 'reason': 'malformed_reconcile_trace'})
    for cls, values in trace_groups.items():
        diagnostics['reconcile_groups'].append({'interval': cls, 'selected_cycles': len(values),
            'selected_reads': sum(v['reads'] for v in values),
            'contained_worker_complete_to_resume_ms': quant([x for v in values for x in v['delays']]),
            'read_omissions_values': [v['reads_omitted'] for v in values],
            'new_fill_omissions_values': [v['new_fills_omitted'] for v in values]})
    diagnostics['feed_gap_publication_counts'] = dict(Counter(
        'fixed_window' if start <= stamp(i['publication']) < end else 'tail_next_partial'
        for i in rows_by_family['feed-gap']))
    diagnostics['limits'] = ['Publication is not measured interval containment.', 'Quiet/missing/overflow/source-retention coverage unknown.',
        'Known status+gap pooled statistics are not rejected-gap-only statistics.',
        'Accepted intent ages exclude rejected-source traffic; resting wait is not ack latency.']

    statuses = []
    for item in rows_by_family['boundary-status']:
        d = item['data']
        statuses.append({'publication': item['publication'], **{k: d.get(k) for k in (
            'as_of', 'mode', 'authenticated', 'trading_now', 'total_halted', 'day_stop_latched',
            'cleanup_pending', 'open_orders', 'positions', 'reserved_usd', 'open_risk_usd',
            'total', 'today', 'caps')}})  # never recurse latest_events/reports/practice_twin
    gate_path = directory / 'CAPTURE_GATE.json'
    gate: dict[str, Any] = {'present': gate_path.exists(), 'declaration_gate_satisfied': False,
                            'basis': 'Root-provided attestation; original source proof remains separate.'}
    if gate_path.exists():
        try:
            g = load(gate_path)
            identity_ok = (g['source_commit'] == declaration['source_commit']
                           and g['deployment_id'] == declaration['deployment_id'])
            # Actual original readiness and timely root verification are distinct.
            # An explicit false flag MUST win over retrospectively healthy evidence.
            timely = (g.get('root_verified_readiness_before_window_start') is True
                      and stamp(g['root_checked_at']) < start)
            original_ready = (g.get('original_account_live_ready') is True
                              and stamp(g['original_readiness_log_timestamp']) < start)
            success_before_start = stamp(g['deployment_success_at']) < start
            metadata_ok = (g.get('ticker_metadata_verified') is True
                           and g.get('window', {}).get('ticker') == ticker
                           and stamp(g['window']['start']) == start and stamp(g['window']['end']) == end)
            gate.update(identity_matches=identity_ok, root_verified_before_start=timely,
                        retrospective_original_prestart_ready=original_ready,
                        deployment_success_before_start=success_before_start,
                        ticker_metadata_verified=metadata_ok,
                        declaration_gate_satisfied=all((identity_ok, timely, original_ready,
                                                       success_before_start, metadata_ok)),
                        explicit_root_timeliness_flag=g.get('root_verified_readiness_before_window_start'),
                        root_checked_at=g.get('root_checked_at'),
                        original_readiness_log_timestamp=g.get('original_readiness_log_timestamp'),
                        file=digest(gate_path))
        except (KeyError, ValueError, TypeError, OSError):
            gate['malformed_or_incomplete_gate'] = True
    markers = {}
    for name, clock_key in (('CAPTURE_COMPLETE.json', 'completed_at'), ('CAPTURE_STOPPED.json', 'stopped_at')):
        path = directory / name
        if not path.is_file():
            continue
        marker: dict[str, Any] = {**digest(path), 'valid': False}
        markers[name] = marker
        try:
            m = load(path)
            identity_ok = (m['source_commit'] == declaration['source_commit']
                           and m['deployment_id'] == declaration['deployment_id'])
            bounds_ok = all(stamp(m[k]) == v for k, v in (
                ('fixed_start', start), ('fixed_end', end), ('fixed_tail', tail)))
            closed_ok = stamp(m[clock_key]) >= tail
            marker['valid'] = identity_ok and bounds_ok and closed_ok
            if clock_key == 'completed_at':
                marker['valid'] = marker['valid'] and set(m['families_completed']) == set(specs)
            else:
                marker['valid'] = (marker['valid'] and m.get('collector_running') is False
                                   and m.get('query_tail_extended') is False)
        except (KeyError, ValueError, TypeError, OSError):
            marker['reason'] = 'malformed_or_incomplete_marker'
    core_complete = all(coverage[q['family']]['uncapped_full_query_interval'] for q in declaration['queries'])
    unresolved_intents = [cid for cid in selected_intents if cid not in acks and cid not in not_sent and cid not in rejected]
    financial_checks_clean = arithmetic is not None and core_complete and not any((errors, flags, unresolved_caps, conflicts, ack_errors, join_errors, mismatches, unresolved_intents, lifecycle_errors, cancel_join_errors))
    clean = financial_checks_clean and gate['declaration_gate_satisfied'] and len(markers) == 2 and all(m['valid'] for m in markers.values())
    accounting_status = ('UNKNOWN missing/malformed official settlement' if arithmetic is None else
                         'MISMATCH settlement arithmetic' if mismatches else 'settlement arithmetic agrees; coverage separate')
    return {'schema': 1, 'source_commit_declared': declaration['source_commit'], 'deployment': declaration['deployment_id'],
        'fixed_window': fixed, 'declaration_sha256': DECLARATION_SHA, 'queries': queries, 'coverage': coverage,
        'query_errors': errors, 'row_or_time_flags': flags, 'capped_parents': capped, 'unresolved_caps': unresolved_caps,
        'identical_original_duplicates': duplicate_rows, 'logical_duplicates': logical_duplicates, 'conflicts': conflicts,
        'ack_errors': ack_errors, 'lifecycle_errors': lifecycle_errors,
        'general_rejects_without_client_id': unassigned_rejects, 'fill_join_errors': join_errors, 'startup_gate': gate,
        'collector_markers': markers, 'core_query_coverage_complete': core_complete, 'source_completeness_certified': False,
        'all_reported_audit_checks_clean': clean, 'financial_checks_clean_separate_from_declaration_gate': financial_checks_clean,
        'capture_declaration_status': 'satisfied' if gate['declaration_gate_satisfied'] else 'FAILED_OR_UNVERIFIED; fixed-window actual accounting remains separate',
        'status': accounting_status,
        'settled_accounting_sign': ('unknown' if arithmetic is None or mismatches else
            'loss' if arithmetic['pnl_usd'] < 0 else 'profit' if arithmetic['pnl_usd'] > 0 else 'zero'),
        'ticker': ticker, 'fill_count': len(joined), 'numeric_fill_count': len(valid_fills),
        'distinct_filled_order_ids': len({f.get('order_id') for f in valid_fills}),
        'intents': len(selected_intents), 'accepted': len(selected_acks),
        'not_sent': sum(cid in not_sent for cid in selected_intents),
        'rejected_intents': sum(cid in rejected for cid in selected_intents),
        'unresolved_intents': unresolved_intents,
        'by_side': side, 'paired_shares': pairs,
        'leftover_shares': {s: h['shares'] - pairs for s, h in side.items()},
        'settlement_original': settled, 'recomputed': arithmetic, 'settlement_mismatches': mismatches,
        'roles_and_kinds_overlapping_groups': groups,
        'decision_to_ack_ms': {**quant(latency), 'missing_or_invalid': ack_missing, 'lock_not_applicable': locks},
        'accepted_intent_source_age_denominator': len(set(selected_intents) & set(selected_acks)),
        'accepted_intent_source_age_status_counts': dict(age_counts),
        'accepted_intent_source_ages_ms': {k: quant(v) for k, v in source_ages.items()},
        'cancel_rows': len(cancel_rows), 'cancel_groups': cancel_summary, 'cancel_join_errors': cancel_join_errors,
        'cancel_terminal_confirmation': 'Not established by request/reply receipt; reservations retained until reconcile.',
        'joined_fills': joined, 'excluded_fill_tickers': dict(Counter(f['data'].get('window') for f in fills.values()
                                                                 if f['data'].get('window') != ticker)),
        'diagnostics': diagnostics, 'boundary_status_counters': statuses,
        'learning_separate_observe_only': {family: rows_by_family[family] for family in specs if family.startswith('learning-')},
        'limitations': ['No cash/current-balance inference or alternate-policy profit.',
            'Actual-fill signed contribution is static accounting, not simulated fills or a policy backtest.',
            'Missing settlement, labels, families, joins, boundary counters or timing stay unknown; no tail extension.',
            'Counters include startup/next partial; no automatic attribution of cumulative deltas to trial.',
            'Markers are validated for exact identity/bounds/closed-time; they do not certify complete venue tape.']}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    directory = args.input_dir.resolve()
    label = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    output = directory / ('AUDIT-' + label + '.json')
    try:
        declaration_path = Path(__file__).resolve().parent / 'CAPTURE_DECLARATION.json'
        if hashlib.sha256(declaration_path.read_bytes()).hexdigest() != DECLARATION_SHA:
            raise ValueError('declaration_hash_mismatch')
        declaration = load(declaration_path)
        if D(str(datetime.now(timezone.utc).timestamp())) < stamp(declaration['fixed_window']['publication_tail']):
            raise ValueError('fixed_tail_not_closed_do_not_run')
        result = run(directory, declaration)
        result['parser_identity'] = digest(Path(__file__))
        result['audit_created_at'] = datetime.now(timezone.utc).isoformat()
        with output.open('x') as handle:
            json.dump(result, handle, indent=2, default=str, allow_nan=False)
            handle.write('\n')
        print(json.dumps({'audit_file': str(output), 'status': result['status'],
                          'clean': result['all_reported_audit_checks_clean'], 'fill_count': result['fill_count']}))
        return 0
    except Exception as exc:  # noqa: BLE001 - preserve offline failure without rewriting raw inputs
        allowed = {'declaration_hash_mismatch', 'fixed_tail_not_closed_do_not_run', 'no_capture_originals',
                   'input_capacity_exceeded'}
        reason = str(exc) if type(exc) in (ValueError, TypeError) and str(exc) in allowed else 'offline_parser_failure'
        failure = directory / ('AUDIT-' + label + '-FAILURE.json')
        with failure.open('x') as handle:
            json.dump({'status': 'FAILED; no completed audit', 'reason': reason,
                       'exception_class': type(exc).__name__, 'parser_identity': digest(Path(__file__))}, handle, indent=2)
            handle.write('\n')
        print(json.dumps({'failure_file': str(failure), 'reason': reason}))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
