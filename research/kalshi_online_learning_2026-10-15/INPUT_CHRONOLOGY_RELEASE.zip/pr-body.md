LIVE ON MERGE: touches real money; restarts existing bots and applies the owner-approved bounded Kalshi resume.

Fix the observer child’s use of untimed simulator warnings, which could reject an otherwise eligible forecast because of an old pre-start event. Preserve time-qualified gap exclusions, saved history and practice accounting. The learner remains observe-only; no live prediction, trading rule, controller, feed, fee, cap or Polymarket code changes.

The owner confirmed unchanged $10/window, $20 open, $6 daily and five-contract clip; Codex explicitly communicated a fresh $10 total-loss test budget. Only a fresh single-use resume control is planned immediately before a safe-minute merge, without an extra deployment. All historical losses and current daily loss remain. No guard removal or cap increase.

Validation: 5,695 tests passed / 14 existing skips, captured exit 0; mypy all 128 source files; Ruff both changed Python files; exact independent source/integration review. Latest base application/test trees equal the tested base. Frozen source, original failed attempts, test receipts and limitations are in research/kalshi_online_learning_2026-10-15/INPUT_CHRONOLOGY_PREPARATION.md.

After merge: verify exact Railway commit, normal Polymarket startup, applied-once resume, retained losses/caps/day stop, fresh live-account status and real/practice-separated observations. Quiet-market maker eligibility and producer-time limitations remain; no profitable-edge or actual learning-update claim.
