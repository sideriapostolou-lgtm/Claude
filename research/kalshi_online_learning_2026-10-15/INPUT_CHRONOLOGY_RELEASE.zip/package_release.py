"""Package fixed release evidence only; never execute a production operation."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib,json,re,zipfile
HERE=Path(__file__).resolve().parent
REPO=Path('/workspace/nightcrawler-feed-learning')
OUT=REPO/'research/kalshi_online_learning_2026-10-15'
REPORT='INPUT_CHRONOLOGY_RELEASE.md'
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    assert (HERE/'CAPTURE_STOPPED.json').is_file() and (HERE/'CAPTURE_COMPLETE.json').is_file()
    report=(OUT/REPORT).read_bytes()
    files=[p for p in HERE.iterdir() if p.is_file() and p.suffix in {'.json','.md','.log','.py','.patch'}
           and p.name not in {'TAKEOVER_REMAINING.md','RELEASE_DRAFT.md','PUBLISHED.json'}
           and not p.name.startswith('PACKAGE-')]
    payload={p.name:p.read_bytes() for p in sorted(files)}
    payload[REPORT]=report
    patterns=[rb'-----BEGIN[ ](?:[A-Z]+[ ])?PRIVATE[ ]KEY-----',rb'\bsk-[A-Za-z0-9_-]{20,}',rb'\bjup_[A-Za-z0-9_-]{20,}',rb'\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{25,}',rb'\bgithub_pat_[A-Za-z0-9_]{30,}']
    findings=[n for n,b in payload.items() if any(re.search(pattern,b) for pattern in patterns)]
    assert not findings,'Recognized credential-like pattern: inspect privately'
    archive=OUT/'INPUT_CHRONOLOGY_RELEASE.zip'
    assert not archive.exists(),'Never overwrite a published release archive'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,b in sorted(payload.items()):z.writestr(name,b)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and set(z.namelist())==set(payload)
        assert all(z.read(n)==b for n,b in payload.items())
    receipt={'recorded_at_pacific':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
       'source_commit':'153a12214f8763b9bf9382697fe6d6810ab04860',
       'deployment_id':'e641cdf8-f9e1-43b2-9309-56fd70827d25','archive':archive.name,
       'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'member_count':len(payload),
       'original_member_bytes_and_crc_verified':True,'recognized_credential_pattern_matches':0,
       'original_preparation_archive_unchanged':True,
       'members':[{'name':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(payload.items())]}
    (OUT/'INPUT_CHRONOLOGY_RELEASE.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({k:receipt[k] for k in ['archive','bytes','sha256','member_count']}))
if __name__=='__main__':main()
