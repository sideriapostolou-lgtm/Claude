"""Synthetic ACTUAL child-step paths; no network/I/O or production causality."""
import importlib.util,json,sys,tempfile,time,statistics
from pathlib import Path
from nightcrawler import kalshi_arena as new
from nightcrawler.speeddesk_model import Window
OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('nightcrawler._old_history_benchmark',OUT/'baseline_kalshi_arena.py')
old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
START=1792066500.
def run(kind,history,steps):
 module=old if kind=='old_source' else new
 clock=[START-100];view=module.WireView()
 view.windows=tuple(Window(f'KXBTC15M-history-{i}',START-i*900,START-i*900+900,100,venue='kalshi') for i in range(history))
 view.bitcoin_price=100;view.sigma=.001;view.bitcoin_at=clock[0]
 with tempfile.TemporaryDirectory() as temp:
  town=module.KalshiArena(module.ArenaConfig(Path(temp),population=12),lambda:view,clock=lambda:clock[0])
  if kind=='candidate_disabled':town.learning.disable('optional_learning_method_failed')
  town._save=lambda now:setattr(town,'saved_at',now)
  town.step(clock[0])
  cpu0,wall0=time.process_time(),time.perf_counter()
  for i in range(steps):
   clock[0]=START+300+i*.001;view.bitcoin_at=clock[0];town.step(clock[0])
  cpu,wall=time.process_time()-cpu0,time.perf_counter()-wall0
  state=town.state(clock[0]);raw=json.dumps(state,separators=(',',':'))
  cpu0=time.process_time()
  for _ in range(100):json.dumps(state,separators=(',',':'))
  encode_us=(time.process_time()-cpu0)*1e4
  return {'cpu_s':cpu,'wall_s':wall,'cpu_us_per_step':cpu*1e6/steps,'wall_us_per_step':wall*1e6/steps,'state_bytes':len(raw.encode()),'encode_cpu_us':encode_us}
rows=[]
for history,steps in [(9,2000),(16,2000),(4096,200)]:
 for trial in range(5):
  for kind in ('old_source','candidate_disabled','candidate_active'):
   rows.append({'history':history,'steps':steps,'trial':trial,'kind':kind,**run(kind,history,steps)})
summary=[]
for history in (9,16,4096):
 med={kind:statistics.median(r['cpu_us_per_step'] for r in rows if r['history']==history and r['kind']==kind) for kind in ('old_source','candidate_disabled','candidate_active')}
 summary.append({'history':history,'median_cpu_us_per_step':med,'active_minus_old_us':med['candidate_active']-med['old_source'],'active_minus_disabled_us':med['candidate_active']-med['candidate_disabled']})
report={'scope':'Actual KalshiArena.step, twelve residents, unchanged snapshot tuple with9/16/4096 historical/current/future window rows; fresh synthetic spot/sigma, no books/trades/orders. One due forecast then pending. Both old and candidate save replaced equally by saved_at update; CPU includes all child step work and ordinary resident evaluation.','limits':'Synthetic quiet no-I/O workload; wall/CPU noise and fixed interleave order preserved; not production latency, busy-market proof, strategy evidence or profit.4096is input capacity, not claimed typical production history. Source fingerprints computed once at construction, outside timed loop.','trial_order':['old_source','candidate_disabled','candidate_active'],'rows':rows,'summary':summary}
(OUT/'benchmark-history.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(summary,indent=2))
