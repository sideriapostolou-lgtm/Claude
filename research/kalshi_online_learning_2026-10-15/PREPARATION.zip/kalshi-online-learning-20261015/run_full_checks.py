"""Run checks on the frozen integrated candidate; retain real exit codes and exact source hashes."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
import subprocess
import time

REPO = Path('/workspace/nightcrawler-online-learning')
OUT = Path(__file__).parent
PYTHON = '/workspace/shared/nightcrawler-venv/bin/python'
FILES = [
    'src/nightcrawler/kalshi_online_learning.py', 'src/nightcrawler/kalshi_arena.py',
    'src/nightcrawler/pagestate.py', 'tests/test_kalshi_online_learning.py',
    'tests/test_kalshi_online_learning_arena.py', 'tests/test_kalshi_online_learning_page.py',
    'tests/test_kalshi_arena_page.py',
]


def hashes():
    return {name: sha256((REPO / name).read_bytes()).hexdigest() for name in FILES}


frozen = json.loads((OUT / 'integrated-seven-files-freeze.json').read_text())
before = hashes()
assert before == frozen['files'], 'candidate changed before checks'
env = os.environ.copy()
env['PYTHONPATH'] = str(REPO / 'src')
env['NIGHTCRAWLER_LIVE_TESTS'] = '0'
checks = [
    ('pytest', [PYTHON, '-m', 'pytest', '-q', '-ra']),
    ('mypy', [PYTHON, '-m', 'mypy', 'src/nightcrawler']),
    ('ruff', [PYTHON, '-m', 'ruff', 'check', *FILES]),
    ('diff-check', ['git', 'diff', '--check']),
]
result = {'started_utc': datetime.now(timezone.utc).isoformat(), 'before': before, 'checks': []}
for name, command in checks:
    print(name + ' started ' + datetime.now(timezone.utc).isoformat(), flush=True)
    started = time.monotonic()
    with (OUT / ('full-' + name + '.log')).open('w') as log:
        process = subprocess.run(command, cwd=REPO, env=env, stdout=log, stderr=subprocess.STDOUT, check=False)
    result['checks'].append({'name': name, 'command': command, 'exit_code': process.returncode,
                             'elapsed_s': time.monotonic() - started})
    (OUT / 'full-checks-progress.json').write_text(json.dumps(result, indent=2) + '\n')
    print(name + ' finished exit=' + str(process.returncode), flush=True)
    if process.returncode:
        raise SystemExit(process.returncode)
result['after'] = hashes()
result['source_unchanged'] = result['after'] == before
assert result['source_unchanged'], 'candidate changed during checks'
result['completed_utc'] = datetime.now(timezone.utc).isoformat()
result['all_passed'] = True
(OUT / 'full-checks-final.json').write_text(json.dumps(result, indent=2) + '\n')
print('all checks complete; source unchanged', flush=True)
