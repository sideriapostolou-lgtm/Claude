"""Synthetic child-only CPU/state comparison; no venue/orders or profit evidence."""
import importlib.util,json,subprocess,sys,tempfile,time,statistics
from pathlib import Path
from nightcrawler import kalshi_arena as new
from nightcrawler.kalshi_online_learning import OnlineLearning
from nightcrawler.speeddesk_model import Window
OUT=Path(__file__).resolve().parent
base=subprocess.check_output(['git','show','f0a0a9d8cab3880925a91abae6773282514e0660:src/nightcrawler/kalshi_arena.py'],text=True)
(OUT/'baseline_kalshi_arena.py').write_text(base)
spec=importlib.util.spec_from_file_location('nightcrawler._old_online_benchmark',OUT/'baseline_kalshi_arena.py')
old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
def run(module,steps):
 clock=[900.0];view=module.WireView();view.windows=(Window('KXBTC15M-bench',1000,1900,100,venue='kalshi'),);view.bitcoin_price=100;view.sigma=.001;view.bitcoin_at=900
 with tempfile.TemporaryDirectory() as temp:
  town=module.KalshiArena(module.ArenaConfig(Path(temp),population=12),lambda:view,clock=lambda:clock[0])
  town._save=lambda now:setattr(town,'saved_at',now)
  town.step(900)
  started=time.process_time()
  for i in range(steps):
   clock[0]=1300+i*.001;view.bitcoin_at=clock[0];town.step(clock[0])
  elapsed=time.process_time()-started
  state=town.state(clock[0]); size=len(json.dumps(state,separators=(',',':')).encode())
  return {'cpu_seconds':elapsed,'per_step_us':elapsed/steps*1e6,'state_bytes':size}
results={'baseline':[],'candidate':[]}
for _ in range(5):
 results['baseline'].append(run(old,5000));results['candidate'].append(run(new,5000))
learner=OnlineLearning(0)
for i in range(150):
 start=1000+i*900;w=Window(f'KXBTC15M-{i}',start,start+900,100,venue='kalshi')
 learner.discover([w],start-1);learner.advance([w],100,.001,start+300,{},start+300,{})
 learner.advance([w],100,.001,w.end,{w.slug:bool(i%2)},w.end,{})
for i in range(32):
 start=200000+i*900;learner.discover([Window(f'KXBTC15M-future-{i}',start,start+900,100,venue='kalshi')],190000)
state=learner.state();raw=json.dumps(state,separators=(',',':'));restored=OnlineLearning(190000);restored.restore(json.loads(raw),190000)
assert restored.enabled
report={'scope':'Synthetic quiet child-step CPU only; no actual production timing, data replay, network, fills, or P&L. Existing checkpoint I/O replaced equally by a timestamp update in BOTH paths. One due forecast, thereafter pending. Parent ArenaLink untouched.','steps_per_trial':5000,'trials_each':5,'results':results,'median_added_us_per_child_step':statistics.median(r['per_step_us'] for r in results['candidate'])-statistics.median(r['per_step_us'] for r in results['baseline']),'candidate_added_checkpoint_bytes_one_pending':results['candidate'][0]['state_bytes']-results['baseline'][0]['state_bytes'],'bounded_stress_state':{'admitted_pending':len(state['pending']),'recent':len(state['recent']),'labels':len(state['labels']),'bytes':len(raw.encode()),'restore_pass':restored.enabled},'limits':'CPU deltas include normal timing noise; not a latency regression guarantee. Source reads/fingerprint occur once at child construction, outside the pass loop. No new save/fsync cadence or power-failure guarantee.'}
(OUT/'benchmark.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
