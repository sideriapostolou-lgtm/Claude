"""Bounded release audit, exact original rows; does not query production."""
import hashlib
import json
import math
import re
import subprocess
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/nightcrawler-online-learning')
MERGE = '933a43d2d7cb6d6dd27b4728d50c78ce0f488ed5'
BASE = 'f0a0a9d8cab3880925a91abae6773282514e0660'
FEATURE = '6d7a123b96c8dc65ca2267542829050f999aa78a'
NEW = '458e8e54-804c-46f1-aaf4-0abab4461571'

def obj(name):
    v = json.loads((ROOT / name).read_text())
    r = v['result']
    if r.get('status') == 'fulfilled':
        r = r['value']
    assert not r.get('isError'), name
    return r['structuredContent']

def originals(name, event, logger):
    rows = []
    for r in obj(name).get('deploy', []):
        m = re.search(r' INFO ' + re.escape(logger) + r': ' + re.escape(event) + r' (\{.*\})$', r['message'])
        if m:
            rows.append({'timestamp': r['timestamp'], 'event': json.loads(m[1])})
    return sorted(rows, key=lambda r: r['timestamp'])

def pacific(timestamp):
    return datetime.fromisoformat(timestamp.replace('Z', '+00:00')).astimezone(ZoneInfo('America/Los_Angeles')).isoformat()

before_rows = originals('before-status.json', 'speeddesk_live_status', 'nightcrawler.speeddesk')
after_rows = originals('kalshi-fresh.json', 'speeddesk_live_status', 'nightcrawler.speeddesk')
assert before_rows and after_rows
before, after = before_rows[-1], after_rows[-1]
keys = ['mode', 'configured_mode', 'status', 'authenticated', 'fee_precision_verified', 'fee_precision_usd',
        'cash_usd', 'reserved_usd', 'open_risk_usd', 'open_cost_usd', 'at_risk_usd', 'open_orders',
        'positions', 'total_halted', 'day_stop_latched', 'real_orders_available', 'integrity_error',
        'integrity_reset', 'cleanup_pending']
paths = [[k] for k in keys]
paths += [['caps', k] for k in ['window_usd', 'open_usd', 'day_stop_usd', 'clip', 'total_stop_usd']]
paths += [['total', k] for k in ['windows','fills','settled_windows','fees_usd','locked_usd','directional_usd',
                                'pnl_usd','worst_usd','take_attempts','take_fills','maker_orders','maker_fills','locks','lock_fills']]
paths += [['ladder', k] for k in ['enabled','rung','ladder_rung','max_window_usd','configured_max_window_usd',
                                 'top_rung','change_pending','recheck_pending','effective_from','pending_limits',
                                 'rung_started_at','start_pnl_usd','last_change']]
paths += [['ladder','limits', k] for k in ['window_usd', 'open_usd', 'day_stop_usd', 'clip', 'total_stop_usd']]

def at(event, path):
    for k in path:
        if not isinstance(event, dict) or k not in event:
            return {'MISSING': True}
        event = event[k]
    return event

comparisons = []
for path in paths:
    a, b = at(before['event'], path), at(after['event'], path)
    equal = a == b
    numeric = all(isinstance(v, (int,float)) and not isinstance(v,bool) for v in [a,b])
    tolerant = numeric and math.isclose(a,b,rel_tol=0,abs_tol=1e-10)
    comparisons.append({'field':'.'.join(path),'before':a,'after':b,
                        'missing':a == {'MISSING':True} or b == {'MISSING':True},
                        'exact_equal':equal,'within_tolerance':equal or tolerant})
assert not any(x['missing'] or not x['within_tolerance'] for x in comparisons)
ae = after['event']
assert ae['authenticated'] and ae['trading_now'] and ae['waiting'] == ''
assert ae['integrity_error'] is None and not ae['cleanup_pending']
assert 0 <= ae['at'] - ae['cash_at'] < 3
assert 0 <= ae['at'] - ae['as_of'] < 3

controls=[]
for r in obj('used-controls.json')['deploy']:
    m=re.search(r' INFO nightcrawler.speeddesk: (speeddesk_live_resume|speeddesk_live_integrity_reset|speeddesk_live_day_reset) (\{.*\})$',r['message'])
    if m:
        v=json.loads(m[2]); assert v.get('state') == 'ignored; this value was already used',v
        controls.append({'timestamp':r['timestamp'],'event':m[1],'data':v})
assert {x['event'] for x in controls} == {'speeddesk_live_resume','speeddesk_live_integrity_reset','speeddesk_live_day_reset'}

lr=originals('learner-startup.json','kalshi_online_learning_status','nightcrawler.kalshi_online_learning')
assert len(lr)==1
learning=lr[0]['event']['learning']
assert learning['enabled'] and learning['mode']=='observe_only'
assert not learning['live_application'] and not learning['profitability_proven'] and learning['error'] is None
assert learning['forecasts']==learning['scored']==0
periodic = originals('learner-after-first-pass.json','kalshi_online_learning_status','nightcrawler.kalshi_online_learning')
assert len(periodic)==1
pl=periodic[0]['event']['learning']
assert pl['enabled'] and pl['mode']=='observe_only' and pl['error'] is None
assert pl['source_fingerprint']==learning['source_fingerprint']
assert pl['forecasts']==pl['scored']==0 and pl['unknown']==1
assert pl['exclusions']['startup_inside']==1
assert pl['brier_baseline'] is None and pl['brier_shadow'] is None

def git(*args):
    return subprocess.check_output(['git',*args],cwd=REPO).decode().strip()
tree_checks={k:git('rev-parse',f'{MERGE}:{k}') == git('rev-parse',f'{FEATURE}:{k}') for k in ['src','tests']}
protected=['src/nightcrawler/config.py','src/nightcrawler/polydesk.py','src/nightcrawler/ledger.py',
           'src/nightcrawler/speeddesk_live.py','src/nightcrawler/speeddesk_live_model.py',
           'src/nightcrawler/speeddesk_kalshi_client.py','Dockerfile','railway.json','pyproject.toml']
protected_checks={k:git('rev-parse',f'{MERGE}:{k}') == git('rev-parse',f'{BASE}:{k}') for k in protected}
assert all(tree_checks.values()) and all(protected_checks.values())
d=[x for x in obj('deployment-terminal.json')['deployments'] if x['id']==NEW]
assert len(d)==1 and d[0]['status']=='SUCCESS' and d[0]['meta']['commitHash']==MERGE
health=obj('health-final.json')
assert len(health['services'])==2
for s in health['services']:
    assert s['state']=='online' and not s['hasIssues']
    assert s['replicaStatus']=={'running':1,'crashed':0,'total':1}
rec=[s for s in health['services'] if s['serviceName']=='kalshi-recorder'][0]
assert rec['activeDeployments'][0]['id']=='8453f919-b891-4aa7-8478-6fcf6b9c24ee'
assert not obj('tracebacks-final.json')['deploy']

out={'recorded_at':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
     'scope':'Selected original status fields and bounded startup logs; not raw ledger/stop-anchor or complete activity export',
     'merge':MERGE,'deployment':d[0], 'before':{'timestamp':before['timestamp'],'pacific':pacific(before['timestamp'])},
     'fresh_after':{'timestamp':after['timestamp'],'pacific':pacific(after['timestamp']),
                    'cash_age_s':ae['at']-ae['cash_at'],'account_age_s':ae['at']-ae['as_of'],
                    'reason':ae['reason'],'trading_now':ae['trading_now'],'waiting':ae['waiting']},
     'status_original_rows':{'before':len(before_rows),'fresh_after':len(after_rows)},
     'compared_fields':len(comparisons),'exact_equal':sum(x['exact_equal'] for x in comparisons),
     'absolute_tolerance':1e-10,'comparisons':comparisons,
     'used_controls_originals':controls,'used_controls_query_raw_rows':len(obj('used-controls.json')['deploy']),
     'learner_startup':lr[0], 'learner_first_periodic':periodic[0], 'learner_initial_read_counts_not_readiness':True,
     'no_forward_accuracy_or_profitability_claim':True,'cold_first_status_excluded_as_account_readiness':True,
     'app_test_tree_checks':tree_checks,'protected_checks':protected_checks,
     'health':health,'traceback_query_rows':0,'traceback_query_end':'2026-10-15T13:57:09Z',
     'authenticated_http_page_not_checked':True,'EXEC_DELAY_001':'OPEN','TJR_MNQ_001':'BLOCKED_UNCHANGED'}
(ROOT/'root-release-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['recorded_at','compared_fields','exact_equal','fresh_after','no_forward_accuracy_or_profitability_claim']}))
