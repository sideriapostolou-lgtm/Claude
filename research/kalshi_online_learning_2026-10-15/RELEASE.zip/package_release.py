"""Preserve original release evidence separately from immutable preparation."""
import hashlib
import json
import re
import subprocess
import zipfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

HERE=Path(__file__).resolve().parent
REPO=Path('/workspace/nightcrawler-online-learning')
OUT=REPO/'research/kalshi_online_learning_2026-10-15'
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=REPO)
assert git('rev-parse','HEAD').decode().strip()=='933a43d2d7cb6d6dd27b4728d50c78ce0f488ed5'
assert sha((OUT/'PREPARATION.zip').read_bytes())=='c14cdba6627c0d416659e4059aba0e30b1ffc652858a121afa26d59f4219dba9'
payload={p.name:p.read_bytes() for p in sorted(HERE.iterdir()) if p.is_file() and p.suffix in {'.json','.py'}}
payload['RELEASE.md']=(OUT/'RELEASE.md').read_bytes()
checks=[]
for i in range(1,6):
    r=json.loads(payload[f'latest-tjr-gate-{i}.raw.json'])
    s=r['response']['structuredContent']
    path=r['path']; expected=git('rev-parse','933a43d:'+path).decode().strip()
    assert expected==s['sha']
    assert git('show','933a43d:'+path).decode()==s['content']
    checks.append({'path':path,'blob':expected,'entire_returned_content_matches_git':True})
payload['root-tjr-source-byte-verification.json']=(json.dumps(checks,indent=2)+'\n').encode()
# Narrow recognized credential patterns only. Hashes/UUIDs/names are not values.
patterns={
    'private_pem':re.compile(rb'-----BEGIN[ ](?:[A-Z]+[ ])?PRIVATE[ ]KEY-----'),
    'openai_style':re.compile(rb'\bsk-[A-Za-z0-9_-]{20,}'),
    'jupiter_style':re.compile(rb'\bjup_[A-Za-z0-9_-]{20,}'),
    'github_style':re.compile(rb'\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{25,}'),
    'github_pat':re.compile(rb'\bgithub_pat_[A-Za-z0-9_]{30,}'),
    'jwt':re.compile(rb'\beyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}'),
    'bearer_value':re.compile(rb'(?i)Bearer[ ]+[A-Za-z0-9_-]{24,}')
}
hits=[{'member':name,'pattern':key,'count':len(pat.findall(data))} for name,data in payload.items() for key,pat in patterns.items() if pat.search(data)]
assert not hits, [{'member':x['member'],'pattern':x['pattern'],'count':x['count']} for x in hits]
archive=OUT/'RELEASE.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(payload.items()):
        info=zipfile.ZipInfo(name,date_time=(2026,10,15,14,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16
        z.writestr(info,data)
members=[]
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert set(z.namelist())==set(payload)
    for name in sorted(payload):
        data=z.read(name); assert data==payload[name]
        members.append({'name':name,'bytes':len(data),'sha256':sha(data)})
manifest={'recorded_at_pacific':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
          'archive':'RELEASE.zip','bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),
          'member_count':len(members),'crc_all_passed':True,'member_bytes_match_originals':True,
          'private_pattern_scan':{'patterns':list(patterns),'matches':0,'scope':'Recognized credential formats in complete uncompressed archive members; not a universal secret-detection guarantee'},
          'preparation_sha256_unchanged':sha((OUT/'PREPARATION.zip').read_bytes()),
          'tjr_source_byte_checks':checks,'members':members}
(OUT/'RELEASE_ARCHIVE.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ['recorded_at_pacific','archive','bytes','sha256','member_count','crc_all_passed','member_bytes_match_originals']}))
