"""Archive a tested local candidate without publishing application source."""
import hashlib
import json
import re
import subprocess
import zipfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
HERE=Path(__file__).resolve().parent
FROZEN=HERE/'candidate-frozen'
CODE=Path('/workspace/nightcrawler-feed-learning')
DOCS=Path('/workspace/nightcrawler-online-learning')
OUT=DOCS/'research/kalshi_online_learning_2026-10-15'
def sha(b):return hashlib.sha256(b).hexdigest()
m=json.loads((HERE/'candidate-frozen-manifest.json').read_text())
assert m['full_pytest']['exit_code']==0 and m['full_pytest']['passed']==5695 and m['full_pytest']['skipped']==14
assert json.loads((FROZEN/'candidate-full-pytest.json').read_text())['exit_code']==0
assert '5695 passed, 14 skipped' in (FROZEN/'candidate-full-pytest.log').read_text()
payload={}
for path,v in m['members'].items():
 b=(FROZEN/path).read_bytes();assert len(b)==v['bytes'] and sha(b)==v['sha256'];payload['frozen/'+path]=b
for path,v in m['source_files'].items():
 assert (CODE/path).read_bytes()==payload['frozen/'+path]
assert sha((FROZEN/'candidate.patch').read_bytes())==m['patch_sha256']
for path in ['src/nightcrawler/kalshi_online_learning.py','src/nightcrawler/speeddesk_model.py',
             'src/nightcrawler/speeddesk.py','src/nightcrawler/speeddesk_live.py','src/nightcrawler/speeddesk_live_model.py',
             'src/nightcrawler/config.py','src/nightcrawler/ledger.py','src/nightcrawler/polydesk.py']:
 assert (CODE/path).read_bytes()==subprocess.check_output(['git','show',m['base']+':'+path],cwd=CODE)
for name in ['candidate-frozen-manifest.json','package_candidate.py']:
 payload[name]=(HERE/name).read_bytes()
payload['INPUT_CHRONOLOGY_PREPARATION.md']=(OUT/'INPUT_CHRONOLOGY_PREPARATION.md').read_bytes()
patterns=[rb'-----BEGIN[ ](?:[A-Z]+[ ])?PRIVATE[ ]KEY-----',rb'\bsk-[A-Za-z0-9_-]{20,}',rb'\bjup_[A-Za-z0-9_-]{20,}',rb'\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{25,}',rb'\bgithub_pat_[A-Za-z0-9_]{30,}']
assert not any(re.search(p,b) for b in payload.values() for p in patterns)
archive=OUT/'INPUT_CHRONOLOGY_PREPARATION.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for path,b in sorted(payload.items()):z.writestr(path,b)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(payload)
 assert all(z.read(p)==b for p,b in payload.items())
receipt={'recorded_at_pacific':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
         'scope':'Local candidate only; this research archive does not change deployed application source.',
         'base':m['base'],'patch_sha256':m['patch_sha256'],'source_files':m['source_files'],
         'full_pytest':m['full_pytest'],'targeted':m['targeted'],'mypy':m['mypy'],'ruff':m['ruff'],
         'independent_review':m['independent_review'],'root_verified_original_hashes_source_and_log':True,
         'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),
         'member_count':len(payload),'crc_and_member_bytes_verified':True,'recognized_credential_matches':0,
         'members':[{'name':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(payload.items())]}
(OUT/'INPUT_CHRONOLOGY_PREPARATION.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['archive','bytes','sha256','member_count','full_pytest']}))
