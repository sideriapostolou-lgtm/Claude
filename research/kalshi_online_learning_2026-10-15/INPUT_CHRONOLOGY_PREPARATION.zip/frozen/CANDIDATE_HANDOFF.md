# Local child learner input chronology candidate

Base: `91250c6598f4b866d7601ac0ead3e66ba55996cd` in `/workspace/nightcrawler-feed-learning`.
Only `src/nightcrawler/kalshi_arena.py` (child learning hooks) and new
`tests/test_kalshi_online_learning_input_chronology.py` are changed. No commit,
push, production query, deployment, config, financial control or real order action.
The existing total-stop latch remains untouched. Root owns repository documentation.

## Behavior

The practice simulator deliberately retains sticky degradation history, including
late pre-start data. The learner already time-qualifies `degrade` against window
start. Passing the simulator history into `advance` defeated that qualification.
This candidate passes an empty untimed map and makes existing learner-local
pre/post gap state authoritative. Ordinary `self.degraded` behavior is unchanged.

The child routes global frame-loss notifications to all bounded learner pending
windows, including those absent from practice inventory. When discovery admits a
new window, it replays the global loss watermark using the original child
observation time. This preserves same-frame announcement/drop protection while
avoiding reinterpretation of a genuinely pre-start event as an active gap.
A missing ladder before a window announcement in the same frame is replayed to
the learner at that frame's original observation time. The temporary failed-slug
set is bounded by the already-decoded frame; it adds no persistent storage.

`kalshi_online_learning.py` and `speeddesk_model.py` remain exactly equal to base.
The pure algorithm fingerprint remains
`b6112b7ef8955b20af734157c1e7f5ec533bf98f70e034558f06670578c391f2`.
That fingerprint is not a hash of the entire input pipeline. The exact local
patch identity is separately recorded in `candidate-review-v1.json`.
No historical unknowns or predictions are reconstructed; no epoch/reset/migration
is introduced. Existing checkpoint cadence and durability limits remain.

## Verification and retained failures

The new tests use actual child `receive`, `step`, degradation, label, checkpoint
and restart paths with synthetic windows, fake clocks and local temporary state.
No clients, network or sealed datasets are used. Tests cover future and active
late books/prints; future then active loss; global counter/sequence loss with
learner-only windows; same-frame and snapshot admission; original drop time;
explicit stream/Coinbase/selected gaps despite recovery; missing ladders before
and after announcements; postforecast loss across restart and out-of-order labels;
no restart reconstruction; exactly-once score; unchanged practice state and save
call timestamps with the learner disabled as a comparison.

`candidate-initial-focused.log/json`: 180 passed, one existing opt-in wall-clock
performance test skipped. This initial run preceded the three later test cases.
`candidate-current-targeted.log/json`: 85 passed (22 new chronology cases plus
existing pure learner/arena integration tests).
`candidate-current-mypy.log/json`: success, 128 source files.
`candidate-current-ruff.log/json`: both changed files pass.
Full-suite receipt and independent review are pending at initial handoff creation.
Each JSON receipt records the actual subprocess exit and command; shell wrapper
success is not substituted for the subprocess status.

The intentional missing-ladder red regression is retained in
`candidate-red-missing-ladder.log/json` (pytest exit 1 before the repair).
`candidate-test-fixture-id-failure.log/json` retains a separate test fixture
failure: fresh towns legitimately have random distinct IDs; the comparison
fixture now shares that ID explicitly before comparing all non-learning state.
Neither failure is represented as a passed run.

## Limits

This candidate does not narrow V1's `trade_stream and coinbase` quality condition,
change maker readiness, alter real cancellation, or timestamp the gap wire.
Quiet-print expiry and queued pre-start status timing are distinct open design
questions. Existing saved receipts do not attribute any particular one of the
five production `pregap` exclusions to this chronology defect. No production
fix, latency improvement, certified coverage, learned score, profitability or
EXEC completion is established by the local tests.

A missing ladder for a completely unknown window in an earlier separate frame
is not persisted in a new cache. Later discovery after start remains explicitly
startup-unknown; equal-clock cross-frame admission at exactly start is being
called out to independent review. The existing base also lacked a practice map
entry for that unknown window. This candidate does not infer an event timestamp
from current simulator state.

## Final completion

Independent Astra review ACCEPTED exact patch `f90a860d89700e09d4351fc585ebfe807cee9dc41b65405160dc7fb788dff427`; see `independent-candidate-review.json`. Full pytest exit 0: **5695 passed, 14 existing skips in 318.17s**. Refreshed targeted85/mypy128/Ruff2 checks also exit0. The source/test bytes stayed unchanged throughout final checks and review. Fixed bounded credential-pattern scan reports zero matches in the assigned source/test files. Exact copies, review and all check/failure receipts are in `candidate-frozen/`; `candidate-frozen-manifest.json` enumerates every file hash/length and the current source equality checks. This is a reviewed and tested LOCAL ONLY candidate, not an authorized or performed release.
