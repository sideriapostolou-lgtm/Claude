import hashlib
import json
import math
import re
import subprocess
import zipfile
from collections import Counter
from pathlib import Path

HERE=Path(__file__).resolve().parent
REPO=Path('/workspace/nightcrawler-online-learning')
OUT=REPO/'research/kalshi_online_learning_2026-10-15'
def read(name):
    r=json.loads((HERE/name).read_text())['result'];assert not r.get('isError'),name
    return r['structuredContent']
def events(name,logger,event=None):
    out=[]
    for row in read(name).get('deploy',[]):
        m=re.search(r' INFO '+re.escape(logger)+r': (\w+) (\{.*\})$',row['message'])
        if m and (event is None or m[1]==event):out.append({'timestamp':row['timestamp'],'type':m[1],'data':json.loads(m[2])})
    return sorted(out,key=lambda x:x['timestamp'])
status=events('status.json','nightcrawler.speeddesk','speeddesk_live_status')[-1]
learning=events('learning.json','nightcrawler.kalshi_online_learning')
last=[x for x in learning if x['type']=='kalshi_online_learning_status'][-1]
unknown=[x for x in learning if x['type']=='kalshi_online_learning_unknown']
s=status['data'];l=last['data']['learning']
assert s['mode']=='paper' and s['total_halted'] and not s['trading_now']
assert s['open_risk_usd']==s['reserved_usd']==s['open_orders']==s['positions']==0
assert s['authenticated'] and s['integrity_error'] is None
assert l['enabled'] and l['mode']=='observe_only' and l['error'] is None
assert l['forecasts']==l['scored']==0 and l['unknown']==6
assert l['brier_baseline'] is None and l['brier_shadow'] is None
assert Counter(x['data']['reason'] for x in unknown)=={'startup_inside':1,'pregap':5}
assert len({x['data']['window'] for x in unknown})==6
settled=events('settlement.json','nightcrawler.speeddesk','speeddesk_live_settlement')
stops=events('stop.json','nightcrawler.speeddesk','speeddesk_live_stop')
assert len(settled)==len(stops)==1
assert settled[0]['data']['pnl_usd']==-.56 and settled[0]['data']['locked_usd']==0
assert math.isclose(s['total']['pnl_usd']-(-18.49100000000001),-.56,abs_tol=1e-10)
health=read('health.json');assert len(health['services'])==2 and all(x['state']=='online' and not x['hasIssues'] for x in health['services'])
assert len(read('tracebacks.json')['deploy'])==0
report={'recorded_at_pacific':'2026-10-15T08:14:25-07:00','evidence_end_utc':'2026-10-15T15:12:01Z',
 'running_commit':'933a43d2d7cb6d6dd27b4728d50c78ce0f488ed5','deployment':'458e8e54-804c-46f1-aaf4-0abab4461571',
 'repository_pin':'8bf1acb05f2133e7f24490048dfbf00db3a4ddb8',
 'status':status,'latest_learning':last,'unknowns':unknown,'settlements_in_query':settled,'stop_events_in_query':stops,
 'learner_original_event_counts':dict(Counter(x['type'] for x in learning)),
 'queries_uncapped':all(len(read(n).get('deploy',[]))<json.loads((HERE/n).read_text())['query']['limit'] for n in ['status.json','learning.json','tracebacks.json','settlement.json','stop.json']),
 'health':health,'traceback_rows':0,
 'next_step':'Attribute and correct pre-forecast feed gaps without weakening data-quality rules, then obtain a prospective forecast and official-label score-before-update receipt. EXEC remains open. Do not reset stops or resume real trading.',
 'limits':['Cash and cumulative bot P&L are different; no full native cash ledger or stop-budget anchor exported.',
 'The stop row reports total_at_risk_usd9.0589 vs cap10; the threshold/anchor calculation was not audited in this status check. Do not infer a new exact10-dollar loss or reset.',
 'No learner forecast/score was observed. All five full forecast opportunities excluded for pregap plus one startup partial. No accuracy or profitability claim.',
 'Health and filtered logs are bounded point/interval evidence, not complete storage/feed or prior-day coverage.',
 'TJR remains blocked on authentic development bars/costs, paper not started/live off; no duplicate research or automation change.',
 'Read-only production inspection. No variables, source deployment, order, financial setting, stop or resume change.']}
payload={n:(HERE/n).read_bytes() for n in ['health.json','status.json','learning.json','tracebacks.json','stop.json','settlement.json','save_observation.py']}
payload['observation.json']=(json.dumps(report,indent=2)+'\n').encode()
patterns=[rb'-----BEGIN[ ](?:[A-Z]+[ ])?PRIVATE[ ]KEY-----',rb'\bsk-[A-Za-z0-9_-]{20,}',rb'\bjup_[A-Za-z0-9_-]{20,}',rb'\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{25,}',rb'\beyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}']
assert not any(re.search(p,data) for data in payload.values() for p in patterns)
zip_path=OUT/'OBSERVATION_2026-10-15_0812_PDT.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for n,data in sorted(payload.items()):z.writestr(n,data)
with zipfile.ZipFile(zip_path) as z:
    assert z.testzip() is None
    assert set(z.namelist())==set(payload)
    assert all(z.read(n)==data for n,data in payload.items())
receipt={'observation':report,'archive':zip_path.name,'bytes':zip_path.stat().st_size,'sha256':hashlib.sha256(zip_path.read_bytes()).hexdigest(),
         'crc_and_exact_member_bytes_verified':True,'bounded_credential_scan_matches':0,
         'members':[{'name':n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for n,data in sorted(payload.items())]}
(OUT/'OBSERVATION_2026-10-15_0812_PDT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'member_count':len(payload),'archive_bytes':receipt['bytes'],'sha256':receipt['sha256'],'cash_usd':s['cash_usd'],'settled_pnl_usd':s['total']['pnl_usd'],'learning_scored':l['scored'],'unknown':l['unknown']}))
