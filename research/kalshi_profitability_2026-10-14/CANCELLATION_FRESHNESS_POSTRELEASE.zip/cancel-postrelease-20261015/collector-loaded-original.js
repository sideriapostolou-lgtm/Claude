const base=load("cancelCaptureBase");
const root="/workspace/shared/cancel-postrelease-20261015/";
const specs=[
["order","nightcrawler.speeddesk: speeddesk_live_order"],
["fill","nightcrawler.speeddesk: speeddesk_live_fill"],
["settlement","nightcrawler.speeddesk: speeddesk_live_settlement"],
["cancel","nightcrawler.speeddesk: speeddesk_live_cancel"],
["reject","nightcrawler.speeddesk: speeddesk_live_reject"],
["timing","nightcrawler.speeddesk: speeddesk_live_timing"],
["feed-timing","nightcrawler.speeddesk_kalshi_ws: speeddesk_feed_kalshi_ws_timing"],
["feed-gap","nightcrawler.speeddesk_kalshi_ws: speeddesk_feed_kalshi_ws_gap"],
["reconcile","nightcrawler.speeddesk: speeddesk_reconcile_trace"]
];
async function save(name,value){await tools.apply_patch("*** Begin Patch\n*** Add File: "+root+name+"\n+"+JSON.stringify(value,null,2).replace(/\n/g,"\n+")+"\n*** End Patch");}
async function query(name,phrase,start,end,suffix=""){
 const args={...base,startDate:start,endDate:end,filter:JSON.stringify(phrase)};
 const response=await tools.mcp__codex_apps__railway_get_logs(args);
 await save("queries/"+name+suffix+".json",{query:args,response});
 const rows=response.structuredContent?.deploy;
 notify({file:name+suffix,rows:rows?.length,error:response.isError||false});
 if(rows?.length>=500){
  const midpoint=new Date((Date.parse(start)+Date.parse(end))/2).toISOString();
  await query(name,phrase,start,midpoint,suffix+"-a");
  await query(name,phrase,midpoint,end,suffix+"-b");
 }
}
for(const [part,start,end,due] of [
 ["first","2026-10-15T12:15:00Z","2026-10-15T12:32:00Z","2026-10-15T12:32:02Z"],
 ["second","2026-10-15T12:30:00Z","2026-10-15T12:47:00Z","2026-10-15T12:47:02Z"]
]){
 while(Date.now()<Date.parse(due)){await new Promise(resolve=>setTimeout(resolve,Math.min(50000,Date.parse(due)-Date.now())));notify({phase:"awaiting fixed "+part+" retrospective",now:new Date().toISOString()});await yield_control();}
 for(const [name,phrase] of specs)await query(part+"-"+name,phrase,start,end);
 await save(part+"-queries-complete.json",{part,completed:new Date().toISOString(),fixed_start:start,fixed_end:end,deployment:base.deploymentId});
 notify({phase:part+" query batch complete"});await yield_control();
}
await save("COLLECTOR_STOPPED.json",{stopped_at:new Date().toISOString(),fixed_tail:"2026-10-15T12:47:00Z",collector_running:false,query_tail_extended:false});
notify({phase:"closed fixed capture; collector stopped"});
