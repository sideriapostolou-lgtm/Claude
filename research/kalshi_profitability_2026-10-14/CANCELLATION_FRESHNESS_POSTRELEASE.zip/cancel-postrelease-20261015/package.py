"""Snapshot only this fixed capture directory; no network or credential access."""
from pathlib import Path
import hashlib,json,zipfile,re,datetime
P=Path(__file__).resolve().parent
ARCHIVE=P.parent/'cancel-postrelease-20261015.zip'
MANIFEST=P.parent/'cancel-postrelease-20261015.manifest.json'
def sha(data):return hashlib.sha256(data).hexdigest()
def main():
 assert (P/'COLLECTOR_STOPPED.json').exists()
 assert (P/'first-queries-complete.json').exists() and (P/'second-queries-complete.json').exists()
 assert (P/'independent-final-review.json').exists(), 'Hold for independent final review'
 assert not ARCHIVE.exists() and not MANIFEST.exists(), 'Do not overwrite immutable archive'
 audit=json.loads((P/'final-audit.json').read_text())
 patterns={'private_key':rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----','provider_token':rb'\b(?:sk-[A-Za-z0-9_-]{20,}|gh[pousr]_[A-Za-z0-9]{20,}|xox[baprs]-[A-Za-z0-9-]{20,}|AKIA[A-Z0-9]{16})\b','credential_assignment':rb'(?i)["\x27]?(?:api[_-]?key|access[_-]?token|refresh[_-]?token|railway[_-]?token|password|client[_-]?secret)["\x27]?\s*[:=]\s*["\x27][^"\x27\r\n]{8,}["\x27]','bearer_value':rb'(?i)\bBearer\s+[A-Za-z0-9_.-]{20,}'}
 files=sorted(f for f in P.rglob('*') if f.is_file());assert not any(f.is_symlink() for f in files)
 original={str(f.relative_to(P.parent)):f.read_bytes() for f in files};flags=[]
 for name,data in original.items():
  for category,pattern in patterns.items():
   n=len(re.findall(pattern,data))
   if n:flags.append({'path':name,'category':category,'count':n})
 if flags:print(json.dumps({'secret_pattern_flags':flags}));raise RuntimeError('Private review required before packaging')
 with zipfile.ZipFile(ARCHIVE,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for name,data in original.items():z.writestr(name,data)
 with zipfile.ZipFile(ARCHIVE) as z:
  assert z.testzip() is None
  assert len(z.namelist())==len(original) and set(z.namelist())==set(original)
  for name,data in original.items():
   assert z.read(name)==data and sha(z.read(name))==sha(data)
   assert (P.parent/name).read_bytes()==data,'Source changed during packaging'
 manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':{'file':ARCHIVE.name,'members':len(original),'bytes':ARCHIVE.stat().st_size,'uncompressed_bytes':sum(map(len,original.values())),'sha256':sha(ARCHIVE.read_bytes())},'scope':'Every exact file recursively within cancel-postrelease-20261015, including originals, failed/predata collector versions, first/final audits, independent final review, timing reports, assignment and stopped markers; no other workspace/home/env files. Archive/manifest are adjacent, not inside source directory.','omissions':[],'secret_pattern_scan':{'files':len(original),'categories':list(patterns),'flags':flags,'limitation':'Bounded recognized-pattern scan; not proof every possible secret format is recognizable'},'verification':{'crc':'pass','exact_member_names':'pass','every_member_byte_equality':'pass','every_member_sha256':'pass','every_current_source_byte_equality':'pass'},'audit_final_flags':audit['coverage_flags'],'collector_completion':audit['collector_completion'],'limitations':['Fixed windows12:15–12:30/12:30–12:45UTC; query publication tail12:47UTC unchanged; collector stopped12:47:23.654UTC after fetching past bounds.','Settlement arithmetic agreement and no surfaced query/join errors do not certify complete venue/source tape.','Mainreader freshness remains unresolved: known delays and overflow-unknown receipts; sampled diagnostics, nested spans non-additive.','Cancellation request/404 receipts are not confirmed terminal order states.','Startup/next partial/practice excluded; no alternative policy or causal before/after profitability inference.','Root startup/restart account verification and supplemental monitors are separate evidence, not additional queries by this collector.'],'sources':{name:{'bytes':len(data),'sha256':sha(data)} for name,data in original.items()}}
 MANIFEST.write_text(json.dumps(manifest,indent=2)+'\n')
 print(json.dumps({'archive':manifest['archive'],'manifest_sha256':sha(MANIFEST.read_bytes()),'checks':manifest['verification'],'scan_flags':len(flags),'omissions':[]},indent=2))
if __name__=='__main__':main()
