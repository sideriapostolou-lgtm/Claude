"""Offline diagnostic classification; wall bounds and exact reader identities only."""
import json,statistics,math
from pathlib import Path
from decimal import Decimal as D
from collections import defaultdict,Counter
from datetime import datetime,timezone
P=Path(__file__).resolve().parent
START=D(str(datetime(2026,10,15,12,15,tzinfo=timezone.utc).timestamp()))
CLOSE1=START+D(900);CLOSE2=CLOSE1+D(900)
def classify(start,end):
 if start is None or end is None:return 'unknown_wall_interval'
 if start>=START and end<=CLOSE1:return 'first_contained'
 if start>=CLOSE1 and end<=CLOSE2:return 'second_contained'
 if end<START or start>CLOSE2:return 'outside_fixed_windows'
 return 'boundary_covering'
def summary(a):
 a=sorted(a);return {'n':len(a),'median':statistics.median(a) if a else None,'p95_nearest_rank':a[max(0,math.ceil(.95*len(a))-1)] if a else None,'max':max(a) if a else None}
def main():
 x=json.load(open(P/'audit.json'),parse_float=D);groups=defaultdict(list);classified=[]
 for e in x['feed_timing']:
  reader=e.get('reader') or {};receipt=e.get('receipt') or {};identity=(reader.get('kind'),reader.get('instance'),reader.get('process'),e.get('session'));a=receipt.get('accepted_wall');b=receipt.get('received_wall')
  a=D(str(a)) if a is not None else None;b=D(str(b)) if b is not None else None
  cls=classify(a,b);groups[(identity,cls)].append(e);classified.append({'reader':reader,'session':e.get('session'),'event':e.get('event'),'receipt_status':receipt.get('status'),'receipt_interval_class':cls,'accepted_wall':a,'received_wall':b,'apply_wall':e.get('apply_wall'),'residence_ms':receipt.get('residence_ms'),'publication':e['_publication']})
 out=[]
 for (identity,cls),rows in sorted(groups.items(),key=lambda kv:str(kv[0])):
  known=[D(str((r.get('receipt') or {})['residence_ms'])) for r in rows if (r.get('receipt') or {}).get('status')=='known' and (r.get('receipt') or {}).get('residence_ms') is not None]
  out.append({'reader_identity_kind_instance_process_session':identity,'interval_class':cls,'rows':len(rows),'events':dict(Counter(e.get('event') for e in rows)),'receipt_status':dict(Counter((e.get('receipt') or {}).get('status') for e in rows)),'known_residence_ms':summary(known)})
 trace_groups=defaultdict(list);trace_records=[]
 for t in x['reconcile_traces']:
  a=D(t['started_at']);b=a+D(t['elapsed_ms'])/1000;cls=classify(a,b);trace_groups[cls].append(t);resumes=[]
  for r in t.get('reads',[]):
   marks=r.get('marks_ms') or {};c=marks.get('worker_completed');v=marks.get('coroutine_resumed')
   if c is None or v is None:continue
   c=D(c);v=D(v);resumes.append({'read':r.get('read'),'delay_ms':v-c,'interval_class':classify(a+c/1000,a+v/1000)})
  trace_records.append({'cycle':t.get('cycle'),'started_at':a,'anchored_end_at':b,'interval_class':cls,'reads_omitted':t.get('reads_omitted'),'new_fills_omitted':t.get('new_fills_omitted'),'read_resume':resumes,'work_details_not_additive':True})
 trace_summary=[]
 for cls,rows in trace_groups.items():
  delays=[rr['delay_ms'] for t in trace_records if t['interval_class']==cls for rr in t['read_resume'] if rr['interval_class']==cls]
  trace_summary.append({'interval_class':cls,'selected_cycles':len(rows),'selected_reads':sum(len(t.get('reads',[])) for t in rows),'read_omissions':sum(t.get('reads_omitted',0) for t in rows),'new_fill_omissions':sum(t.get('new_fills_omitted',0) for t in rows),'contained_worker_complete_to_coroutine_resume_ms':summary(delays)})
 result={'scope':'sampled original diagnostics only; not full tape or complete quiet-cycle/work coverage','classification_basis':'receipt accepted_wall/received_wall; reconcile started_at wall anchor + documented monotonic elapsed offsets; publication time never substitutes for measured interval; clock uncertainty remains','feed_reader_groups':out,'feed_classified_receipts':classified,'reconcile_groups':trace_summary,'reconcile_classified':trace_records,'raw_gap_warning_publication_counts':dict(Counter('first_publication' if START<=D(str(datetime.fromisoformat(e['_publication'].replace('Z','+00:00')).timestamp()))<CLOSE1 else 'second_publication' if CLOSE1<=D(str(datetime.fromisoformat(e['_publication'].replace('Z','+00:00')).timestamp()))<CLOSE2 else 'tail_publication' for e in x['feed_gaps'])),'limitation':'Gap warnings are publication cohorts with text/identity, not measured full intervals. Overflow unknown receipts remain unknown. Reader sessions/instances are not pooled. Source ages of durable intent inputs exclude rejected-source traffic; decision-to-ack excludes lock and is not resting-to-fill latency.'}
 (P/'timing-audit.json').write_text(json.dumps(result,indent=2,default=str)+'\n')
 print(json.dumps({'feed_groups':out,'reconcile_groups':trace_summary},indent=2,default=str))
if __name__=='__main__':main()
