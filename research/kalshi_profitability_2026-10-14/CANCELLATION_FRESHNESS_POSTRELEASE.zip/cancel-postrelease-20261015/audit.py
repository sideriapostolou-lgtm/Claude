"""Offline original-only fixed-window postrelease parser; no account/network actions."""
import json,re,hashlib,statistics
from pathlib import Path
from decimal import Decimal as D
from collections import defaultdict,Counter
P=Path(__file__).resolve().parent
DEPLOYMENT='cdf0d895-6eed-403b-9594-4679692a4499'
TICKERS=['KXBTC15M-26OCT150830-30','KXBTC15M-26OCT150845-45']
RX=re.compile(r'^\S+ (?:INFO|WARNING|ERROR) (?P<logger>nightcrawler\.[\w.]+): (?P<event>speeddesk_[\w]+) (?P<body>.*)$')
def quant(values):
 values=sorted(values)
 return {'n':len(values),'median':statistics.median(values) if values else None,'p95_nearest_rank':values[max(0,__import__('math').ceil(.95*len(values))-1)] if values else None,'max':max(values) if values else None}
def main():
 events=defaultdict(list);queries=[];seen=set();excluded=[];errors=[];duplicates=[];conflicts=[];unresolved_caps=[];unexpected=[]
 for path in sorted((P/'queries').glob('*.json')):
  w=json.loads(path.read_text());q=w['query']
  if w.get('unresolved_cap'):unresolved_caps.append(w);continue
  r=w['response'];s=r.get('structuredContent')
  if not s:queries.append({'file':str(path.relative_to(P)),'error':True,'query':q});errors.append(path.name);continue
  assert s['scope']=='deployment' and s['deploymentId']==DEPLOYMENT
  assert s['serviceId']=='f84d3b52-002f-44cb-931e-bc9e3e097e97' and s['environmentId']=='17f7b0e0-104c-4903-9484-0106748b3cdb'
  if r.get('isError'):errors.append(path.name);continue
  rows=s.get('deploy',[]);capped=len(rows)>=500
  queries.append({'file':str(path.relative_to(P)),'query':q,'metadata':{k:s.get(k) for k in ['scope','deploymentId','serviceId','environmentId','status']},'count':len(rows),'capped':capped,'analyzed':not capped})
  if capped:continue
  for row in rows:
   key=(row['timestamp'],row['message'])
   if key in seen:duplicates.append({'timestamp':row['timestamp'],'file':path.name,'kind':'identical original row repeated across responses'});continue
   seen.add(key);m=RX.fullmatch(row['message'])
   if not m:excluded.append({'timestamp':row['timestamp'],'reason':'unrecognized anchored original signature'});continue
   if m['logger'] not in q['filter']:unexpected.append({'file':path.name,'timestamp':row['timestamp'],'reason':'unexpected original logger'})
   from datetime import datetime
   ts=datetime.fromisoformat(row['timestamp'].replace('Z','+00:00'));qs=datetime.fromisoformat(q['startDate'].replace('Z','+00:00'));qe=datetime.fromisoformat(q['endDate'].replace('Z','+00:00'))
   if not qs<=ts<=qe:unexpected.append({'file':path.name,'timestamp':row['timestamp'],'reason':'outside query bounds'})
   try:d=json.loads(m['body'],parse_float=D)
   except json.JSONDecodeError:d={'text':m['body']}
   d['_publication']=row['timestamp'];d['_logger']=m['logger'];events[m['event']].append(d)
 intents={};acks={};not_sent={};fills={};settlements={}
 def insert(mapping,key,value,kind):
  if key in mapping:
   old={k:v for k,v in mapping[key].items() if not k.startswith('_')};new={k:v for k,v in value.items() if not k.startswith('_')}
   (duplicates if old==new else conflicts).append({'kind':kind,'key':key,'old':mapping[key],'new':value})
   return
  mapping[key]=value
 for o in events['speeddesk_live_order']:
  if o.get('state','').startswith('durable intent'):insert(intents,o['client_order_id'],o,'intent')
  elif o.get('state','').startswith('accepted;'):insert(acks,o['client_order_id'],o,'ack')
  elif o.get('state','').startswith('not sent;'):insert(not_sent,o['client_order_id'],o,'not_sent')
 for f in events['speeddesk_live_fill']:
  insert(fills,f['fill_id'],f,'fill')
 for s in events['speeddesk_live_settlement']:
  insert(settlements,s['window'],s,'settlement')
 ack_errors=[]
 for cid,a in acks.items():
  i=intents.get(cid)
  if i is None:ack_errors.append({'client_order_id':cid,'ack':a,'reason':'orphan ack; missing durable intent'})
  elif a['window']!=i['window'] or not a.get('order_id'):ack_errors.append({'client_order_id':cid,'ack':a,'intent':i,'reason':'ack window mismatch or missing order ID'})
 rejected={r.get('client_order_id') for r in events['speeddesk_live_reject']}
 joined=[];join_errors=[]
 for f in fills.values():
  if f['window'] not in TICKERS:continue
  i=intents.get(f['client_order_id']);a=acks.get(f['client_order_id']);problems=[]
  if not i:problems.append('missing durable intent')
  elif any(i[k]!=f[k] for k in ['window','side']):problems.append('intent mismatch')
  if not a:problems.append('missing accepted order')
  elif a['order_id']!=f['order_id']:problems.append('order ID mismatch')
  row={'fill':f,'intent':i,'ack':a,'problems':problems};joined.append(row)
  if problems:join_errors.append(row)
 windows=[]
 query_end=max((q['query']['endDate'] for q in queries if 'query' in q),default='')
 for t in TICKERS:
  fs=[f for f in fills.values() if f['window']==t];s=settlements.get(t);ii={k:i for k,i in intents.items() if i['window']==t};aa={k:a for k,a in acks.items() if a['window']==t}
  holding={side:{'shares':sum((f['size'] for f in fs if f['side']==side),D(0)),'cost':sum((f['size']*f['price'] for f in fs if f['side']==side),D(0)),'fees':sum((f['fee_usd'] for f in fs if f['side']==side),D(0))} for side in ['up','down']}
  u,d=holding['up'],holding['down'];cost=u['cost']+d['cost'];fees=u['fees']+d['fees'];pairs=min(u['shares'],d['shares']);locked=pairs*(1-(u['cost']+u['fees'])/u['shares']-(d['cost']+d['fees'])/d['shares']) if pairs else D(0)
  latency=[];ack_missing=0;lock_ack=0;ages=defaultdict(list);age_status=Counter()
  for cid,a in aa.items():
   intent=ii.get(cid)
   if intent and intent.get('kind')=='lock':lock_ack+=1;continue
   tim=a.get('timing')
   if isinstance(tim,dict) and tim.get('metric')=='decision_to_ack' and tim.get('status')=='ok' and tim.get('value_ms') is not None:latency.append(tim['value_ms'])
   else:ack_missing+=1
  for i in ii.values():
   for tim in i.get('timing') or []:
    age_status[(tim.get('metric'),tim.get('status'))]+=1
    if tim.get('status')=='ok' and tim.get('value_ms') is not None:ages[tim['metric']].append(tim['value_ms'])
  cancels=[c for c in events['speeddesk_live_cancel'] if c.get('window')==t or c.get('client_order_id') in ii]
  rr={'ticker':t,'fill_count':len(fs),'distinct_filled_orders':len({f['order_id'] for f in fs}),'maker_fills':sum(f['is_taker'] is False for f in fs),'taker_fills':sum(f['is_taker'] is True for f in fs),'lock_fills':sum(intents.get(f['client_order_id'],{}).get('kind')=='lock' for f in fs),'holding':holding,'intents':len(ii),'accepted':len(aa),'not_sent':sum(cid in not_sent for cid in ii),'rejected':sum(cid in rejected for cid in ii),'unresolved_intents':[cid for cid in ii if cid not in aa and cid not in not_sent and cid not in rejected],'decision_to_ack_ms':quant(latency),'ack_missing':ack_missing,'lock_ack_not_applicable':lock_ack,'intent_source_ages_ms':{metric:quant(vals) for metric,vals in ages.items()},'source_age_metric_status_counts':{str(k):v for k,v in age_status.items()},'cancel_states':dict(Counter(c.get('state') for c in cancels)),'cancel_events':len(cancels),'settlement':s,'status':'missing settlement; unknown' if s is None else 'observed settlement'}
  if s:
   payout=u['shares'] if s['up_wins'] else d['shares'];pnl=payout-cost-fees;computed={'up_shares':u['shares'],'down_shares':d['shares'],'cost_usd':cost,'fee_usd':fees,'payout_usd':payout,'pnl_usd':pnl,'locked_usd':locked,'direction_usd':pnl-locked}
   rr['recomputed']=computed;rr['mismatches']={k:{'reported':s[k],'computed':v} for k,v in computed.items() if abs(v-s[k])>D('0.0000001')};rr['status']='settlement arithmetic agrees; source coverage separate' if not rr['mismatches'] else 'MISMATCH'
  close='2026-10-15T12:30:00Z' if t==TICKERS[0] else '2026-10-15T12:45:00Z'
  rr['capture_phase']='INCOMPLETE second-window partial; no complete-window result' if query_end<close else 'closed-window retrospective query; coverage still requires separate assessment'
  if query_end<close:rr['status']='INCOMPLETE; not zero P&L'
  windows.append(rr)
 result={'deployment':DEPLOYMENT,'source':'1bd8f2217025b098adfd2a0e8a9ca3bbe45c97da','fixed_start':'2026-10-15T12:15:00Z','fixed_end':'2026-10-15T12:45:00Z','fixed_tail':'2026-10-15T12:47:00Z','queries':queries,'errors':errors,'unresolved_caps':unresolved_caps,'duplicate_receipts':duplicates,'conflicting_receipts':conflicts,'ack_errors':ack_errors,'unexpected_rows':unexpected,'original_event_populations':{e:len(rows) for e,rows in events.items()},'unrecognized_original_signatures':excluded,'excluded_tickers':dict(Counter(f['window'] for f in fills.values() if f['window'] not in TICKERS)),'joined':joined,'join_errors':join_errors,'windows':windows,'feed_timing':events['speeddesk_feed_kalshi_ws_timing'],'feed_gaps':events['speeddesk_feed_kalshi_ws_gap'],'reconcile_traces':events['speeddesk_reconcile_trace'],'timing_receipts':events['speeddesk_live_timing'],'cancel_originals':events['speeddesk_live_cancel'],'rejects':events['speeddesk_live_reject']}
 result['collector_completion']={'first_batch_marker':(P/'first-queries-complete.json').exists(),'second_batch_marker':(P/'second-queries-complete.json').exists(),'stopped_marker':(P/'COLLECTOR_STOPPED.json').exists(),'note':'Batch/stopped markers show bounded execution ended; they do not certify complete venue/source tape.'}
 result['coverage_flags']={'query_errors':len(errors),'unresolved_caps':len(unresolved_caps),'conflicting_receipts':len(conflicts),'ack_errors':len(ack_errors),'fill_join_errors':len(join_errors),'unexpected_rows':len(unexpected),'unrecognized_original_signatures':len(excluded),'expected_event_families_per_batch':9,'actual_query_files':len(queries),'source_completeness_certified':False}
 (P/'audit.json').write_text(json.dumps(result,indent=2,default=str)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k in ['deployment','original_event_populations','errors','join_errors','windows','excluded_tickers']},indent=2,default=str))
if __name__=='__main__':main()
