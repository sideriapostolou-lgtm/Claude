"""Bounded offline quiet callback density profile; no production state or client."""
from __future__ import annotations

import cProfile
import dataclasses
import hashlib
import json
import logging
import pstats
import socket
import statistics
import subprocess
import tempfile
import threading
import time
from pathlib import Path

ROOT = Path('/workspace/nightcrawler-next-evidence')
OUT = Path('/workspace/shared/quiet-callback-profile.json')

def denied(*args, **kwargs):
    raise RuntimeError('offline diagnostic denies socket/client/thread use')

# Before imports/fixture: prohibit all socket allocation, network and worker threads.
class DeniedSocket(socket.socket):
    def __init__(self, *args, **kwargs):
        denied(*args, **kwargs)

socket.socket = DeniedSocket
socket.create_connection = denied
threading.Thread.start = denied

from test_kalshi_arena_feed import Ladders, LocalFeeds

from nightcrawler.clock import FakeClock
from nightcrawler.config import Settings
from nightcrawler.speeddesk import SpeedRunner
from nightcrawler.speeddesk_live import Intent, KalshiLiveDesk
from nightcrawler.speeddesk_live_model import LiveIntent
from nightcrawler.speeddesk_model import Trade, Window

logging.disable(logging.CRITICAL)
SLUG = 'KXBTC15M-QUIET-CURRENT'
T0 = 1792016160.0

class Feeds(LocalFeeds):
    def maker_windows(self):
        return {SLUG}


def native(value):
    if dataclasses.is_dataclass(value):
        return native(dataclasses.asdict(value))
    if isinstance(value, dict):
        return {str(key): native(val) for key, val in value.items()}
    if isinstance(value, (list, tuple)):
        return [native(val) for val in value]
    return value


def digest(value):
    return hashlib.sha256(json.dumps(native(value), sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def run(history, terminals):
    with tempfile.TemporaryDirectory(prefix='quiet-callback-', dir='/workspace/shared') as directory:
        clock = FakeClock(T0)
        def live_factory(settings, path, snapshot, **kwargs):
            return KalshiLiveDesk(settings, path, snapshot, client_factory=denied, **kwargs)
        runner = SpeedRunner(Settings(data_dir=Path(directory), speeddesk_enabled=True,
            speeddesk_kalshi_enabled=True, speeddesk_kalshi_mode='paper',
            speeddesk_kalshi_live_confirm=None, kalshi_key_id=None, kalshi_private_key=None,
            kalshi_arena_enabled=False), threading.Event(), clock=clock,
            feed_factory=Feeds, live_factory=live_factory)
        try:
            assert runner.live is not None and runner.live.client is None
            live = runner.live
            history_windows = []
            for index in range(history):
                begin = T0 - 900 * (history + 1 - index)
                spec = Window(f'KXBTC15M-QUIET-OLD{index:04}', begin, begin + 900, 80000,
                    venue_start_price=80000, venue='kalshi', taker_coefficient=.07,
                    maker_coefficient=0, fee_rounding='kalshi')
                history_windows.append(spec)
                for model in (runner.desk, live.twin):
                    model.add_window(dataclasses.replace(spec))
                    model.settle(spec.slug, True, spec.end + 1)
                live.book.add_window(dataclasses.replace(spec))
                live.book.settle(spec.slug, True, spec.end + 1, f's{index}')
            for index in range(terminals):
                spec = history_windows[index % history]
                key = f'quiet-terminal-{index}'
                live.book.intents[key] = LiveIntent(key, spec.slug, 'up', 'rest', .3, 1,
                    spec.start + 10, .3, order_id=f'o{index}', status='canceled', reservation_active=False)
                live.intents[key] = Intent(key, spec.slug, 'up', 'rest', .3, 1, .5,
                    spec.start + 10, order_id=f'o{index}', terminal=True)
            current = Window(SLUG, T0 - 60, T0 + 840, 80000, venue_start_price=80000,
                venue='kalshi', taker_coefficient=.07, maker_coefficient=0, fee_rounding='kalshi')
            runner.on_windows([current])
            # Warm a realistic hour of completed seconds without feed callbacks or orders.
            for second in range(3601):
                price = 80000 + (second % 17 - 8) * .5
                runner.desk.tape.tick(price, T0 - 3600 + second)
                live.twin.tape.tick(price, T0 - 3600 + second)
            runner.on_tick(80000, T0, T0)
            runner.on_status({'coinbase':'connected', 'trade_stream':True, 'markets':'connected'})
            # Clear setup-only pending receipts before measuring quiet callbacks.
            runner.checkpoint(T0)
            fixture = {'now':T0, 'current_window':native(current), 'history_windows':native(history_windows),
                'terminal_orders':native(list(live.book.intents.values())),
                'warmup':'3601 seconds, 80000+(second%17-8)*.5',
                'book_generator':'tests.test_kalshi_arena_feed.Ladders depth=25 seed=1',
                'trade':'up .30 size1 aggressor=sell, unique ID; current clock +.001 per pair',
                'callbacks_per_state':1000, 'unprofiled_pairs':250, 'profiled_pairs':250,
                'no_active_orders':True, 'arena':False, 'paper_mode':True}
            fixture_hash = digest(fixture)
            ladders = Ladders(SLUG, depth=25, seed=1)
            count = 0
            def pair():
                nonlocal count
                count += 1
                clock.advance(.001)
                now = clock.now()
                runner.on_book(ladders.delta(now)[count % 2])
                runner.on_trade(Trade(SLUG, 'up', .30, 1, now, f't{count}', 'sell', now))
            pending_before = len(runner.pending)
            ledger_before = runner.ledger.connection.total_changes if hasattr(runner.ledger, 'connection') else None
            wall, cpu = [], []
            for _ in range(250):
                w, c = time.perf_counter_ns(), time.thread_time_ns()
                pair()
                cpu.append((time.thread_time_ns()-c)/1000)
                wall.append((time.perf_counter_ns()-w)/1000)
            profile = cProfile.Profile()
            profile.enable()
            for _ in range(250):
                pair()
            profile.disable()
            stats = pstats.Stats(profile)
            rows = [{'file':str(Path(key[0]).relative_to(ROOT)) if key[0].startswith(str(ROOT)) else key[0],
                'line':key[1], 'function':key[2], 'primitive_calls':v[0], 'calls':v[1],
                'self_ms':v[2]*1000, 'cumulative_ms':v[3]*1000} for key,v in stats.stats.items()]
            assert count == 500 and len(runner.pending) == pending_before
            assert not runner.desk.orders and not live.twin.orders
            assert runner.live_problem is None and live.client is None
            assert len(runner.desk.seen_trades) == len(live.twin.seen_trades) == count
            return {'fixture':fixture,'fixture_sha256':fixture_hash,
                'unprofiled_pair_us':{'wall_median':statistics.median(wall),'cpu_median':statistics.median(cpu),
                    'wall_mean':statistics.fmean(wall),'cpu_mean':statistics.fmean(cpu),
                    'wall_max':max(wall),'cpu_max':max(cpu)}, 'wall_pair_us':wall, 'cpu_pair_us':cpu,
                'profile_top_cumulative':sorted(rows,key=lambda x:x['cumulative_ms'],reverse=True)[:35],
                'profile_top_self':sorted(rows,key=lambda x:x['self_ms'],reverse=True)[:25],
                'profile_all':rows, 'effects':{'book_callbacks':count,'trade_callbacks':count,
                    'practice_seen_trades':len(runner.desk.seen_trades),'twin_seen_trades':len(live.twin.seen_trades),
                    'practice_closed':len(runner.desk.closed),'twin_closed':len(live.twin.closed),
                    'live_settled':len(live.book.settled),'live_terminal_intents':len(live.intents),
                    'pending_before':pending_before,'pending_after':len(runner.pending),
                    'practice_orders':len(runner.desk.orders),'twin_orders':len(live.twin.orders),
                    'live_client_initialized':False,'live_problem':runner.live_problem,
                    'ledger_before_optional':ledger_before,'observer':runner.work_trace.status()}}
        finally:
            runner.close()


def main():
    result = {'scope':'offline density sensitivity; not production replay',
        'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        'guards':'socket.socket/create_connection and Thread.start denied before fixture/imports; fake unreachable client; no keys',
        'limitations':['No raw production state available. Empty historical inventories and no active maker/taker orders.',
            'No pending markout waiters, arena process, account reads, worker threads or event-loop contention.',
            'Only 500 pairs per state, split separate unprofiled/profiled phases; cProfile timings are instrumented.',
            '200 settled windows and316 terminal orders match density motivation only, not actual production contents.',
            'Book/trade fixture follows arena hotpath generators, but actual live callbacks replace SpyLive.',
            'Historical windows retained in practice and twin; historical books not retained; live maker gate enabled.',
            'Setup checkpoint and temporary fakes-only persistence excluded from timed phase.'],
        'cases':[run(0,0),run(200,316)]}
    result['script_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    result['source_sha256'] = {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
        for p in (ROOT/'src/nightcrawler/speeddesk.py',ROOT/'src/nightcrawler/speeddesk_model.py',
            ROOT/'src/nightcrawler/speeddesk_live.py',ROOT/'src/nightcrawler/speeddesk_worktrace.py')}
    OUT.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'path':str(OUT),'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),
        'cases':[{'fixture_sha256':x['fixture_sha256'],'timings':x['unprofiled_pair_us'],
            'top':x['profile_top_cumulative'][:12],'effects':x['effects']} for x in result['cases']]},indent=2))

if __name__ == '__main__':
    main()
