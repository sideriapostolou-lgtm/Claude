"""Independent finite first-window audit of saved original tool responses only."""
from __future__ import annotations
import hashlib,json,re
from collections import Counter
from datetime import datetime,timezone
from decimal import Decimal
from pathlib import Path

ROOT=Path('/workspace/shared')
SOURCE=ROOT/'ws-timing-first-window-audit-input.json'
raw=SOURCE.read_bytes(); capture=json.loads(raw)
START=datetime.fromisoformat('2026-10-15T04:15:00+00:00').timestamp()
END=START+900
def stamp(s):return datetime.fromisoformat(s.replace('Z','+00:00')).timestamp()
def sha(b):return hashlib.sha256(b).hexdigest()
events=[];seen=set();duplicates=0;parse_errors=[];queries=[]
pattern=re.compile(r'^(\S+) (?:INFO|WARNING|ERROR|DEBUG|CRITICAL) ([^:]+): (speeddesk_[A-Za-z_]+)(?: (.*))?$',re.S)
for q in capture['queries']:
 response=q['response'];sc=response.get('structuredContent',{});rows=sc.get('deploy',[])
 artifact=Path(q['artifact'])
 queries.append({'label':q['label'],'query':q['query'],'received_at':q['received_at'],
  'rows':len(rows),'cap_hit':len(rows)>=q['query']['limit'],'isError':response.get('isError'),
  'artifact_sha_matches':artifact.exists() and sha(artifact.read_bytes())==q['artifact_sha256']})
 for row in rows:
  key=(row['timestamp'],row['message'])
  if key in seen:duplicates+=1;continue
  seen.add(key)
  match=pattern.match(row['message'])
  if not match:
   parse_errors.append({'timestamp':row['timestamp'],'reason':'prefix','message':row['message']});continue
  wall,logger,event,body=match.groups();body=body or ''
  payload=None
  if body.startswith('{'):
   try:payload=json.loads(body)
   except Exception as exc:parse_errors.append({'timestamp':row['timestamp'],'event':event,'reason':type(exc).__name__})
  events.append({'id':sha((row['timestamp']+'\0'+row['message']).encode()),'timestamp':row['timestamp'],
   'logger':logger,'source_wall':wall,'event':event,'payload':payload,'body':body,'original_message':row['message']})
events.sort(key=lambda r:(r['timestamp'],r['id']))
def subset(name):return [e for e in events if e['event']==name]
def log_inside(e):return START<=stamp(e['timestamp'])<END
def ref(e):return {'id':e['id'],'timestamp':e['timestamp'],'payload':e['payload']}

# Ticker inferred from actual first-window real intent, never from naming convention.
inside_intents=[e for e in subset('speeddesk_live_order') if e['payload'].get('state','').startswith('durable intent') and START<=e['payload']['at']<END]
tickers=sorted({e['payload']['window'] for e in inside_intents});assert len(tickers)==1,tickers
TICKER=tickers[0]
window=lambda name:[e for e in subset(name) if e['payload'].get('window')==TICKER]
orders=window('speeddesk_live_order');intents=[e for e in orders if e['payload'].get('state','').startswith('durable intent')]
accepted=[e for e in orders if e['payload'].get('state','').startswith('accepted;')]
fills=window('speeddesk_live_fill');settlements=window('speeddesk_live_settlement');cancels=window('speeddesk_live_cancel')
unique={};fill_conflicts=[]
for e in fills:
 f=e['payload'];fid=f['fill_id']
 if fid in unique and unique[fid]['payload']!=f:fill_conflicts.append(fid)
 unique[fid]=e
fills=list(unique.values())
D=lambda x:Decimal(str(x))
cost=sum((D(e['payload']['price'])*D(e['payload']['size']) for e in fills),Decimal(0))
fees=sum((D(e['payload']['fee_usd']) for e in fills),Decimal(0))
shares={side:sum((D(e['payload']['size']) for e in fills if e['payload']['side']==side),Decimal(0)) for side in ['up','down']}
intent_ids={e['payload']['client_order_id'] for e in intents}
accepted_ids={e['payload']['order_id'] for e in accepted}
joins=[{'fill_id':e['payload']['fill_id'],'intent_found':e['payload']['client_order_id'] in intent_ids,
        'accepted_order_found':e['payload']['order_id'] in accepted_ids} for e in fills]
financial={'ticker':TICKER,'real_fill_events':len(fills),'durable_intents':len(intent_ids),
 'accepted_orders':len(accepted_ids),'cancel_rows':len(cancels),'fill_conflicts':fill_conflicts,
 'cost_decimal':str(cost),'fee_decimal':str(fees),'shares_decimal':{k:str(v) for k,v in shares.items()},
 'worst_case_pnl_at_window_exposure_decimal':str(min(shares.values())-cost-fees),
 'fill_joins':joins,'fills':[ref(e) for e in fills],'orders':[ref(e) for e in orders],
 'cancels':[ref(e) for e in cancels],'settlements':[ref(e) for e in settlements]}
if len(settlements)==1:
 s=settlements[0]['payload'];payout=shares['up' if s['up_wins'] else 'down'];paired=min(shares.values())
 financial['recomputed_payout_decimal']=str(payout);financial['recomputed_pnl_decimal']=str(payout-cost-fees)
 financial['settlement_checks']={
  'shares_match':all(abs(float(shares[k])-s[k+'_shares'])<1e-9 for k in shares),
  'cost_matches':abs(float(cost)-s['cost_usd'])<1e-9,'fees_match':abs(float(fees)-s['fee_usd'])<1e-9,
  'payout_matches':abs(float(payout)-s['payout_usd'])<1e-9,
  'pnl_matches':abs(float(payout-cost-fees)-s['pnl_usd'])<1e-9,
  'locked_plus_direction_matches':abs(s['locked_usd']+s['direction_usd']-s['pnl_usd'])<1e-9,
  'net_plus_paired_credit_matches':abs(s['net_payout_usd']+s['paired_credit_usd']-s['payout_usd'])<1e-9}

timing=[e for e in subset('speeddesk_feed_kalshi_ws_timing') if log_inside(e)]
gaps=[e for e in subset('speeddesk_feed_kalshi_ws_gap') if log_inside(e)]
def gap_class(e):
 b=e['body']
 if 'timestamp_missing_or_stale:' in b:return 'source_age_or_invalid_timestamp'
 if 'market_set_changed' in b:return 'market_set_changed'
 if b=='reason=TimeoutError':return 'timeout'
 return 'other'
main_known=[];unidentified_known=[]
for e in timing:
 p=e['payload'];r=p.get('receipt') or {}
 if p.get('event')=='gap' and r.get('status')=='known':
  (main_known if 'local_work' in p else unidentified_known).append(e)
freshness={'timing_rows':len(timing),'timing_events':dict(Counter(e['payload']['event'] for e in timing)),
 'shared_logger_gap_rows':len(gaps),'shared_gap_classes':dict(Counter(map(gap_class,gaps))),
 'timestamp_domains':dict(Counter(re.search(r'timestamp_missing_or_stale:([^:]+):',e['body']).group(1) for e in gaps if 'timestamp_missing_or_stale:' in e['body'])),
 'known_gap_main_wiring':len(main_known),'known_gap_unidentified':len(unidentified_known),
 'unknown_gap_receipts':dict(Counter((e['payload'].get('receipt') or {}).get('status','missing') for e in timing if e['payload'].get('event')=='gap' and (e['payload'].get('receipt') or {}).get('status')!='known')),
 'main_known_gap_rows':[ref(e) for e in main_known],'unidentified_known_gap_rows':[ref(e) for e in unidentified_known],
 'gap_originals':gaps,'producer_limit':'Shared logger and instance-local session counters; only positive local_work under verified main-only wiring identifies main reader. Absence does not identify Weather. Do not aggregate connection counters across unidentified instances.',
 'other_feed_warnings':[e for e in events if log_inside(e) and e['event'] in ['speeddesk_feed_kalshi_trade_gap','speeddesk_feed_coinbase_disconnected','speeddesk_feed_kalshi_book_failed']]}

traces=subset('speeddesk_reconcile_trace')
selected=[e for e in traces if e['payload']['started_at']<END and e['payload']['at']>=START]
readrows=[];missing=[];queries_work=[]
for e in selected:
 p=e['payload']
 for i,r in enumerate(p['reads']):
  marks=r['marks_ms'];required=['submitted','worker_started','worker_completed','coroutine_resumed','wrapper_returned']
  miss=[k for k in required if k not in marks]
  if miss:missing.append({'cycle':p['cycle'],'read_index':i,'missing':miss})
  else:readrows.append({'cycle':p['cycle'],'read_index':i,'read':r['read'],
   'actual_resume_ms':marks['coroutine_resumed']-marks['worker_completed'],'marks_ms':marks})
 queries_work += [('cycle',p.get('callback_work',{}))]+[('read_resume',r) for r in p.get('read_resume_work',[])]
trace_result={'selected_cycles':len(selected),'selected_reads':len(readrows),'missing_required_marks':missing,
 'omitted_reads':sum(e['payload']['reads_omitted'] for e in selected),
 'max_actual_resume':max(readrows,key=lambda r:r['actual_resume_ms']) if readrows else None,
 'cycles':[ref(e) for e in selected],'read_details':readrows,
 'whole_cycle_work_omitted_details':sum(w.get('omitted_spans',0) for k,w in queries_work if k=='cycle'),
 'read_resume_work_omitted_details':sum(w.get('omitted_spans',0) for k,w in queries_work if k=='read_resume'),
 'work_retention_loss':[(k,w.get('start_mono'),w.get('end_mono')) for k,w in queries_work if w.get('retention_loss')],
 'work_disabled':[(k,w.get('error')) for k,w in queries_work if not w.get('enabled')],
 'bin_retention_loss':[(k,w.get('start_mono')) for k,w in queries_work if w.get('all_sync_work_lower_bound',{}).get('retention_loss')]}

statuses=subset('speeddesk_live_status');statuses.sort(key=lambda e:e['payload']['at'])
intervals=[]
for prev,cur in zip(statuses,statuses[1:]):
 a,b=prev['payload']['at'],cur['payload']['at']
 if a<END and b>=START:
  intervals.append({'start':a,'end':b,'start_log':prev['timestamp'],'end_log':cur['timestamp'],
    'fully_contained':a>=START and b<=END,'loop':cur['payload']['loop'],
    'counts':cur['payload']['reconcile_trace']['counts'],
    'trace_enabled':cur['payload']['reconcile_trace']['enabled'],
    'buffered':cur['payload']['reconcile_trace'].get('buffered'),
    'buffer_dropped':cur['payload']['reconcile_trace'].get('buffer_dropped')})
lagrows=[(i,i['loop']['ms'].get('event_loop_lag',{})) for i in intervals]
boundary_before=max((e for e in statuses if e['payload']['at']<START),key=lambda e:e['payload']['at'])
endpoint_before=max((e for e in statuses if e['payload']['at']<END),key=lambda e:e['payload']['at'])
endpoint_after=min((e for e in statuses if e['payload']['at']>=END),key=lambda e:e['payload']['at'])
latest=statuses[-1]
statuses_result={'covering_intervals':len(intervals),'fully_contained_intervals':sum(i['fully_contained'] for i in intervals),
 'coverage_start':intervals[0]['start'],'coverage_end':intervals[-1]['end'],
 'max_lag_ms':max(l.get('max_ms',0) for i,l in lagrows),
 'max_lag_sample_count':max(l.get('n',0) for i,l in lagrows),
 'any_sample_cap_hit':any(v.get('n',0)>=8192 for i in intervals for v in i['loop']['ms'].values()),
 'intervals':intervals,'before_start':ref(boundary_before),'before_end':ref(endpoint_before),
 'after_end':ref(endpoint_after),'latest_tail_status':ref(latest)}
publication=[]
for e in [boundary_before,endpoint_before,endpoint_after,latest]:
 p=e['payload'];t=p['reconcile_trace'];counts=t['counts']
 expected=counts['reported'];cohort=[x for x in traces if x['payload']['cycle']<=counts['cycles']]
 publication.append({'status_log':e['timestamp'],'counts':counts,'completed_equals_begun':counts['cycles']==counts['quiet']+counts['reported']+counts['suppressed'],
  'published_rows_for_started_cohort':len(cohort),'expected_reported':expected,'published_matches':len(cohort)==expected,
  'buffered':t['buffered'],'buffer_dropped':t['buffer_dropped'],'enabled':t['enabled']})
guard_keys=['authenticated','fee_precision_verified','real_orders_available','total_halted','day_stop_latched','integrity_error','cleanup_pending','caps']
guard_rows=[e for e in statuses if START<=e['payload']['at']<=latest['payload']['at']]
financial['guard_observations']={'status_rows':len(guard_rows),'values':{k:list({json.dumps(e['payload'].get(k),sort_keys=True) for e in guard_rows}) for k in guard_keys},
 'scope':'Periodic status observations; no claim of continuous proof from snapshots.'}
source_dir=Path('/workspace/nightcrawler-next-evidence')
source_paths=['src/nightcrawler/speeddesk_readtrace.py','src/nightcrawler/speeddesk_worktrace.py','src/nightcrawler/speeddesk_live.py','src/nightcrawler/speeddesk_kalshi_ws.py','src/nightcrawler/speeddesk.py','src/nightcrawler/weatherwatch_markets.py']
source_hashes={p:sha((source_dir/p).read_bytes()) for p in source_paths}
derived_path=ROOT/'ws-timing-production-derived.json';derived_raw=derived_path.read_bytes();derived=json.loads(derived_raw)
independent_first={(e['timestamp'],e['original_message']) for e in events if log_inside(e)}
derived_first={(e['timestamp'],e['original_message']) for e in derived['original_events'] if log_inside(e)}
comparison={'derived_sha256_at_comparison':sha(derived_raw),'independent_first_window_event_count':len(independent_first),
 'derived_first_window_event_count':len(derived_first),'missing_in_derived':len(independent_first-derived_first),
 'extra_in_derived':len(derived_first-independent_first),
 'missing_event_counts':dict(Counter(e['event'] for e in events if (e['timestamp'],e['original_message']) in independent_first-derived_first)),
 'note':'Original row population compared independently. Heuristic diagnostic/warning joins are not proven shared-producer identities.'}
assert not parse_errors and not fill_conflicts
assert all(not q['cap_hit'] and not q['isError'] and q['artifact_sha_matches'] for q in queries)
assert all(all(j[k] for k in ['intent_found','accepted_order_found']) for j in joins)
assert len(settlements)==1 and all(financial['settlement_checks'].values())
assert all(p['published_matches'] and p['completed_equals_begun'] for p in publication)
output={'task':'EXEC-DELAY-001 independent first fixed window audit','state':'first_window_closed_with_bounded_tail_second_window_active',
 'input_file':str(SOURCE),'input_sha256':sha(raw),'input_bytes':len(raw),'source_assignment':capture['assignment'],
 'collector_complete_at_snapshot':capture['complete'],'collector_jobs_running_at_snapshot':capture['collector_jobs_running'],
 'window_start_utc':'2026-10-15T04:15:00Z','window_end_utc':'2026-10-15T04:30:00Z','publication_tail_received_through':'2026-10-15T04:33:00Z',
 'queries':queries,'raw_unique_rows':len(seen),'exact_duplicate_rows':duplicates,'parsed_original_events':len(events),
 'parse_errors':parse_errors,'financial':financial,'freshness':freshness,'read_trace':trace_result,'status_intervals':statuses_result,
 'publication_cohorts':publication,
 'source_hashes':source_hashes,'collector_derived_population_comparison':comparison,
 'limits':['Finite filtered logs, not raw market tape or ledger export.','Unknown shared-producer gaps are not BTC-specific.',
 'Selected read marks and interval lag populations differ; no pooled quantiles or cumulative-max subtraction.',
 'Nested work and quiet-bin coverage overlap; omitted scopes must not be added.',
 'Only first fixed window audited here; second window and final04:47tail remain active.']}
OUT=ROOT/'ws-timing-first-window-audit.json';OUT.write_text(json.dumps(output,indent=2,allow_nan=False)+'\n')
print(json.dumps({'output':str(OUT),'sha256':sha(OUT.read_bytes()),'queries':len(queries),'errors':len(parse_errors),
 'financial':{k:v for k,v in financial.items() if k not in ['fills','orders','cancels','settlements']},
 'timing':{k:v for k,v in freshness.items() if k not in ['main_known_gap_rows','unidentified_known_gap_rows','gap_originals','other_feed_warnings']},
 'read':{k:v for k,v in trace_result.items() if k not in ['cycles','read_details']},
 'statuses':{k:v for k,v in statuses_result.items() if k not in ['intervals','before_start','before_end','after_end','latest_tail_status']},
 'publication':publication},indent=2))
