"""Close only after assigned fixed-tail request and complete uncapped response coverage."""
from datetime import datetime,timezone
import hashlib,json,os,subprocess
from pathlib import Path
root=Path('/workspace/shared');plan_path=root/'ws-timing-production-plan.json';plan=json.loads(plan_path.read_text())
def utc(v): return datetime.fromisoformat(v.replace('Z','+00:00')).timestamp()
now=datetime.now(timezone.utc)
assert now.timestamp()>=utc(plan['assignment']['publication_tail_end_utc'])+10
queries=[json.loads(p.read_text()) for p in sorted(root.glob('ws-timing-production-query-*.json'))]
intervals=[];errors=[];caps=[]
for q in queries:
 requested=q['queried_at'].replace(' UTC','Z').replace(' ','T')
 assert utc(q['query']['endDate'])<=utc(requested)-10,(q['label'],'past_lag_guard')
 assert 0<utc(q['query']['endDate'])-utc(q['query']['startDate'])<=180
 r=q['response'];s=r.get('structuredContent',{});rows=s.get('deploy')
 if r.get('isError') or not isinstance(rows,list): errors.append(q['label']);continue
 if s.get('deploymentId')!=plan['scope']['deploymentId'] or s.get('serviceId')!=plan['scope']['serviceId'] or s.get('environmentId')!=plan['scope']['environmentId'] or s.get('status')!='SUCCESS': errors.append(q['label']+':scope_or_status');continue
 if len(rows)>=500: caps.append(q['label']);continue
 intervals.append((utc(q['query']['startDate']),utc(q['query']['endDate'])))
assert not errors,errors
expected_start=utc(plan['assignment']['restart_partial_start_utc']);expected_end=utc(plan['assignment']['publication_tail_end_utc'])
reach=expected_start;gaps=[]
for start,end in sorted(intervals):
 if start>reach: gaps.append((reach,start))
 reach=max(reach,end)
assert not gaps and reach>=expected_end,(gaps,reach,expected_end)
assert all(end<=expected_end for start,end in intervals)
checks={'query_count':len(queries),'capped_parent_queries':caps,'uncapped_leaf_coverage_start':plan['assignment']['restart_partial_start_utc'],'uncapped_leaf_coverage_end':plan['assignment']['publication_tail_end_utc'],'continuous_uncapped_query_coverage':True,'all_exact_scope_SUCCESS':True,'query_errors':errors,'fixed_windows_preserved':True,'collection_completed_not_execution_task_completed':True}
plan['state']='closed_fixed_bounded_capture';plan['collection_closed_at_utc']=now.isoformat();plan['remaining_chunks']=[];plan['closure_checks']=checks
plan_path.write_text(json.dumps(plan,indent=2)+'\n')
subprocess.run(['/workspace/shared/nightcrawler-venv/bin/python','-B','/workspace/shared/ws-timing-production-refresh.py'],check=True,stdout=subprocess.DEVNULL)
source=root/'ws-timing-production-capture.json';capture=json.loads(source.read_text());capture['closure_checks']=checks;capture['collection_closed_at_utc']=now.isoformat();capture['scheduled_queries_finished']=True;capture['collector_jobs_running']=False
source.write_text(json.dumps(capture,indent=2)+'\n')
final=root/'ws-timing-production-closed-complete.json'
with final.open('x') as stream: stream.write(source.read_text())
manifest={'closed_artifact':str(final),'bytes':final.stat().st_size,'sha256':hashlib.sha256(final.read_bytes()).hexdigest(),'closed_at_utc':now.isoformat(),'checks':checks,'artifacts':{}}
for p in sorted(root.glob('ws-timing-production-query-*.json')):
 manifest['artifacts'][str(p)]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
for name in ['ws-timing-production-parser.py','ws-timing-production-refresh.py','ws-timing-production-finalize.py','ws-timing-production-plan.json']:
 p=root/name;manifest['artifacts'][str(p)]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(root/'ws-timing-production-closed-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'final':str(final),'sha256':manifest['sha256'],'bytes':manifest['bytes'],'queries':len(queries),'closed_at_utc':now.isoformat(),'no_queries_scheduled':True}))
