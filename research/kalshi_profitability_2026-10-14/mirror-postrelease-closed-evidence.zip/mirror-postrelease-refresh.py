from __future__ import annotations
import hashlib,json,os
from datetime import datetime,timezone
from pathlib import Path
import importlib.util
spec=importlib.util.spec_from_file_location('ws_parser','/workspace/shared/mirror-postrelease-parser.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
root=Path('/workspace/shared');plan=json.loads((root/'mirror-postrelease-plan.json').read_text())
queries=[]
for p in sorted(root.glob('mirror-postrelease-query-*.json')):
 q=json.loads(p.read_text());q['artifact']=str(p);q['artifact_sha256']=hashlib.sha256(p.read_bytes()).hexdigest();q['response_canonical_sha256']=hashlib.sha256(json.dumps(q['response'],sort_keys=True,separators=(',',':')).encode()).hexdigest();queries.append(q)
plan['production_queries_executed']=len(queries)
plan['remaining_chunks']=[chunk for chunk in plan.get('remaining_chunks',[]) if not any(q['query']['startDate']==chunk['start_utc'] and q['query']['endDate']==chunk['end_utc'] for q in queries)]
(root/'mirror-postrelease-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
closed=bool(plan.get('collection_closed_at_utc'))
capture={'schema_version':1,'task':'EXEC-DELAY-001','state':'closed_fixed_bounded_capture' if closed else plan['state'],'complete':closed,'scope':plan['scope'],'assignment':plan['assignment'],'queries':queries,'last_persisted_at':datetime.now(timezone.utc).isoformat(),'collector_jobs_running':not closed,'limitations':plan['limitations'],'root_health_references':plan.get('root_health_references',[]),'root_restart_audit_references':plan.get('root_restart_audit_references',[])}
for name,obj in [('mirror-postrelease-capture.json',capture),('mirror-postrelease-derived.json',module.derive(capture))]:
 target=root/name;temporary=root/(name+'.tmp');temporary.write_text(json.dumps(obj,indent=2)+'\n');os.replace(temporary,target)
derived=module.derive(capture)
latest=queries[-1]['label'] if queries else None
recent_ids={e['id'] for e in derived['original_events'] if any(r['label']==latest for r in e['query_refs'])}
recent=[t for t in derived['timing_samples'] if t['event']=='gap' and t['event_id'] in recent_ids]
compact=[]
for t in sorted(recent,key=lambda row:(row.get('reader_identity',{}).get('kind')!='speeddesk',not isinstance(row.get('local_work'),dict),row['timestamp']))[:1]:
 w=t.get('local_work');compact.append({k:v for k,v in t.items() if k!='local_work'} | {'local_work_keys':list(w) if isinstance(w,dict) else None})
print(json.dumps({'queries':len(queries),'latest_label':latest,'unique_original_events':len(derived['original_events']),'total_timing_samples':len(derived['timing_samples']),'total_gap_timing_samples':sum(t['event']=='gap' for t in derived['timing_samples']),'recent_gap_timing_samples':len(recent),'recent_prioritized_gap':compact,'total_warning_rows':len(derived['gap_warnings']),'cap_hits':sum(q['cap_hit'] for q in derived['queries']),'parse_response_errors':len(derived['parse_or_response_errors'])}))
