"""Package only the finite, closed capture and already-frozen audit originals."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import zipfile

root = Path('/workspace/shared')
closed = json.loads((root / 'mirror-postrelease-closed-manifest.json').read_text())
paths = [Path(p) for p in closed['artifacts']]
paths += [Path(closed['closed_artifact']), root / 'mirror-postrelease-closed-manifest.json']
paths += [root / name for name in [
    'mirror-postrelease-midcapture-health.json',
    'mirror-postrelease-resource-context.json',
    'mirror-recorder-0500-manifest-query.json',
    'live-mirror-restart-audit.json', 'live-mirror-restart-audit.md',
    'mirror-capture-root-verification.json',
    'mirror-postrelease-first-window-audit-input.json',
    'mirror-postrelease-first-window-audit-parser.py',
    'mirror-postrelease-first-window-audit.json',
    'mirror-postrelease-first-window-audit.md',
    'mirror-postrelease-two-window-audit-input.json',
    'mirror-postrelease-two-window-audit.py',
    'mirror-postrelease-two-window-audit.json',
    'mirror-postrelease-two-window-audit.md',
    'package-mirror-postrelease.py',
]]
paths = list(dict.fromkeys(paths))
assert len({p.name for p in paths}) == len(paths)
assert all(p.is_file() for p in paths)
secret_patterns = [
    rb'\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{20,}',
    rb'\bjup_[A-Za-z0-9_-]{20,}',
    rb'-----BEGIN (?:RSA |EC |ENCRYPTED )?PRIVATE KEY-----',
    rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})',
]
archive = root / 'mirror-postrelease-closed-evidence.zip'
assert not archive.exists(), 'Do not silently replace an existing evidence archive'
members = []
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in paths:
        b = p.read_bytes()
        for pattern in secret_patterns:
            assert not re.search(pattern, b), f'Credential-pattern finding in {p.name}; value omitted'
        z.writestr(p.name, b)
        members.append({'member': p.name, 'original_path': str(p), 'bytes': len(b),
                        'sha256': hashlib.sha256(b).hexdigest()})
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert set(z.namelist()) == {m['member'] for m in members}
    for p, m in zip(paths, members):
        b = z.read(m['member'])
        assert b == p.read_bytes()
        assert hashlib.sha256(b).hexdigest() == m['sha256']
manifest = {'saved_at_utc': datetime.now(timezone.utc).isoformat(),
            'archive': archive.name, 'archive_bytes': archive.stat().st_size,
            'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'crc_ok': True, 'all_member_bytes_equal_originals': True,
            'credential_pattern_findings': 0,
            'scope': 'Closed fixed-window evidence; not complete raw venue/ledger exports or a profitability claim.',
            'members': members}
(root / 'mirror-postrelease-closed-evidence.manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({k: v for k, v in manifest.items() if k != 'members'}, indent=2))
print('members', len(members))
