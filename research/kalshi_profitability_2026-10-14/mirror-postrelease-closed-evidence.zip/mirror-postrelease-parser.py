"""Read-only original-event parser for frozen bounded Railway captures.
CLI: parser.py INPUT_CAPTURE OUTPUT_DERIVED
Input has queries[{label,query,queried_at,received_at,response}] preserving MCP responses.
No network, source edits, financial state mutation or token handling.
"""
from __future__ import annotations
from collections import Counter
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import sys

ANCHOR=re.compile(r'^(?P<source_wall_utc>\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?Z)\s+(?:DEBUG|INFO|WARNING|ERROR|CRITICAL)\s+(?P<logger>nightcrawler[\w.]*):\s+(?P<event>[a-zA-Z_][a-zA-Z_0-9]*)(?:\s+(?P<body>.*))?$')
PREFIXES=('speeddesk_live','speeddesk_reconcile_trace','speeddesk_fill','speeddesk_feed','speeddesk_callback')
TIMING='speeddesk_feed_kalshi_ws_timing'
READER_TOKENS=re.compile(r'\breader_kind=(?P<kind>\S+)\s+reader_instance=(?P<instance>\S+)\s+reader_process=(?P<process>\S+)\s+reader_session=(?P<session>\S+)')
def identity(kind,instance,process,session,deployment):
    valid_kind=kind in {'speeddesk','derived_market_reader'}
    positive=lambda value:isinstance(value,int) and not isinstance(value,bool) and value>0
    reader_valid=valid_kind and positive(instance) and positive(process)
    return {'kind':kind if valid_kind else None,'instance':instance if positive(instance) else None,'process':process if positive(process) else None,'session':session if positive(session) else None,'deploymentId':deployment,'reader_valid':reader_valid,'session_valid':positive(session),'identity_complete':reader_valid and positive(session),'scope_limit':'Observed deployment/process/reader/session tuple; not global identity across replicas or process reincarnations.'}
def warning_identity(body,deployment):
    match=READER_TOKENS.search(body)
    if not match:return identity(None,None,None,None,deployment)
    number=lambda value:int(value) if value.isdecimal() else None
    return identity(match['kind'],number(match['instance']),number(match['process']),number(match['session']),deployment)
def identity_key(value):
    return tuple(value.get(field) for field in ['deploymentId','kind','process','instance','session']) if value.get('identity_complete') else None
GAP='speeddesk_feed_kalshi_ws_gap'
DOMAIN=re.compile(r'reason=timestamp_missing_or_stale:(?P<domain>[a-z_]+):(?:(?:age_s=(?P<age>-?\d+(?:\.\d+)?))|(?P<missing>missing_or_invalid))')
def utc(value): return datetime.fromisoformat(value.replace('Z','+00:00')).timestamp()
def finite_number(value):
    import math
    return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value)
def validate_query(query,queried_at):
    """Call BEFORE each runtime request; no future end, missing deployment or broad query."""
    assert query['deploymentId'] and query['serviceId'] and query['environmentId'] and query['projectId']
    assert query['types']==['deploy'] and query['limit']==500
    assert utc(query['endDate'])<=utc(queried_at)-10,'Publication lag must be at least ten seconds'
    assert 0<utc(query['endDate'])-utc(query['startDate'])<=180,'Use bounded3minute-or-shorter chunks'
    assert 'filter' in query and query['filter']

def derive(capture):
    events={}; errors=[]; discarded=Counter(); query_counts=[]
    deployment=capture.get('scope',{}).get('deploymentId')
    for query in capture.get('queries',[]):
        response=query.get('response',{})
        structured=response.get('structuredContent',{}) or {}
        rows=structured.get('deploy')
        if rows is None:
            errors.append({'label':query['label'],'error':'structured_deploy_array_missing','isError':response.get('isError')})
            rows=[]
        query_counts.append({'label':query['label'],'rows':len(rows),'cap_hit':len(rows)>=500,
                             'queried_at':query.get('queried_at'),'received_at':query.get('received_at'),
                             'query':query['query'],'isError':response.get('isError',False)})
        for index,row in enumerate(rows):
            message=row.get('message','')
            match=ANCHOR.fullmatch(message)
            if not match:
                discarded['unmatched_original_prefix']+=1
                continue
            event=match['event']
            if not event.startswith(PREFIXES):
                discarded[event]+=1
                continue
            key=hashlib.sha256((str(row.get('timestamp'))+'\0'+message).encode()).hexdigest()
            if key in events:
                events[key]['query_refs'].append({'label':query['label'],'row_index':index})
                continue
            payload=None; body=match['body'] or ''
            if body.startswith('{'):
                try: payload=json.loads(body)
                except (ValueError,TypeError) as exc:
                    errors.append({'label':query['label'],'row_index':index,'event':event,'error':str(exc)})
            events[key]={'id':key,'timestamp':row.get('timestamp'),'source_wall_utc':match['source_wall_utc'],
                         'logger':match['logger'],'event':event,'payload':payload,'body':body,
                         'original_message':message,'query_refs':[{'label':query['label'],'row_index':index}],
                         'financial_population':('real_venue_fill' if event=='speeddesk_live_fill' else
                            'real_settlement' if event=='speeddesk_live_settlement' else
                            'real_order_event' if event=='speeddesk_live_order' else
                            'practice_fill' if event=='speeddesk_fill' else 'other')}
    ordered=sorted(events.values(),key=lambda e:(e['timestamp'],e['id']))
    diagnostics=[]; warning_events=[]; populations=Counter()
    for e in ordered:
        populations[e['event']]+=1
        if e['event']==TIMING and isinstance(e['payload'],dict):
            p=e['payload']; receipt=p.get('receipt') or {}; conn=p.get('connection') or {}
            applied=p.get('apply_wall')
            reader=p.get('reader') if isinstance(p.get('reader'),dict) else {}
            reader_id=identity(reader.get('kind'),reader.get('instance'),reader.get('process'),p.get('session'),deployment)
            item={'event_id':e['id'],'timestamp':e['timestamp'],'session':p.get('session'),
                  'reader_identity':reader_id,'event':p.get('event'),'kind':p.get('kind'),'receipt_status':receipt.get('status','missing'),
                  'ordinal':receipt.get('ordinal'),'residence_ms':receipt.get('residence_ms'),
                  'return_to_apply_ms':p.get('return_to_apply_ms'),'recv_wait_ms':p.get('recv_wait_ms'),
                  'previous_message':p.get('previous_message'),'connection':conn,
                  'source_ages_at_apply_s':{},'local_work':p.get('local_work'),
                  'producer_attribution':(reader_id['kind'] if reader_id['reader_valid'] else 'unknown_legacy_or_invalid_identity'),
                  'known_local_lower_bound_ms':receipt.get('residence_ms') if receipt.get('status')=='known' else None,
                  'limits':'Local protocol residence excludes earlier local/kernel/provider/network delay; work spans must not be summed.'}
            for field in ['sending_ts_ms','engine_ts_ms']:
                value=p.get(field)
                item['source_ages_at_apply_s'][field]=(applied-value/1000 if finite_number(applied) and finite_number(value) else None)
            diagnostics.append(item)
        if e['event']==GAP:
            m=DOMAIN.search(e['body'])
            warning_events.append({'event_id':e['id'],'timestamp':e['timestamp'],'reason':e['body'],
                'classification':'source_timestamp' if m else 'market_transition' if 'market_set_changed' in e['body'] else 'other',
                'reader_identity':warning_identity(e['body'],deployment),
                'domain':m['domain'] if m else None,'rounded_age_s':float(m['age']) if m and m['age'] else None,
                'matching_timing_event_ids':[]})
    # A warning is logged after close; select earlier incident reports only if
    # kind/domain and source age rounded to the logged millisecond agree.
    # Retain ambiguous or absent joins rather than assigning by time alone.
    for warning in warning_events:
        if warning['classification']!='source_timestamp': continue
        warning_key=identity_key(warning['reader_identity'])
        if warning_key is None:
            warning['join_state']='reader_or_session_identity_missing'
            continue
        domain=warning['domain']; field='sending_ts_ms' if domain.endswith('_network') else 'engine_ts_ms'
        kind=domain.removesuffix('_network').removesuffix('_engine')
        for item in diagnostics:
            if identity_key(item['reader_identity'])!=warning_key:continue
            age=item['source_ages_at_apply_s'].get(field)
            dt=utc(warning['timestamp'])-utc(item['timestamp'])
            kind_matches=(item['kind'] in {'orderbook_snapshot','orderbook_delta'} if kind=='book' else item['kind']==kind)
            if item['event']!='gap' or not kind_matches or not 0<=dt<=30: continue
            expected=warning['rounded_age_s']
            if expected is None:
                matches=age is None
            else:
                matches=age is not None and abs(age-expected)<=.000501
            if matches: warning['matching_timing_event_ids'].append(item['event_id'])
        warning['join_state']=('matched_unique' if len(warning['matching_timing_event_ids'])==1 else
                               'ambiguous' if warning['matching_timing_event_ids'] else 'missing')
    return {'schema_version':1,'state':capture.get('state'),'scope':capture.get('scope'),
            'assignment':capture.get('assignment'),'queries':query_counts,'original_events':ordered,
            'event_counts':dict(populations),'discarded_original_prefix_counts':dict(discarded),
            'parse_or_response_errors':errors,'timing_samples':diagnostics,'gap_warnings':warning_events,
            'unknown_receipt_counts':dict(Counter(i['receipt_status'] for i in diagnostics)),
            'limits':['Exact original logger/event anchors only; no recursive traversal into latest_events/status payloads.',
                      'Original financial events retained separately; no inferred profit or fees/pair credits counted twice.',
                      'Session counters are samples without guaranteed final totals; missing/evicted/disabled remains unknown.',
                      'Explicit reader kind/instance/process/session are parsed independently in timing and warnings. Joins require the same complete tuple plus source domain/kind/age/time; no legacy producer or current session is inferred. Deployment/process-incarnation scope is still required.',
                      'Incident matching requires complete reader tuple, source domain/kind/rounded age and earlier30second context; ambiguous/missing identities remain unresolved.',
                      'A small local residence cannot assign remainder to provider or establish full freshness coverage.']}

if __name__=='__main__':
    assert len(sys.argv)==3,'Need INPUT_CAPTURE OUTPUT_DERIVED'
    source=Path(sys.argv[1]); target=Path(sys.argv[2])
    assert str(target).startswith('/workspace/shared/mirror-postrelease')
    result=derive(json.loads(source.read_text()))
    result['source_artifact']=str(source)
    result['source_sha256']=hashlib.sha256(source.read_bytes()).hexdigest()
    result['parser_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'output':str(target),'events':len(result['original_events']),
                      'query_cap_hits':sum(q['cap_hit'] for q in result['queries']),
                      'errors':len(result['parse_or_response_errors']),'counts':result['event_counts']}))
