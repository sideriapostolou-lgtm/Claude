# Independent first post-PR58 fixed-window audit

Finite intermediate audit only. The 05:00–05:15 UTC (22:00–22:15 PDT) window is closed, and saved original queries extend through05:18. The second05:15–05:30 window remains active; the assigned combined capture is not complete. No production queries or source changes were made for this audit.

Source `1e8d0be07b280292fa873a2f5da9b22dd02f28c3`, deployment `fc0a73e9-f052-435a-94b2-ce7b1272f36e`. Immutable input SHA256 `06514819e7bf71cc53a0b3b9f9cd56f9a38799581b628a6f2d68172d71a072e8`; 9,516,134bytes,10contiguous original query responses,834unique original rows,0duplicates/parse failures. Each query is below its500-row cap and each saved response artifact hash matches. The independent parser retains16 original rows excluded by the collector-derived window population (15speeddesk_status,1speeddesk_twin); derived summaries are not the audit authority.

## Actual logged financial result

Fixed ticker `KXBTC15M-26OCT150115-15`: **−$1.59**, cost$9.59, fees$0,13Up/8Down shares, Down settled winner. Eight paired shares paid$8; the unpaired5Up paid$0. Logged locked component+$0.6792307692 and directional component−$2.2692307692 sum to−$1.59. This single window is also the worst settled window in this intermediate report. These components are the model's average-cost allocation, not a separately realized arbitrage return.

Five distinct maker fills join exact client/order IDs to40durable intents and40accepted orders. All five joins match side, remain within the buy limit, and have aggregate filled quantity within intended size. Five accepted orders filled:12.5%; this is an order-level rate, not a prediction win rate. Logged fill quantities/cost/fees reconcile to the unique settlement published05:15:06.647204136. The original venue/ledger exports were not queried; this is consistency of the retained original application records.

| Fill side | Size | Price | Cost |
|---|---:|---:|---:|
| Up |5|0.46|2.30|
| Down |5|0.48|2.40|
| Up |3|0.50|1.50|
| Down |3|0.43|1.29|
| Up |5|0.42|2.10|

The+$1.11 settlement published05:00:07.913777506 belongs prior/restart ticker `KXBTC15M-26OCT150100-00` and is excluded. Next-window fills in the tail are also excluded by exact ticker. Cumulative account P&L and consumed resume anchors are not used to infer this window's result or a budget-stop failure.

Periodic status observations through the tail retain clip5/open20/window10/day-stop6/total-stop10, authenticated and fee_precision_verified true, total_halted/day_stop_latched false, integrity_error null, cleanup_pending false. These observations do not prove continuous readiness or reveal the consumed financial stop anchors.

## Coarse account responsiveness

All four selected reconcile cycles overlapping the fixed interval (427,620,628,633), including any straddlers, contain20reads with required marks and no omitted reads. Largest measured worker-completed→coroutine-resumed delay is420.597ms (cycle628,balance), below the3000ms coarse criterion. Sixteen adjacent status intervals cover the fixed window, including both boundaries; largest covering event-loop lag997.7ms. Fourteen intervals are wholly contained. No missing lag interval or8192-sample cap is observed. Selected WorkTrace records report no omitted details, disabled observer, retention loss or bin loss. This is bounded recorded coverage, not a full WebSocket-latency guarantee.

Publication cohorts are time-indexed, not differences of cumulative maxima: preceding endpoint04:59:52 cycles404=395quiet+9reported; before-end05:14:46 cycles1000=987quiet+13reported; after-end05:15:46 cycles1041=1025quiet+16reported; tail05:17:46 cycles1129=1109quiet+20reported. All four report0active/unfinished,suppressed,buffered and dropped; original published rows for each started cohort match reported counts. No counter reset is observed. Cohorts include startup and tail; they are not themselves fixed-window counts.

## Source freshness remains unresolved

Within the fixed log-time interval there are20source-age/invalid-timestamp warnings (18orderbook_delta_network,2trade_network), plus1market_set_changed warning. There are separately20gap diagnostics and29periodic/status diagnostics. Every identified producer in these populations is explicit `speeddesk`,instance1,PID1, scoped to this deployment and verified startup incarnation. No derived-weather or unidentified producer occurs in this window. Matching explicit reader/session identifies candidate warning/diagnostic joins; warning and diagnostic log-time populations remain separate.

Eighteen gap receipts are overflow-unknown. Two exact main-reader known receipts prove local protocol-acceptance→public-recv residence:

| Original diagnostic UTC | Known residence ms | Full-bin synchronous-work lower bound ms | Retained full bins | Detail coverage |
|---|---:|---:|---:|---:|
|05:01:46.361504349|2895.428|2212.684|92/92|8/62slow spans|
|05:05:56.818036002|2890.691|1899.181|92/92|8/49slow spans|

The first incident includes practice_daily_reports255.766ms wall/247.091ms threadCPU nested inside practice_checkpoint461.188ms; the second includes live_checkpoint363.577ms with live_ledger188.773ms wall/40.373ms threadCPU. Repeated practice work also overlaps. Nested detail durations and bin lower bounds must not be added. Missing54/41slow details and unassigned/boundary portions remain; none of these figures partitions the full delay into exclusive causes. Ledger wall is not serialization CPU, and no next correction is selected here.

Provider sending/engine integer timestamp samples and their types are retained separately in JSON. Provider age does not measure receipt. Known acceptance omits earlier kernel/network/provider/local delay; overflow does not prove preacceptance delay or absence of local delay. Connection counters/maxima are per-reader/session samples, not final totals. No whole-feed coverage, pooled before/after causal estimate, or EXEC-DELAY-001 clearance follows.

## Scoped real-order latency

Each metric uses40original exact-ticker real_kalshi samples; no status median pooling: BTC exchange→decision median202.231ms/max662.100ms; BTC callback receipt→decision101.141/628.154ms; decision→ack84.252/696.443ms. Provider/local clock uncertainty and callback-vs-network receipt boundaries remain. These intent/ack samples do not substitute for venue fill waiting or for rejected stale-message coverage.

## Reproduction and receipts

Saved JSON: `/workspace/shared/mirror-postrelease-first-window-audit.json` SHA256 `b7b91189af5b5e65452615cffdc9b89eb516db8ea176071265619a4dce907fda`.
Immutable raw input: `/workspace/shared/mirror-postrelease-first-window-audit-input.json` SHA256 `06514819e7bf71cc53a0b3b9f9cd56f9a38799581b628a6f2d68172d71a072e8`.
Frozen parser: `/workspace/shared/mirror-postrelease-first-window-audit-parser.py` SHA256 `9935bdb43b75ea696596dac518a95af85ed5ba365d43adc1d8cee96419b4fc54`.
For offline replay, import the frozen parser with importlib and call `audit_window(Path("/workspace/shared/mirror-postrelease-first-window-audit-input.json"),1792040400,1792041300,"KXBTC15M-26OCT150115-15")`. The command-line `--first` entry point intentionally refuses replacement once the active capture differs from this immutable input. The stored derived-comparison hash is an observation of the derived artifact at audit time; a replay against a later derived artifact changes only that comparison. Later final audit must preserve this intermediate input/report and compare any late first-window events explicitly.
