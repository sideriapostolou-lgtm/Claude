"""Independent finite first-window audit of saved original tool responses only."""
from __future__ import annotations
import hashlib,json,re,subprocess,sys,statistics
from collections import Counter
from datetime import datetime,timezone
from decimal import Decimal
from pathlib import Path

def audit_window(capture_path,start,end,expected_ticker):
 ROOT=Path('/workspace/shared')
 SOURCE=capture_path
 raw=SOURCE.read_bytes(); capture=json.loads(raw)
 START=start
 END=end
 def stamp(s):return datetime.fromisoformat(s.replace('Z','+00:00')).timestamp()
 def sha(b):return hashlib.sha256(b).hexdigest()
 events=[];seen=set();duplicates=0;parse_errors=[];queries=[]
 pattern=re.compile(r'^(\S+) (?:INFO|WARNING|ERROR|DEBUG|CRITICAL) ([^:]+): (speeddesk_[A-Za-z_]+)(?: (.*))?$',re.S)
 for q in capture['queries']:
  response=q['response'];sc=response.get('structuredContent',{});rows=sc.get('deploy',[])
  artifact=Path(q['artifact'])
  queries.append({'label':q['label'],'query':q['query'],'received_at':q['received_at'],
   'rows':len(rows),'cap_hit':len(rows)>=q['query']['limit'],'isError':response.get('isError'),
   'artifact_sha_matches':artifact.exists() and sha(artifact.read_bytes())==q['artifact_sha256']})
  for row in rows:
   key=(row['timestamp'],row['message'])
   if key in seen:duplicates+=1;continue
   seen.add(key)
   match=pattern.match(row['message'])
   if not match:
    parse_errors.append({'timestamp':row['timestamp'],'reason':'prefix','message':row['message']});continue
   wall,logger,event,body=match.groups();body=body or ''
   payload=None
   if body.startswith('{'):
    try:payload=json.loads(body)
    except Exception as exc:parse_errors.append({'timestamp':row['timestamp'],'event':event,'reason':type(exc).__name__})
   events.append({'id':sha((row['timestamp']+'\0'+row['message']).encode()),'timestamp':row['timestamp'],
    'logger':logger,'source_wall':wall,'event':event,'payload':payload,'body':body,'original_message':row['message']})
 events.sort(key=lambda r:(r['timestamp'],r['id']))
 def subset(name):return [e for e in events if e['event']==name]
 def log_inside(e):return START<=stamp(e['timestamp'])<END
 def ref(e):return {'id':e['id'],'timestamp':e['timestamp'],'payload':e['payload']}
 
 # Fixed window identity is retained even if there are no observed decisions/fills.
 TICKER=expected_ticker
 window=lambda name:[e for e in subset(name) if isinstance(e['payload'],dict) and e['payload'].get('window')==TICKER]
 orders=window('speeddesk_live_order');intents=[e for e in orders if e['payload'].get('state','').startswith('durable intent')]
 accepted=[e for e in orders if e['payload'].get('state','').startswith('accepted;')]
 fills=window('speeddesk_live_fill');settlements=window('speeddesk_live_settlement');cancels=window('speeddesk_live_cancel')
 unique={};fill_conflicts=[]
 for e in fills:
  fid=e['payload']['fill_id']
  if fid in unique and unique[fid]['payload']!=e['payload']:fill_conflicts.append(fid)
  unique[fid]=e
 fills=list(unique.values());D=lambda x:Decimal(str(x))
 cost=sum((D(e['payload']['price'])*D(e['payload']['size']) for e in fills),Decimal(0))
 fees=sum((D(e['payload']['fee_usd']) for e in fills),Decimal(0))
 shares={side:sum((D(e['payload']['size']) for e in fills if e['payload']['side']==side),Decimal(0)) for side in ['up','down']}
 side_spent={side:sum((D(e['payload']['price'])*D(e['payload']['size'])+D(e['payload']['fee_usd']) for e in fills if e['payload']['side']==side),Decimal(0)) for side in shares}
 pairs=min(shares.values());averages={side:side_spent[side]/shares[side] if shares[side] else Decimal(0) for side in shares}
 locked=pairs*(Decimal(1)-sum(averages.values()))
 intent_map={e['payload']['client_order_id']:e for e in intents};accepted_map={e['payload']['order_id']:e for e in accepted}
 intent_ids=set(intent_map);accepted_ids=set(accepted_map);joins=[]
 for e in fills:
  f=e['payload'];i=intent_map.get(f['client_order_id']);o=accepted_map.get(f['order_id'])
  j={'fill_id':f['fill_id'],'intent_found':i is not None,'accepted_order_found':o is not None}
  if i is not None and o is not None:
   v=i['payload'];j.update(accepted_client_matches=o['payload']['client_order_id']==f['client_order_id'],
    intent_side_matches=v['side']==f['side'],fill_price_within_buy_limit=D(f['price'])<=D(v['price']),
    joined_fill_quantity_within_intent=sum(D(x['payload']['size']) for x in fills if x['payload']['client_order_id']==f['client_order_id'])<=D(v['size']))
  joins.append(j)
 filled_orders={e['payload']['order_id'] for e in fills};filled_clients={e['payload']['client_order_id'] for e in fills}
 financial={'ticker':TICKER,'ticker_evidence':'observed original real events' if orders or fills or settlements else 'expected fixed ticker only; no event proof',
  'real_fill_events':len(fills),'durable_intents':len(intent_ids),'accepted_orders':len(accepted_ids),'cancel_rows':len(cancels),
  'fill_conflicts':fill_conflicts,'cost_decimal':str(cost),'fee_decimal':str(fees),'shares_decimal':{k:str(v) for k,v in shares.items()},
  'worst_case_pnl_at_observed_exposure_decimal':str(min(shares.values())-cost-fees),
  'filled_orders':len(filled_orders),'filled_clients':len(filled_clients),
  'accepted_order_fill_rate':len(filled_orders&accepted_ids)/len(accepted_ids) if accepted_ids else None,
  'durable_intent_fill_rate':len(filled_clients&intent_ids)/len(intent_ids) if intent_ids else None,
  'fill_records_per_accepted_order':len(fills)/len(accepted_ids) if accepted_ids else None,
  'intent_kinds':dict(Counter(e['payload'].get('kind','unknown') for e in intent_map.values())),
  'fill_roles':dict(Counter('taker' if e['payload'].get('is_taker') is True else 'maker' if e['payload'].get('is_taker') is False else 'unknown' for e in fills)),
  'order_states':dict(Counter(e['payload'].get('state','missing') for e in orders)),
  'intents_without_accepted_row':sorted(intent_ids-{e['payload'].get('client_order_id') for e in accepted}),
  'fill_joins':joins,'fills':[ref(e) for e in fills],'orders':[ref(e) for e in orders],'cancels':[ref(e) for e in cancels],
  'settlements':[ref(e) for e in settlements], 'recomputed_pnl_decimal':None,'recomputed_payout_decimal':None,
  'settlement_checks':None,'financial_reconciliation_complete':False,
  'fee_inclusive_side_spent_decimal':{k:str(v) for k,v in side_spent.items()},
  'recomputed_average_cost_locked_decimal':str(locked),'recomputed_directional_decimal':None}
 financial['unaccepted_intent_resolution']=[{'client_order_id':key,
  'original_order_records':[ref(e) for e in orders if e['payload'].get('client_order_id')==key],
  'logged_not_sent':any(e['payload'].get('state','').startswith('not sent;') for e in orders if e['payload'].get('client_order_id')==key)}
  for key in financial['intents_without_accepted_row']]
 if len(settlements)==1:
  v=settlements[0]['payload'];payout=shares['up' if v['up_wins'] else 'down']
  financial['recomputed_payout_decimal']=str(payout);financial['recomputed_pnl_decimal']=str(payout-cost-fees)
  financial['recomputed_directional_decimal']=str(payout-cost-fees-locked)
  financial['settlement_checks']={
   'shares_match':all(abs(float(shares[k])-v[k+'_shares'])<1e-9 for k in shares),
   'cost_matches':abs(float(cost)-v['cost_usd'])<1e-9,'fees_match':abs(float(fees)-v['fee_usd'])<1e-9,
   'payout_matches':abs(float(payout)-v['payout_usd'])<1e-9,'pnl_matches':abs(float(payout-cost-fees)-v['pnl_usd'])<1e-9,
   'locked_plus_direction_matches':abs(v['locked_usd']+v['direction_usd']-v['pnl_usd'])<1e-9,
   'average_cost_locked_matches':abs(float(locked)-v['locked_usd'])<1e-9,
   'directional_matches':abs(float(payout-cost-fees-locked)-v['direction_usd'])<1e-9,
   'net_plus_paired_credit_matches':abs(v['net_payout_usd']+v['paired_credit_usd']-v['payout_usd'])<1e-9}
  financial['financial_reconciliation_complete']=not fill_conflicts and all(financial['settlement_checks'].values()) and all(all(v for k,v in j.items() if k!='fill_id') for j in joins)
 else:
  financial['limitation']='No unique published settlement. Zero observed fills alone is not proof of a completed no-trade window.'
 latency={};latency_samples=[]
 for e in orders:
  rows=e['payload'].get('timing',[]);rows=rows if isinstance(rows,list) else [rows]
  for row in rows:
   if isinstance(row,dict) and row.get('scope')=='real_kalshi':
    latency_samples.append({'event_id':e['id'],'client_order_id':e['payload'].get('client_order_id'),**row})
 for metric in sorted({r.get('metric','missing') for r in latency_samples}):
  rows=[r for r in latency_samples if r.get('metric','missing')==metric]
  vals=[r['value_ms'] for r in rows if r.get('status')=='ok' and type(r.get('value_ms')) in (int,float)]
  latency[metric]={'population':'original real intent/accepted-order timing rows for exact ticker; not lifetime status medians',
   'statuses':dict(Counter(r.get('status','missing') for r in rows)),'sample_count':len(vals),
   'median_ms':statistics.median(vals) if vals else None,'max_ms':max(vals) if vals else None}
 financial['scoped_latency']={'metrics':latency,'original_samples':latency_samples,
  'limits':['Provider/local clock uncertainty in exchange age.','Receipt timing starts at strategy callback, not network ingress.',
   'Decision-to-ack includes journal/queue/HTTP; venue fill waiting is not substituted.','No combined quantile is made from window summaries.']}
 timing=[e for e in subset('speeddesk_feed_kalshi_ws_timing') if log_inside(e)]
 gaps=[e for e in subset('speeddesk_feed_kalshi_ws_gap') if log_inside(e)]
 incarnation=capture['assignment']['verified_startup_time_utc']
 deployment=capture['assignment']['exact_SUCCESS_deploymentId']
 def producer(e):
  p=e['payload']
  if isinstance(p,dict):
   r=p.get('reader',{});session=p.get('session')
  else:
   m=re.search(r' reader_kind=(\S+) reader_instance=(\d+) reader_process=(\d+) reader_session=(\d+|None)$',e['body'])
   if not m:return None
   kind,instance,process,session=m.groups();r={'kind':kind,'instance':int(instance),'process':int(process)}
   session=None if session=='None' else int(session)
  if not isinstance(r,dict) or r.get('kind') not in ['speeddesk','derived_market_reader'] or type(r.get('instance')) is not int or type(r.get('process')) is not int:return None
  if session is not None and type(session) is not int:return None
  return {'deployment':deployment,'incarnation_anchor':incarnation,**r,'session':session}
 def pkey(e):
  r=producer(e);return json.dumps(r,sort_keys=True) if r else None
 def category(e):
  r=producer(e);return r['kind'] if r else 'unidentified'
 def gap_class(e):
  b=e['body'].split(' reader_kind=',1)[0]
  if 'timestamp_missing_or_stale:' in b:return 'source_age_or_invalid_timestamp'
  if 'market_set_changed' in b:return 'market_set_changed'
  if b=='reason=TimeoutError':return 'timeout'
  return 'other'
 main_known=[];derived_known=[];unidentified_known=[];typed_samples=[]
 for e in timing:
  p=e['payload'];r=p.get('receipt') or {};who=category(e)
  if p.get('event')=='gap' and r.get('status')=='known':
   (main_known if who=='speeddesk' else derived_known if who=='derived_market_reader' else unidentified_known).append(e)
  typed_samples.append({'event_id':e['id'],'timestamp':e['timestamp'],'reader':producer(e),'event':p.get('event'),'kind':p.get('kind'),
   'receipt_status':r.get('status'),'residence_ms':r.get('residence_ms'),'receipt':r,
   'source_clocks':{key:{'type':type(p.get(key)).__name__,'raw_value':p.get(key),
    'age_at_apply_s':p['apply_wall']-p[key]/1000 if type(p.get(key)) is int else None} for key in ['sending_ts_ms','engine_ts_ms']},
   'connection_counter_sample':p.get('connection'),'counter_scope':'this explicit reader+session since connection start; samples are not global totals'})
 diagnostics=subset('speeddesk_feed_kalshi_ws_timing');diagnostics=[e for e in diagnostics if isinstance(e['payload'],dict) and e['payload'].get('event')=='gap']
 warning_joins=[]
 for e in gaps:
  key=pkey(e);r=producer(e)
  candidates=[d for d in diagnostics if key is not None and r['session'] is not None and pkey(d)==key]
  warning_joins.append({'warning_id':e['id'],'reader':r,'candidate_diagnostic_ids':[d['id'] for d in candidates],
   'join_basis':'explicit deployment/incarnation/reader/session identity; message reason/time remains separately recorded' if key and r['session'] is not None else 'no join: identity/session missing',
   'unique_same_session_diagnostic':len(candidates)==1})
 freshness={'timing_rows':len(timing),'timing_events':dict(Counter(e['payload']['event'] for e in timing)),
  'gap_warning_rows':len(gaps),'gap_warning_classes':dict(Counter(map(gap_class,gaps))),
  'warnings_by_producer':{kind:dict(Counter(gap_class(e) for e in gaps if category(e)==kind)) for kind in ['speeddesk','derived_market_reader','unidentified']},
  'diagnostics_by_producer':{kind:dict(Counter((e['payload'].get('receipt') or {}).get('status','missing') for e in timing if e['payload'].get('event')=='gap' and category(e)==kind)) for kind in ['speeddesk','derived_market_reader','unidentified']},
  'timestamp_domains':dict(Counter(re.search(r'timestamp_missing_or_stale:([^:]+):',e['body']).group(1) for e in gaps if 'timestamp_missing_or_stale:' in e['body'])),
  'known_gap_main_explicit':len(main_known),'known_gap_derived_explicit':len(derived_known),'known_gap_unidentified':len(unidentified_known),
  'unknown_gap_receipts':dict(Counter((e['payload'].get('receipt') or {}).get('status','missing') for e in timing if e['payload'].get('event')=='gap' and (e['payload'].get('receipt') or {}).get('status')!='known')),
  'main_known_gap_rows':[ref(e) for e in main_known],'derived_known_gap_rows':[ref(e) for e in derived_known],
  'unidentified_known_gap_rows':[ref(e) for e in unidentified_known],'typed_timing_samples':typed_samples,
  'gap_originals':gaps,'same_session_warning_diagnostic_candidates':warning_joins,
  'producer_limit':'Reader IDs are scoped to exact deployment and supplied verified startup incarnation, not across restarts. Unknown identities are not inferred from local_work. Session candidates do not merge distinct warning/diagnostic log-time populations.',
  'other_feed_warnings':[e for e in events if log_inside(e) and e['event'] in ['speeddesk_feed_kalshi_trade_gap','speeddesk_feed_coinbase_disconnected','speeddesk_feed_kalshi_book_failed']]}
 traces=[e for e in subset('speeddesk_reconcile_trace') if isinstance(e['payload'],dict)]
 selected=[e for e in traces if e['payload']['started_at']<END and e['payload']['at']>=START]
 readrows=[];missing=[];queries_work=[]
 for e in selected:
  p=e['payload']
  for i,r in enumerate(p['reads']):
   marks=r['marks_ms'];required=['submitted','worker_started','worker_completed','coroutine_resumed','wrapper_returned']
   miss=[k for k in required if type(marks.get(k)) not in (int,float)]
   if miss:missing.append({'cycle':p['cycle'],'read_index':i,'missing':miss})
   else:readrows.append({'cycle':p['cycle'],'read_index':i,'read':r['read'],
    'actual_resume_ms':marks['coroutine_resumed']-marks['worker_completed'],'marks_ms':marks,
    'approx_read_start_wall':p['started_at']+marks['submitted']/1000,
    'approx_read_end_wall':p['started_at']+marks['wrapper_returned']/1000,
    'read_interval_overlaps_fixed_window':p['started_at']+marks['submitted']/1000<END and p['started_at']+marks['wrapper_returned']/1000>=START})
  queries_work += [('cycle',p.get('callback_work',{}))]+[('read_resume',r) for r in p.get('read_resume_work',[])]
 trace_result={'selected_cycles':len(selected),'selected_reads':len(readrows),'missing_required_marks':missing,
  'omitted_reads':sum(e['payload']['reads_omitted'] for e in selected),
  'max_actual_resume':max(readrows,key=lambda r:r['actual_resume_ms']) if readrows else None,
  'cycles':[ref(e) for e in selected],'read_details':readrows,
  'whole_cycle_work_omitted_details':sum(w.get('omitted_spans',0) for k,w in queries_work if k=='cycle'),
  'read_resume_work_omitted_details':sum(w.get('omitted_spans',0) for k,w in queries_work if k=='read_resume'),
  'work_retention_loss':[(k,w.get('start_mono'),w.get('end_mono')) for k,w in queries_work if w.get('retention_loss')],
  'work_disabled':[(k,w.get('error')) for k,w in queries_work if not w.get('enabled')],
  'bin_retention_loss':[(k,w.get('start_mono')) for k,w in queries_work if w.get('all_sync_work_lower_bound',{}).get('retention_loss')]}
 
 statuses=[e for e in subset('speeddesk_live_status') if isinstance(e['payload'],dict) and type(e['payload'].get('at')) in (int,float)]
 statuses.sort(key=lambda e:e['payload']['at'])
 intervals=[]
 for prev,cur in zip(statuses,statuses[1:]):
  a,b=prev['payload']['at'],cur['payload']['at']
  if a<END and b>=START:
   intervals.append({'start':a,'end':b,'start_log':prev['timestamp'],'end_log':cur['timestamp'],
     'fully_contained':a>=START and b<=END,'loop':cur['payload'].get('loop',{}),
     'counts':cur['payload'].get('reconcile_trace',{}).get('counts'),
     'trace_enabled':cur['payload'].get('reconcile_trace',{}).get('enabled'),
     'buffered':cur['payload'].get('reconcile_trace',{}).get('buffered'),
     'buffer_dropped':cur['payload'].get('reconcile_trace',{}).get('buffer_dropped')})
 lagrows=[(i,i['loop'].get('ms',{}).get('event_loop_lag',{})) for i in intervals]
 boundary_before=max((e for e in statuses if e['payload']['at']<START),key=lambda e:e['payload']['at'],default=None)
 endpoint_before=max((e for e in statuses if e['payload']['at']<END),key=lambda e:e['payload']['at'],default=None)
 endpoint_after=min((e for e in statuses if e['payload']['at']>=END),key=lambda e:e['payload']['at'],default=None)
 latest=statuses[-1] if statuses else None
 maybe_ref=lambda e:ref(e) if e else None
 statuses_result={'covering_intervals':len(intervals),'fully_contained_intervals':sum(i['fully_contained'] for i in intervals),
  'coverage_start':intervals[0]['start'] if intervals else None,'coverage_end':intervals[-1]['end'] if intervals else None,
  'max_lag_ms':max((l.get('max_ms',0) for i,l in lagrows),default=None),
  'max_lag_sample_count':max((l.get('n',0) for i,l in lagrows),default=None),
  'any_sample_cap_hit':any(v.get('n',0)>=8192 for i in intervals for v in i['loop'].get('ms',{}).values()),
  'missing_lag_intervals':[{'start':i['start'],'end':i['end']} for i,l in lagrows if not l],
  'intervals':intervals,'before_start':maybe_ref(boundary_before),'before_end':maybe_ref(endpoint_before),
  'after_end':maybe_ref(endpoint_after),'latest_tail_status':maybe_ref(latest),
  'boundary_coverage_present':boundary_before is not None and endpoint_after is not None,
  'unstructured_status_rows':[e for e in subset('speeddesk_live_status') if e['payload'] is None]}
 publication=[]
 for e in [boundary_before,endpoint_before,endpoint_after,latest]:
  if e is None:
   publication.append({'missing_endpoint':True});continue
  p=e['payload'];t=p.get('reconcile_trace',{});counts=t.get('counts')
  if not isinstance(counts,dict):
   publication.append({'status_log':e['timestamp'],'missing_counts':True,'trace':t});continue
  expected=counts['reported'];cohort=[x for x in traces if x['payload']['cycle']<=counts['cycles']]
  publication.append({'status_log':e['timestamp'],'counts':counts,'completed_equals_begun':counts['cycles']==counts['quiet']+counts['reported']+counts['suppressed'],
   'active_or_unfinished_cycles':counts['cycles']-counts['quiet']-counts['reported']-counts['suppressed'],
   'published_rows_for_started_cohort':len(cohort),'expected_reported':expected,'published_matches':len(cohort)==expected,
   'buffered':t['buffered'],'buffer_dropped':t['buffer_dropped'],'enabled':t['enabled']})
 guard_keys=['authenticated','fee_precision_verified','real_orders_available','total_halted','day_stop_latched','integrity_error','cleanup_pending','caps']
 guard_rows=[e for e in statuses if START<=e['payload']['at']<=latest['payload']['at']] if latest else []
 financial['guard_observations']={'status_rows':len(guard_rows),'values':{k:sorted({json.dumps(e['payload'].get(k),sort_keys=True) for e in guard_rows}) for k in guard_keys},
  'scope':'Periodic status observations; no claim of continuous proof from snapshots.'}
 source_dir=Path('/workspace/nightcrawler-next-evidence')
 source_paths=['src/nightcrawler/speeddesk_readtrace.py','src/nightcrawler/speeddesk_worktrace.py','src/nightcrawler/speeddesk_live.py','src/nightcrawler/speeddesk_kalshi_ws.py','src/nightcrawler/speeddesk.py','src/nightcrawler/weatherwatch_markets.py','src/nightcrawler/speeddesk_model.py','src/nightcrawler/speeddesk_live_model.py']
 source_hashes={p:sha(subprocess.check_output(['git','show','1e8d0be:'+p],cwd=source_dir)) for p in source_paths}
 derived_path=ROOT/'mirror-postrelease-derived.json';derived_raw=derived_path.read_bytes();derived=json.loads(derived_raw)
 independent_first={(e['timestamp'],e['original_message']) for e in events if log_inside(e)}
 derived_first={(e['timestamp'],e['original_message']) for e in derived['original_events'] if log_inside(e)}
 comparison={'derived_sha256_at_comparison':sha(derived_raw),'independent_window_event_count':len(independent_first),
  'derived_window_event_count':len(derived_first),'missing_in_derived':len(independent_first-derived_first),
  'extra_in_derived':len(derived_first-independent_first),
  'missing_event_counts':dict(Counter(e['event'] for e in events if (e['timestamp'],e['original_message']) in independent_first-derived_first)),
  'note':'Original row population compared independently. Heuristic diagnostic/warning joins are not proven shared-producer identities.'}
 # Missing/conflicting financial or observational evidence is retained as a
 # limitation; never replace the fixed window to obtain an easy complete row.
 # Preserve an in-flight or incompletely published cohort as a limitation rather
 # than silently replacing its endpoint or treating it as a parser failure.
 output={'task':'EXEC-DELAY-001 independent fixed window audit','state':'closed_final_capture' if capture['complete'] else 'first_window_with_tail_capture_still_active',
  'input_file':str(SOURCE),'input_sha256':sha(raw),'input_bytes':len(raw),'source_assignment':capture['assignment'],
  'collector_complete_at_snapshot':capture['complete'],'collector_jobs_running_at_snapshot':capture['collector_jobs_running'],
  'window_start_utc':datetime.fromtimestamp(START,timezone.utc).isoformat(),'window_end_utc':datetime.fromtimestamp(END,timezone.utc).isoformat(),'publication_tail_received_through':capture['queries'][-1]['query']['endDate'],
  'queries':queries,'raw_unique_rows':len(seen),'exact_duplicate_rows':duplicates,'parsed_original_events':len(events),
  'parse_errors':parse_errors,'financial':financial,'freshness':freshness,'read_trace':trace_result,'status_intervals':statuses_result,
  'other_settlements_logged_in_window':[ref(e) for e in subset('speeddesk_live_settlement') if isinstance(e['payload'],dict) and log_inside(e) and e['payload'].get('window')!=TICKER],
  'publication_cohorts':publication,
  'status_cycle_counter_resets':[{'previous':a['timestamp'],'current':b['timestamp']} for a,b in zip(statuses,statuses[1:]) if isinstance(a['payload'].get('reconcile_trace',{}).get('counts'),dict) and isinstance(b['payload'].get('reconcile_trace',{}).get('counts'),dict) and b['payload']['reconcile_trace']['counts']['cycles']<a['payload']['reconcile_trace']['counts']['cycles']],
  'source_hashes':source_hashes,'collector_derived_population_comparison':comparison,
  'limits':['Finite filtered logs, not raw market tape or ledger export.','Unknown shared-producer gaps are not BTC-specific.',
  'Selected read marks and interval lag populations differ; no pooled quantiles or cumulative-max subtraction.',
  'Nested work and quiet-bin coverage overlap; omitted scopes must not be added.',
  'This finite original capture cannot establish causal benefit of a later release or retrospective producer identity.']}
 
 return output

if __name__ == '__main__':
 root=Path('/workspace/shared');first_only='--first' in sys.argv
 live_path=root/'mirror-postrelease-capture.json';raw=live_path.read_bytes();c=json.loads(raw)
 required_tail='2026-10-15T05:17:00Z' if first_only else '2026-10-15T05:32:00Z'
 if not first_only:
  assert c.get('complete') is True and c.get('collector_jobs_running') is False,'Final collector is not closed/stopped'
 assert c['queries'][-1]['query']['endDate']>=required_tail,'Predetermined publication tail not present'
 assert c['assignment']['exact_source_commit']=='1e8d0be07b280292fa873a2f5da9b22dd02f28c3'
 assert {q['query']['deploymentId'] for q in c['queries']}=={'fc0a73e9-f052-435a-94b2-ce7b1272f36e'}
 for prev,cur in zip(c['queries'],c['queries'][1:]):
  assert prev['query']['endDate']==cur['query']['startDate'],'Query coverage gap/overlap'
 for q in c['queries']:
  assert not q['response'].get('isError') and len(q['response']['structuredContent']['deploy'])<q['query']['limit'],'Invalid or capped response'
  assert hashlib.sha256(Path(q['artifact']).read_bytes()).hexdigest()==q['artifact_sha256'],'Original response artifact changed'
 prefix='mirror-postrelease-first-window-audit' if first_only else 'mirror-postrelease-two-window-audit'
 source=root/(prefix+'-input.json')
 if source.exists():assert source.read_bytes()==raw,'Refusing to replace immutable audit input'
 else:
  with source.open('xb') as stream:stream.write(raw)
 earlier=root/'mirror-postrelease-first-window-audit-input.json'
 if not first_only and earlier.exists():
  old=json.loads(earlier.read_bytes())
  for oldq,newq in zip(old['queries'],c['queries']):
   assert oldq['query']==newq['query'] and oldq['response']==newq['response'],'Previously frozen original evidence changed'
 start=datetime.fromisoformat('2026-10-15T05:00:00+00:00').timestamp()
 windows=[audit_window(source,start,start+900,'KXBTC15M-26OCT150115-15')]
 if not first_only:windows.append(audit_window(source,start+900,start+1800,'KXBTC15M-26OCT150130-30'))
 cycles={e['payload']['cycle']:e for w in windows for e in w['read_trace']['cycles']}
 reads={(r['cycle'],r['read_index']):r for w in windows for r in w['read_trace']['read_details']}
 intervals={(i['start'],i['end']):i for w in windows for i in w['status_intervals']['intervals']}
 complete=all(w['financial']['financial_reconciliation_complete'] for w in windows)
 D=lambda x:Decimal(str(x))
 financial={'windows_with_complete_logged_reconciliation':sum(w['financial']['financial_reconciliation_complete'] for w in windows),
  'fixed_windows_audited':len(windows),'all_financial_reconciliations_complete':complete,
  'observed_cost_decimal':str(sum(D(w['financial']['cost_decimal']) for w in windows)),
  'observed_fee_decimal':str(sum(D(w['financial']['fee_decimal']) for w in windows)),
  'settled_pnl_decimal':str(sum(D(w['financial']['recomputed_pnl_decimal']) for w in windows)) if complete else None,
  'locked_decimal':str(sum(D(w['financial']['settlements'][0]['payload']['locked_usd']) for w in windows)) if complete else None,
  'directional_decimal':str(sum(D(w['financial']['settlements'][0]['payload']['direction_usd']) for w in windows)) if complete else None,
  'worst_settled_window_decimal':str(min(D(w['financial']['recomputed_pnl_decimal']) for w in windows)) if complete else None,
  'real_fill_events':sum(w['financial']['real_fill_events'] for w in windows),
  'durable_intents':sum(w['financial']['durable_intents'] for w in windows),
  'accepted_orders':sum(w['financial']['accepted_orders'] for w in windows),
  'filled_orders':sum(w['financial']['filled_orders'] for w in windows),
  'filled_clients':sum(w['financial']['filled_clients'] for w in windows),
  'limitation':'Observed fills/fees are not a zero-activity proof if a settlement or join is missing.'}
 financial['accepted_order_fill_rate']=financial['filled_orders']/financial['accepted_orders'] if financial['accepted_orders'] else None
 financial['durable_intent_fill_rate']=financial['filled_clients']/financial['durable_intents'] if financial['durable_intents'] else None
 observation={'unique_selected_cycles':len(cycles),'selected_cycle_ids':sorted(cycles),'unique_selected_reads':len(reads),
  'max_selected_actual_resume':max(reads.values(),key=lambda r:r['actual_resume_ms']) if reads else None,
  'unique_covering_loop_intervals':len(intervals),
  'covering_loop_lag_max_ms':max((i['loop'].get('ms',{}).get('event_loop_lag',{}).get('max_ms',0) for i in intervals.values()),default=None),
  'any_sample_cap_hit':any(w['status_intervals']['any_sample_cap_hit'] for w in windows),
  'gap_warning_classes':dict(sum((Counter(w['freshness']['gap_warning_classes']) for w in windows),Counter())),
  'timing_event_counts':dict(sum((Counter(w['freshness']['timing_events']) for w in windows),Counter())),
  'warnings_by_producer':{kind:dict(sum((Counter(w['freshness']['warnings_by_producer'][kind]) for w in windows),Counter())) for kind in ['speeddesk','derived_market_reader','unidentified']},
  'diagnostics_by_producer':{kind:dict(sum((Counter(w['freshness']['diagnostics_by_producer'][kind]) for w in windows),Counter())) for kind in ['speeddesk','derived_market_reader','unidentified']},
  'main_known_gap_rows':[e for w in windows for e in w['freshness']['main_known_gap_rows']],
  'cohort_limit':'Reads are all reads in overlapping selected cycles, including straddlers; interval union deduplicates boundary bins. Any counter reset invalidates cross-incarnation aggregate interpretation.'}
 result={'task':'EXEC-DELAY-001 independent post-PR58 fixed-window audit',
  'state':'first_window_closed_with_tail_second_still_active' if first_only else 'two_fixed_windows_and_tail_closed',
  'parser_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
  'collector_state_at_snapshot':c['state'],'collector_last_persisted_at':c.get('last_persisted_at'),
  'input_file':str(source),'input_sha256':hashlib.sha256(raw).hexdigest(),'input_bytes':len(raw),
  'first_window':windows[0],'second_window':windows[1] if len(windows)>1 else None,
  'financial_combined':financial,'combined_observation_populations':observation,
  'limits':['Startup and prior/next ticker outcomes remain outside exact fixed-window financial cohorts.',
   'Sending/engine/local clocks stay typed; source timestamps are not network receipt.',
   'Reader identities are deployment/incarnation qualified; unknowns are not inferred or joined.',
   'Warning and diagnostic log-time populations are distinct even when explicit same-session candidates exist.',
   'No pooled quantiles, cumulative-max subtraction, unobserved no-trade assumption, or causal effect from snapshot comparisons.',
   'This finite audit does not clear EXEC-DELAY-001.']}
 outside={}
 for query in c['queries']:
  for row in query['response']['structuredContent']['deploy']:
   match=re.search(r' INFO [^:]+: (speeddesk_live_(?:fill|settlement|order)) (\{.*\})$',row['message'],re.S)
   if not match:continue
   kind,body=match.groups();payload=json.loads(body);ticker=payload.get('window')
   if ticker in ['KXBTC15M-26OCT150115-15','KXBTC15M-26OCT150130-30']:continue
   entry=outside.setdefault(ticker,{'scope':'Partial captured events outside both fixed windows; no full exposure or profitability inference','events':[]})
   entry['events'].append({'timestamp':row['timestamp'],'event':kind,'payload':payload})
 for entry in outside.values():
  observed={e['payload']['fill_id']:e['payload'] for e in entry['events'] if e['event']=='speeddesk_live_fill'}
  entry['unique_observed_fills']=len(observed)
  entry['observed_fill_cost_decimal']=str(sum((D(v['price'])*D(v['size']) for v in observed.values()),Decimal(0)))
  entry['observed_fill_fee_decimal']=str(sum((D(v['fee_usd']) for v in observed.values()),Decimal(0)))
 result['outside_fixed_financial_cohorts']=outside
 if not first_only:
  startup=audit_window(source,datetime.fromisoformat('2026-10-15T04:49:27+00:00').timestamp(),start,'KXBTC15M-26OCT150100-00')
  result['startup_partial_observation']={k:startup[k] for k in ['window_start_utc','window_end_utc','freshness','read_trace','status_intervals','publication_cohorts']}
  result['startup_partial_observation']['scope']='Separate partial restart observation only; prior exposure and old-process fills are absent from this capture. Excluded from both fixed-window totals.'
  result['startup_partial_observation']['prior_ticker_settlement_rows']=startup['financial']['settlements']
  result['startup_partial_observation']['restart_audit_reference']='/workspace/shared/live-mirror-restart-audit.json'
 previous_report=root/'mirror-postrelease-first-window-audit.json'
 if not first_only and previous_report.exists():
  initial=json.loads(previous_report.read_bytes());old=initial['first_window']['financial'];current=windows[0]['financial']
  fields=['real_fill_events','durable_intents','accepted_orders','cost_decimal','fee_decimal','recomputed_pnl_decimal','financial_reconciliation_complete']
  result['initial_first_window_report_comparison']={'path':str(previous_report),
   'sha256':hashlib.sha256(previous_report.read_bytes()).hexdigest(),
   'changed_financial_fields':{key:{'initial':old.get(key),'final':current.get(key)} for key in fields if old.get(key)!=current.get(key)},
   'note':'Earlier artifact remains immutable; any later evidence changes are reported explicitly.'}
 out=root/(prefix+'.json');out.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
 print(json.dumps({'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
  'input_sha256':result['input_sha256'],'financial':financial,
  'observation':{k:v for k,v in observation.items() if k!='main_known_gap_rows'}},indent=2))

