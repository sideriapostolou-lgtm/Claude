"""Save bounded read-only daily inspection evidence; no production operations."""
import hashlib
import json
import math
import re
import subprocess
import zipfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

HERE=Path(__file__).resolve().parent
REPO=Path('/workspace/nightcrawler-online-learning')
OUT=REPO/'research/kalshi_profitability_2026-10-14'
def sha(b):return hashlib.sha256(b).hexdigest()
def result(name):
    r=json.loads((HERE/name).read_text())['result'];assert not r.get('isError'),name
    return r['structuredContent']
def originals(name,logger,event):
    out=[]
    for row in result(name).get('deploy',[]):
        m=re.search(r' INFO '+re.escape(logger)+r': '+re.escape(event)+r' (\{.*\})$',row['message'])
        if m:out.append({'timestamp':row['timestamp'],'payload':json.loads(m[1])})
    return sorted(out,key=lambda x:x['timestamp'])
status=originals('daily-status.json','nightcrawler.speeddesk','speeddesk_live_status')[-1]
s=status['payload'];day=s['reports']['2026-10-14'];real=day['real'];twin=day['practice_twin']
assert s['mode']=='paper' and s['configured_mode']=='live' and s['total_halted']
assert not s['trading_now'] and s['authenticated'] and s['integrity_error'] is None
assert all(s[k]==0 for k in ['open_risk_usd','open_orders','reserved_usd','positions'])
assert 0<=s['at']-s['as_of']<3 and 0<=s['at']-s['cash_at']<3
assert math.isclose(s['total']['pnl_usd'],-19.051,abs_tol=1e-10)
assert math.isclose(real['locked_usd']+real['directional_usd'],real['pnl_usd'],abs_tol=1e-10)
assert math.isclose(twin['locked_usd']+twin['directional_usd'],twin['pnl_usd'],abs_tol=1e-10)
assert 'fees_usd' not in twin  # unknown, not zero
for a in [real,twin]:
    c=a['scorecard'];assert c['eligible_windows']==c['gap_windows']==96 and c['complete_windows']==0
    assert c['pnl_usd'] is None and c['day_complete'] is False
    assert a['take_attempts']==a['take_fills']==0 and a['take_fill_rate'] is None
    assert math.isclose(a['maker_fills']/a['maker_orders'],a['maker_fill_rate'])
assert real['latency']['decision_to_ack']['samples']==1854
assert real['latency']['decision_to_ack']['observations']==1872
assert real['latency']['decision_to_ack']['errors']==18
assert twin['latency']['btc_receipt_to_decision']['samples']==1513
lr=originals('learner-current.json','nightcrawler.kalshi_online_learning','kalshi_online_learning_status')[-1]
l=lr['payload']['learning'];assert l['forecasts']==l['scored']==0 and l['unknown']==7
assert l['exclusions']['pregap']==6 and l['exclusions']['startup_inside']==1
assert l['enabled'] and not l['live_application'] and l['error'] is None
manifests=[]
for row in result('recorder-manifest.json')['deploy']:
    m=re.search(r' kalshi_recorder_evidence (\{.*\})$',row['message'])
    if m:manifests.append({'timestamp':row['timestamp'],'payload':json.loads(m[1])})
assert len(manifests)==2
mr=manifests[-1]['payload'];assert mr['storage']['used_bytes']==505511164 and mr['storage']['level']==0
assert not mr['coverage_certified'] and not mr['segment_hashes_reverified'] and not mr['per_venue_spot_ticks_verified']
assert not result('recorder-warnings.json')['deploy'] and not result('tracebacks.json')['deploy']
health=result('health.json');assert len(health['services'])==2 and all(x['state']=='online' and not x['hasIssues'] for x in health['services'])
bot=[d for d in result('bot-deployments.json')['deployments'] if d['status']=='SUCCESS'][0]
rec=[d for d in result('recorder-deployments-active.json')['deployments'] if d['status']=='SUCCESS'][0]
assert bot['id']=='458e8e54-804c-46f1-aaf4-0abab4461571' and bot['meta']['commitHash']=='933a43d2d7cb6d6dd27b4728d50c78ce0f488ed5'
assert rec['id']=='8453f919-b891-4aa7-8478-6fcf6b9c24ee' and rec['meta']['commitHash']==mr['commit']
sc=json.loads((HERE/'takeover-schedules.json').read_text());assert len(sc['automations'])==3 and all(x['is_enabled'] and x['next_run_time'] is None for x in sc['automations'])
source_checks=[]
for i in range(5):
    d=json.loads((HERE/f'instructions-{i}.json').read_text());v=d['result']['structuredContent']
    content=subprocess.check_output(['git','show',d['ref']+':'+d['path']],cwd=REPO).decode()
    blob=subprocess.check_output(['git','rev-parse',d['ref']+':'+d['path']],cwd=REPO).decode().strip()
    assert content==v['content'] and blob==v['sha']
    source_checks.append({'path':d['path'],'commit':d['ref'],'blob':blob,'complete_returned_bytes_equal_git':True})
report={'recorded_at_pacific':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
        'scope':'Read-only production daily inspection and offline fake reproductions; no source release, orders, variables, financial controls or schedule mutations.',
        'status':status,'prior_completed_utc_day':day,'learner':lr,'recorder_metadata':manifests,
        'health':health,'bot_deployment':bot,'recorder_deployment':rec,'source_checks':source_checks,
        'cash_age_s':s['at']-s['cash_at'],'account_age_s':s['at']-s['as_of'],
        'all_raw_counter_results_partial_coverage':True,'practice_fee_amount':None,
        'window_counter_vs_settlement_counter_unreconciled':True,
        'no_raw_cash_ledger_or_stop_anchor_export':True,
        'recorder_growth_bytes_in_observed_hour':mr['storage']['used_bytes']-manifests[0]['payload']['storage']['used_bytes'],
        'storage_used_share':mr['storage']['used_bytes']/mr['storage']['cap_bytes'],
        'raw_payload_hashes_and_actual_depth_fill_costs_unverified':True,
        'no_material_access_failures_in_used_production_reads':True,
        'failure_limits':'Reviewer initially overlooked embedded JSON; original review and corrected amendment retained. Early root read of pending local agent receipt filename failed before the agent completed it; not a production access failure.',
        'next_step':'Local chronology candidate review/tests; actual future timed gap attribution. Production remains read-only and Kalshi real stop stays latched.'}
names=['daily-status.json','health.json','bot-deployments.json','recorder-deployments.json','recorder-deployments-active.json',
       'recorder-manifest.json','recorder-warnings.json','recorder-guide-source.json','feed-status.json','learner-current.json',
       'tracebacks.json','takeover-schedules.json','TAKEOVER_INVENTORY.json','TAKEOVER_INVENTORY.md',
       'daily-literal-check.json','daily-literal-check-amended.json','FINDINGS.md','findings.json','reproduce.py',
       'independent-design-review.md','independent-original-summary.json','independent_reproducer.py',
       'independent-reproducer-results.json','sol-diagnosis-manifest.json','package_daily.py']
names += [f'instructions-{i}.json' for i in range(5)]
names += ['root-reproductions/reproduce.py','root-reproductions/independent_reproducer.py',
          'root-reproductions/arena.stdout.json','root-reproductions/pipeline.stdout.json','root-reproductions/findings.json']
payload={n:(HERE/n).read_bytes() for n in names}
payload['observation.json']=(json.dumps(report,indent=2)+'\n').encode()
payload['DAILY_STATUS_2026-10-15.md']=(OUT/'DAILY_STATUS_2026-10-15.md').read_bytes()
payload['CODEX_TAKEOVER.md']=(REPO/'docs/CODEX_TAKEOVER.md').read_bytes()
# The older initial learner log interval is part of this day's chronology evidence.
payload['initial-learning-interval.json']=Path('/workspace/shared/kalshi-status-20261015-0812/learning.json').read_bytes()
patterns=[rb'-----BEGIN[ ](?:[A-Z]+[ ])?PRIVATE[ ]KEY-----',rb'\bsk-[A-Za-z0-9_-]{20,}',rb'\bjup_[A-Za-z0-9_-]{20,}',rb'\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{25,}',rb'\bgithub_pat_[A-Za-z0-9_]{30,}']
assert not any(re.search(p,b) for b in payload.values() for p in patterns)
archive=OUT/'DAILY_STATUS_2026-10-15.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(payload.items()):z.writestr(n,b)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(payload)
    assert all(z.read(n)==b for n,b in payload.items())
receipt={'observation':report,'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),
         'member_count':len(payload),'crc_and_original_member_bytes_verified':True,'recognized_private_pattern_matches':0,
         'members':[{'name':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(payload.items())]}
(OUT/'DAILY_STATUS_2026-10-15.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['archive','bytes','sha256','member_count']}))
