# Independent bounded feed/learning design review

Reviewed base `91250c6598f4b866d7601ac0ead3e66ba55996cd` in `/workspace/nightcrawler-feed-learning`.
Read-only source and saved-original review; only shared review/reproducer artifacts written. No production
queries, repository edits, commits, deployment, keys, orders, settings or control actions. The existing Kalshi
total-stop latch must remain latched. The separate unreleased ledger diagnostic remains untouched.

## Evidence and demonstrated defect

`independent-original-summary.json` independently anchors all 31 original learner logger rows from
`/workspace/shared/kalshi-status-20261015-0812/learning.json`. They contain one startup-partial exclusion and
five `pregap` exclusions at 14:05, 14:20, 14:35, 14:50 and 15:05 UTC. No forecasts or scored predictions appear.
The generic `pregap` receipt omits its underlying cause. These originals cannot establish that any particular
one of the five exclusions came from the defect below. Healthy producer snapshots before/at a slot cannot
rule out an intervening gap.

The actual-child local reproduction is `independent_reproducer.py`, with output in
`independent-reproducer-results.json`. It uses actual `KalshiArena.step`, `_drain`, `_degrade` and learner
methods with a fake clock, no clients/orders, and checkpoint writes replaced by a timestamp update:

| Case | State before forecast | Actual result at fresh +300s slot |
| --- | --- | --- |
| No gap | No learner or simulator degradation | One forecast |
| Late book processed at 950 for window starting 1000 | Learner pregap remains null; simulator retains `feed_late` | Incorrectly excluded as pregap |
| Late book processed at 1100, after start | Learner records `feed_late` | Correctly excluded as pregap under V1 |
| Explicit healthy-stream gap for the future window at 950 | No learner pregap | One forecast |
| Active status: maker stream unavailable, Coinbase healthy | Learner records explicit feed gap | Excluded under current V1 |

Source chain:

- `kalshi_online_learning.py:151-159`: `degrade` correctly ignores a window that has not started.
- `kalshi_arena.py:1231-1250`: late books/prints call `_degrade` even for future listings.
- `kalshi_arena.py:1138-1141`: the learner call ignores that early event, but simulator `self.degraded`
  retains an untimed sticky entry for the same window.
- `kalshi_arena.py:1160-1161` passes that simulator map into learner `advance`.
- `kalshi_online_learning.py:269-270` rejects membership in the map without knowing when the gap happened.

This is an internally demonstrated chronology inconsistency. It is not evidence that a genuine active-window
gap is safe, nor that the observed five production exclusions were all false.

## Smallest correction to consider locally

Keep practice `self.degraded`, practice voiding, live book cancellation and all financial controls unchanged.
Make learner exclusion depend on time-qualified learner-window degradation, rather than unconditionally
inheriting sticky simulator membership.

The existing direct `OnlineLearning.degrade` path already stores the correct pre/post-forecast distinction.
Complete this path for every source of actual degradation before removing the redundant untimed fallback:

1. Preserve the existing late-book/print callback: pre-start observations do not contaminate a future window;
   any observed degradation at/after its start still marks it before forecasting.
2. Global frame drops must reach all admitted, started learner windows, including windows absent from the
   simulator's active inventory/window map. `kalshi_arena.py:1105-1107,1143-1147` currently iterates simulator
   windows; a naive removal of the fallback is insufficient.
3. New-window/same-frame drop handling at `kalshi_arena.py:1193-1195` must propagate the original
   `_incomplete_before` occurrence time, not reinterpret an older pre-start gap at the later decision time.
4. Retain post-forecast gap receipts while scoring a valid official label. Do not delete losing frozen forecasts.

An equivalent bounded timestamped learner-specific map is acceptable if it covers those cases; do not clear
the simulator's map or infer event time from current membership. A future pre-start gap followed by a genuine
active-window gap must still exclude the window.

This limited correction preserves V1's intended procedure: future full admission, fixed +300s slot/grace,
all actual active pre-forecast gaps excluded, fresh finite model inputs, official labels and no live application.
Keep every historical V1 unknown and do not retrospectively reconstruct its prediction. It is not a fix for
the broader multisecond feed delay, and it need not make all future slots eligible.

## Fingerprint and history constraint

Current `fingerprint()` hashes the pure learner source plus `speeddesk_model.py`; it does not hash arena
hooks or upstream input-quality propagation. An arena-only chronology correction can therefore retain the
literal existing `b6112b7ef8955b20af734157c1e7f5ec533bf98f70e034558f06670578c391f2` algorithm fingerprint
and restore existing history without a mismatch override. That digest must not be described as a hash of the
complete input pipeline. Record the exact release/source SHA and the input-path correction separately, retain
all prior exclusions, and never reassign old observations to a new source identity.

If learner/model bytes change, the existing source-mismatch disable is expected. Do not bypass it to make
the feature appear operational. Any new protocol or explicit migration needs preserved old protocol/source
history and a prospective boundary. No such migration or code change is implemented by this review.

## Distinct design question: probability inputs versus maker availability

`OnlineLearning.gap` at 161-171 treats `trade_stream and coinbase` as required quality. However,
`speeddesk_kalshi.py:184-192` sets trade_stream from whether any maker window is available, and
`speeddesk_kalshi_ws.py:323-337` requires recent books and a trade within three seconds for maker membership.
Loss of simulated queue priority, a quiet print stream or a transport handoff can therefore exclude a
probability observation even when current spot, strike and sigma are available.

This conflation is separate from the chronology defect. V1 explicitly uses pre-forecast feed gaps, so changing
the required inputs to probability-only quality is an explicit protocol revision, not a stealth relaxation.
For a future version, define required Coinbase/volatility/strike/clock/label integrity separately from
simulated execution completeness; retain maker-gap metadata without treating a practice void as a fabricated
market label. Preserve genuine freshness, missing-input, frame-integrity and official-label safeguards.
No candidate implementation is selected here, and nothing guarantees a profitable calibrated probability.

The gap wire currently lacks occurrence timestamps. A pre-start producer status queued across the start can
be observed as an active-window event. Do not silently reinterpret it as harmless: adding precise source-time
attribution is a separate change, with restart/future-clock tests and bounds. Sol owns the independent producer
trace; this reproduction does not prove that queued-wire path caused the five production exclusions.

## Required acceptance cases and remaining evidence

- Actual child late future book/print followed by fresh forecast inputs: no false learner exclusion; simulator
  degraded/void behavior remains unchanged.
- Same late event after start: exclusion preserved. A future event followed by an active event still excludes.
- Global dropped frame, missing ladder and newly announced same-frame window: real active gaps retained.
- Learner pending but simulator skipped/forgotten windows: gap routing and official settlement remain honest.
- Explicit disconnect/gap, Coinbase failure, stale/future BTC time, missing sigma/strike, changed terms and
  invalid clocks retain existing rejection behavior. Do not make a healthy current snapshot erase an earlier
  active V1 gap.
- Post-forecast gap retains the prediction and scores a valid label exactly once; missing/late/conflicting
  labels remain explicit unknowns/errors. Restart/dedup/watermark behavior remains covered.
- Existing V1 counts, source identity, unknowns and pending forecasts survive the selected compatible change;
  incompatible changes remain disabled unless an explicit reviewed history migration is provided.
- No change to parent/live decisions, risk/reservation/stop history, simulator results or I/O cadence. Any
  added child attribution is bounded and measured; no per-tick log serialization.

Before claiming the production blocker fixed, attribute actual exclusions using original gap/degrade events
with window, producer/reader identity and occurrence/observation time. Capture future fixed windows after any
authorized release: a pre-outcome forecast, its official label, exactly-once score/bin update and retained
unknowns. A successful local reproduction/fix is not production coverage, a latency benefit, profitability,
or EXEC completion. Latest owner scope is production read-only; this review grants no release authority.
