"""Local fake-clock reproduction; no clients, network, orders, or state writes."""
import json
from pathlib import Path

from nightcrawler.kalshi_arena import ArenaConfig, KalshiArena, WireView
from nightcrawler.speeddesk_model import Book, Window


def case(kind):
    clock = [900.0]
    view = WireView()
    window = Window('KXBTC15M-reproduction', 1000, 1900, 100, venue='kalshi')
    view.windows = (window,)
    view.bitcoin_price, view.sigma = 100, .001
    town = KalshiArena(ArenaConfig(Path('/workspace/shared/kalshi-feed-learning-20261015/no-state-created'),
                                  population=2), lambda: view, clock=lambda: clock[0])
    town._save = lambda now: setattr(town, 'saved_at', now)

    def step(now):
        clock[0] = now
        view.bitcoin_at = now
        town.step(now)

    step(900)
    if kind in ('future_late_book', 'active_late_book'):
        clock[0] = 950 if kind == 'future_late_book' else 1100
        town.feed_book(Book(window.slug, 'up', (), (), clock[0] - 10, 'fake'))
        step(clock[0])
    elif kind == 'future_explicit_gap':
        town.feed_gap((window.slug,), True, True)
        step(950)
    elif kind == 'active_maker_unavailable_coinbase_healthy':
        town.feed_gap((), False, True)
        step(1100)
    before = {'learner_pregap': town.learning.pending[window.slug]['pregap'],
              'arena_degraded': dict(town.degraded), 'feed_ok': town.learning.feed_ok}
    step(1300)
    return {'case': kind, 'before_forecast': before, 'after_forecast': town.learning.panel(),
            'last_receipt': town.learning.recent[-1] if town.learning.recent else None,
            'practice_orders': sum(len(r.desk.orders) for r in town.residents.values())}


if __name__ == '__main__':
    results = [case(kind) for kind in ('control', 'future_late_book', 'active_late_book',
                                      'future_explicit_gap', 'active_maker_unavailable_coinbase_healthy')]
    assert results[0]['after_forecast']['forecasts'] == 1
    assert results[1]['before_forecast']['learner_pregap'] is None
    assert results[1]['after_forecast']['exclusions']['pregap'] == 1
    assert results[2]['before_forecast']['learner_pregap'] == 'feed_late'
    assert results[2]['after_forecast']['exclusions']['pregap'] == 1
    assert results[3]['after_forecast']['forecasts'] == 1
    assert results[4]['after_forecast']['exclusions']['pregap'] == 1
    assert all(r['practice_orders'] == 0 for r in results)
    print(json.dumps({'source_base': '91250c6598f4b866d7601ac0ead3e66ba55996cd',
                      'scope': 'Synthetic actual child methods; checkpoint replaced by timestamp update; no production attribution',
                      'results': results}, indent=2))
