"""Read-only source diagnosis with local fakes. No clients/HTTP/orders/outcomes."""
from __future__ import annotations
import json,re,tempfile,hashlib
from pathlib import Path
from types import SimpleNamespace
from fakes import FakeClock
from nightcrawler.speeddesk_model import Window
from nightcrawler.speeddesk_kalshi_ws import KalshiMarketWS,MarketState
from nightcrawler.speeddesk_kalshi import KalshiFeeds
from nightcrawler.speeddesk_venues import MarketFeeds
from nightcrawler.kalshi_online_learning import OnlineLearning
from nightcrawler.kalshi_arena import ArenaLink,ArenaConfig,KalshiArena,WireView
OUT=Path(__file__).resolve().parent

def learner(w):
 obj=OnlineLearning(900);obj.discover([w],900);return obj

def quiet_trade_expiry():
 w=Window('KXBTC15M-local-quiet',1000,1900,100,venue='kalshi');future=Window('KXBTC15M-local-future',1900,2800,100,venue='kalshi')
 c=FakeClock(1100); wire=[]; aggregate=[]
 router=MarketFeeds.__new__(MarketFeeds);router.status={'polymarket_us':{'coinbase':'connected','trade_stream':False}}
 router.known_windows={};router.adapters={'kalshi':SimpleNamespace(windows={w.slug:w,future.slug:future})}
 learn=learner(w)
 def forward(s):
  aggregate.append(s)
  # Exact three data fields forwarded by SpeedRunner.on_status344–345;
  # intentionally do not construct a live runner/client just for diagnosis.
  learn.gap(tuple(s.get('gap_windows',())),bool(s.get('trade_stream')),s.get('coinbase')=='connected',c.now())
 router._on_status=forward
 feed=KalshiFeeds.__new__(KalshiFeeds);feed.windows=router.adapters['kalshi'].windows;feed._clock=c.now
 feed._rest_trade_at={};feed._transport={};feed._status={};feed._ws_status={};feed.on_status=lambda s:router._status('kalshi',s)
 ws=KalshiMarketWS.__new__(KalshiMarketWS);ws._clock=c.now;ws.connected=True;ws._timestamp_notice=False;ws._last_status={}
 ws.state=MarketState(frozenset(feed.windows));ws.state.book_at[w.slug]=1100;ws.state.exchange_at[w.slug]=1100;ws.state.trade_at[w.slug]=1098
 def ws_status(s):wire.append(s);feed._ws_report(s)
 ws._on_status=ws_status
 ws._report()
 c.set(1102);ws.state.book_at[w.slug]=1102;ws.state.exchange_at[w.slug]=1102
 ws._report() # book stays fresh; ONLY the last actual print ages past3seconds
 before_forecast=learn.pending[w.slug]['pregap']
 c.set(1200);ws.state.book_at[w.slug]=1200;ws.state.exchange_at[w.slug]=1200;ws.state.trade_at[w.slug]=1200;ws._report()
 learn.advance([w],100,.001,1300,{},1300,{})
 return {'ws_statuses':wire,'aggregate_statuses':aggregate,'book_remains_fresh_at_expiry':w.slug in wire[1]['ws_books'],'maker_eligibility_expired':not wire[1]['ws_maker_windows'],'current_pregap_before_recovery':before_forecast,'final_counts':learn.counts,'future_ticker_expanded_into_aggregate_gap':future.slug in aggregate[1]['gap_windows']}

def queued_prestart_gap(process_late):
 c=FakeClock(900);w=Window('KXBTC15M-local-queued',1000,1900,100,venue='kalshi');view=WireView();view.windows=(w,);view.bitcoin_price=100;view.sigma=.001;view.bitcoin_at=900
 with tempfile.TemporaryDirectory() as path:
  config=ArenaConfig(Path(path),population=2);town=KalshiArena(config,lambda:view,clock=c.now);town.step(c.now())
  link=ArenaLink(config,clock=c.now);link.running=True
  c.set(990);link.feed_gap((w.slug,),False,True)
  if not process_late:
   town.receive(('batch',1,990,0,0,list(link.pending)),view);link.pending.clear();town.step(c.now())
  c.set(995);link.feed_gap((),True,True)
  messages=list(link.pending)
  if process_late:c.set(1001)
  town.receive(('batch',2 if not process_late else 1,995,0,0,messages),view);town.step(c.now())
  pre=town.learning.pending[w.slug]['pregap'];c.set(1300);view.bitcoin_at=1300;town.step(c.now())
  return {'producer_gap_time':990,'producer_recovery_time':995,'window_start':1000,'applied_after_start':process_late,'wire_records':messages,'pregap_after_apply':pre,'final_counts':town.learning.counts,'forecasted':town.learning.counts['forecasts']}

rawpath=Path('/workspace/shared/kalshi-status-20261015-0812/learning.json');raw=json.loads(rawpath.read_text());data=raw['result']['structuredContent'];parsed=[]
for row in data['deploy']:
 m=re.fullmatch(r'\S+ INFO nightcrawler\.kalshi_online_learning: kalshi_online_learning_(\w+) (\{.*\})',row['message'])
 if m:parsed.append({'event':m[1],'publication':row['timestamp'],'payload':json.loads(m[2])})
report={'base':'91250c6598f4b866d7601ac0ead3e66ba55996cd','scope':'Offline synthetic source/fakeclock only; no sealedTEST or outcome/strategy fitting, no clients/network/production changes. Reproductions are possible mechanisms, not attribution of all five production exclusions.','captured_learning':{'source_sha256':hashlib.sha256(rawpath.read_bytes()).hexdigest(),'rows':len(data['deploy']),'anchored_rows':len(parsed),'unknowns':[p for p in parsed if p['event']=='unknown'],'counts_by_event':{kind:sum(p['event']==kind for p in parsed) for kind in ['status','unknown','forecast','scored']}},'quiet_trade_expiry':quiet_trade_expiry(),'queued_control':queued_prestart_gap(False),'queued_late':queued_prestart_gap(True)}
assert report['quiet_trade_expiry']['book_remains_fresh_at_expiry']
assert report['quiet_trade_expiry']['final_counts']['pregap']==1
assert report['queued_control']['forecasted']==1
assert report['queued_late']['forecasted']==0 and report['queued_late']['final_counts']['pregap']==1
(OUT/'findings.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'capture_events':report['captured_learning']['counts_by_event'],'quiet_book_expiry_causes_pregap':True,'immediate_prestart_control_forecasts':report['queued_control']['forecasted'],'delayed_identical_prestart_events_forecasts':report['queued_late']['forecasted']},indent=2))
