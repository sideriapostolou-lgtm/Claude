# Read-only diagnosis: why the passive learner receives pre-gap exclusions

Pinned source:91250c6598f4b866d7601ac0ead3e66ba55996cd, worktree `/workspace/nightcrawler-feed-learning`. This worker made no source edits, production queries, commits, deployment, client/network calls, financial changes or sealed-TEST/outcome access. Kalshi's latched stop/paper state is outside this diagnosis and must remain unchanged.

## What the saved production evidence proves

`/workspace/shared/kalshi-status-20261015-0812/learning.json` contains31uncapped rows, all31 matching anchored original learner events:25status,6unknown,0forecast,0scored. One unknown is startup_inside; five distinct full-window targets at14:05/14:20/14:35/14:50/15:05UTC are pregap. Each occurs within the declared300–305second forecast grace. The protocol/source identity is the deployed passive v1. These records establish exclusions and zero trained observations, not an operational failure of the learner's statistical updater.

The current `unknown` event logs only reason=pregap. Its decision condition is a disjunction: pending row.pregap OR slug in arena.degraded OR feed_ok=False (`kalshi_online_learning.py:269`). Therefore the31learner records alone cannot identify which producer event or disjunct caused any individual full slot. In particular, they do NOT prove that all five suffered a network outage or that a recovered feed was continuously healthy. Original producer/transport receipts joined to each window before its due time are needed for actual attribution. No counterfactual trained results are inferred.

## Reproduced mechanism1: maker eligibility is a broader signal than probability-input validity

Actual source flow:

1. `speeddesk_kalshi_ws.py:323` computes fresh book membership independently from maker membership; maker membership additionally requires a real print within3seconds. Its gap set includes old ws_maker_windows minus new maker membership, even when the book remains fresh and connected.
2. `speeddesk_kalshi.py:184` sets trade_stream=bool(makers), and `_ws_report:194` forwards those explicit gaps.
3. `speeddesk_venues.py:27` expands a falling per-venue trade_stream into all current AND previously known venue windows, including future listings; explicit WS gaps also pass through. Aggregate trade_stream is any venue's readiness; Coinbase status comes from the shared Polymarket adapter.
4. `speeddesk.py:344` forwards gap_windows, aggregate trade_stream and Coinbase connected bool to the arena. `kalshi_arena.py:606` queues those fields. Child `_gap:1265` forwards them to the learner.
5. `kalshi_online_learning.py:161` sets feed_ok=trade_stream AND coinbase and permanently marks the active window's pre-gap flag. A later recovery updates feed_ok but correctly does not erase a pre-gap recorded under the existing protocol.

The offline `quiet_trade_expiry` reproduction invokes the real WS._report, KalshiFeeds._ws_report/_publish and MarketFeeds._status using constructor-free fakes. A clock advances from1100to1102: local and exchange book timestamps are refreshed, connection remains up, but the last actual print ages from2to4seconds. The book remains in ws_books; maker membership becomes empty; the explicit gap plus falling trade_stream creates a learner pre-gap despite fresh synthetic BTC and subsequent recovery. Future listing appears in expanded gap_windows but is not directly marked by learner.gap until it is active.

This is NOT proof the maker/queue invalidation is wrong. A stale trade/transport transition legitimately invalidates maker assumptions and should continue to protect order execution. It is evidence that treating that broad maker signal as equivalent to lost probability inputs can exclude samples in a quiet book. Changing the learner's eligibility semantics would require an explicit new prospective protocol/epoch or a reviewed compatibility decision; it must not be described as merely resetting an inconvenient exclusion.

## Reproduced mechanism2: timestamp-less queued gap/recovery crosses a window boundary

ArenaLink.feed_gap:606 stores only `(g, slugs, trade_stream, coinbase_connected)`. It contains no producer event timestamp or typed cause. Child receive:1117 queues it; `_drain` applies `_gap` using current child processing time, and learner.gap compares that time against each pending window's start/end. Frame sent_at is not used as a per-event timestamp and would not distinguish differently timed events inside a batch.

An offline control uses real ArenaLink and KalshiArena with FakeClock and an admitted future window starting1000:

- Producer gap990, recovery995; immediate child application990/995: no active-window pre-gap, one valid forecast at1300.
- IDENTICAL queued gap/recovery records applied1001: gap is interpreted as occurring after start; pre-gap persists despite recovery, zero forecasts at1300.

Both tests use identical fresh synthetic spot/sigma/opening, no trades/orders or final outcomes. The result is processing-time contamination of a future window. It proves a source-code defect is possible; it does not establish that the five production gaps crossed this boundary. Delay/drop diagnostics and exact producer event times are required to make that production claim.

A timestamp repair must preserve genuine overlapping outages: a disconnect990 and recovery1100 DOES overlap the window1000onward even though its beginning was before the start. Do not simply discard every pre-start event. Track event-time interval intersection or equivalent explicit producer state at the boundary, keep processing time/late/unknown flags, and treat unavailable/malformed/reversed timing conservatively. Do not reinterpret old timestamp-less queued events as known-good history.

## Independently found related mechanism: future arena degradation leaks into admission

Astra is independently reproducing this path: generic child `_degrade(future_slug, feed_late)` at `kalshi_arena.py:1138` can persist arena.degraded before that window starts. Learner.degrade ignores the pre-start event, but later advance's unconditional slug-in-degraded check excludes it. Unlike `_degrade_started` (started windows only), generic `_degrade` is not time-restricted. Initial comments that all future degradation was guarded were too broad; the distinction is explicit here. Do not clear or alter arena resident/queue degradation to repair a learner-only admission issue.

## Narrow local candidate recommendations — not implementation or release authority

1. Correct event-time attribution of the existing gap wire, preserving event cause/venue/time and fail-closed behavior for timestamp-less/invalid/late/overflow data. Test before-start gap+before-start recovery, outage spanning start, active-window gap, delayed active gap, overflow/drop and reconnect. Keep parent serialization work bounded and avoid changing any real cancellation/guard path.
2. Keep learner-local quality state independent from persistent practice arena degradation. Audit every degrade/drop/window-admission path before removing the unconditional arena.degraded veto; otherwise a true initial drop could be missed. Preserve post-forecast gap flags and score authentic same-terms labels; never delete frozen losing predictions.
3. Decide explicitly whether v1 requires maker/book continuity in addition to the actual p-model inputs. If a narrower BTC/strike-quality protocol is selected, preserve all five original exclusions and previous protocol/history identity; freeze the new prospective rules, tests and next observation cohort. Do not switch a false trade_stream to true to manufacture eligibility, and do not weaken real maker/stop rules.
4. Add bounded typed exclusion provenance (learner-local pregap reason, arena degradation reason, producer event time/type/venue, child applied time and current input flags) to unknown/status evidence so the next pregap is diagnosable without broad logs. No arbitrary payload/credential text, per-tick logging, extra subscriptions or checkpoint cadence.

Reproduction: `PYTHONPATH=src:tests /workspace/shared/nightcrawler-venv/bin/python /workspace/shared/kalshi-feed-learning-20261015/reproduce.py` from the pinned worktree. All assertions pass. `findings.json` preserves the exact local statuses, gap records, counters and six original captured unknown events, along with source input SHA256. No code changes have been selected or made here; root owns any subsequent local-only candidate and production investigation. Owner's latest instruction prohibits deployment/trading/config/financial changes.
