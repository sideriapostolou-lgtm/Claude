# Claude Code → Codex takeover inventory

Evidence snapshot: `/workspace/nightcrawler-feed-learning` at `91250c6598f4b866d7601ac0ead3e66ba55996cd`, read 2026-10-15 15:23 UTC. This is a documentation-only inventory; it does not migrate credentials, account permissions, Railway services/data, or scheduled jobs.

## Current state from the pinned records

Codex owns the Kalshi lane and the handoff says Codex accepted all lanes on Oct 14. The deploy branch is documented as `claude/nightcrawler-memecoin-bot-Gwnb1S`. Repository ownership does not establish infrastructure access or move data. The service inventory in [the dated handoff](../../nightcrawler-feed-learning/docs/HANDOFF_CLAUDE_TO_CODEX_2026-10-14.md) is historical: bot service plus `nightcrawler-data` volume, and a separate read-only `kalshi-recorder` service plus its own `/data` volume. Current service state was not freshly checked.

At the newest pinned status entry, dated Oct 15 8:14 AM PDT, EXEC-DELAY-001 remains open: repeated pre-forecast gaps excluded the five full learner slots, so the next step is gap attribution while preserving admission rules and losses. A frozen ledger diagnostic is separate and unreleased; original/inverse/no-trade comparison has not started. The real Kalshi total stop was latched in the recorded 8:11 AM status; do not replay old restart/cap decisions.

PR60's observe-only learner release was separately verified in the records, but at 8:09 AM it had zero forecasts and zero scores, six unknowns, and null Brier scores. Prospective forecast/official-label evidence remains pending; no accuracy or profit result is established. TJR-MNQ-001 remains blocked despite explicit offline reprioritization: authentic MNQZ2025 development bars and account costs are absent; trades are zero, P&L unknown, holdout unopened, paper not started, live disabled. PR47's release/restart completion is separate from both EXEC and the missing TJR inputs.

The handoff assigns Codex the recorder feasibility report and daily step-up check after saying Claude reminders were disabled. That records responsibility, not schedule migration or current timer state. The recorder report/storage review completion was not verified. Weather/watcher and Lucas work has preserved historical artifacts, but this pinned current queue does not establish a fresh assignment or operational status. The model CLI role launch remains blocked on normal sign-in refresh; chat delegation is usable.

## Portable next steps

1. On each new task, re-read [AGENTS.md](../../nightcrawler-feed-learning/AGENTS.md), [COORDINATION.md](../../nightcrawler-feed-learning/docs/COORDINATION.md), newest [WORKLOG.md](../../nightcrawler-feed-learning/docs/WORKLOG.md), the [handoff](../../nightcrawler-feed-learning/docs/HANDOFF_CLAUDE_TO_CODEX_2026-10-14.md), [continuity index](../../nightcrawler-feed-learning/docs/CONTINUITY_INDEX.md), and [model workflow](../../nightcrawler-feed-learning/docs/MODEL_WORKFLOW.md) at the then-current deploy-branch SHA.
2. Continue EXEC gap attribution with original evidence and exclusions intact; keep the frozen ledger diagnostic separate.
3. Gather prospective eligible learner forecasts and official same-terms labels, scoring before updates; make no performance claim until evidence supports it.
4. For TJR, obtain and verify the MNQZ2025 development export, mapping, timestamp/bar convention, and costs, then follow the saved validation protocol. Keep paper/live disabled.
5. Check the recorder report and storage review against fresh recorder evidence. Do not infer timer transfer from ownership wording.
6. Refresh CLI sign-in normally before the bounded role-launch check. Locate primary evidence before reviving weather/watcher or Lucas work.

Exact queue evidence and status boundaries are captured in [TAKEOVER_INVENTORY.json](TAKEOVER_INVENTORY.json). It records only what the pinned documents support; no production or fresh data checks were made.

