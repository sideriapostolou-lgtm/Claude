"""Offline native buffered feed with actual KalshiLiveDesk run/step/checkpoint.
No repo writes, credential inputs, network, live gate, or invented per-cycle work.
"""
from __future__ import annotations
import ast
import asyncio
import contextlib
import copy
from dataclasses import replace
import hashlib
import inspect
import json
import logging
from pathlib import Path
import platform
import signal
import socket
import sys
import textwrap
import threading
import time

ROOT=Path('/workspace/nightcrawler-next-evidence')
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'tests')]
import websockets
from websockets.asyncio.connection import Connection
from websockets.frames import Frame, OP_TEXT
from websockets.protocol import Protocol, Side
from nightcrawler import speeddesk_kalshi_ws as ws_module
from nightcrawler import speeddesk_live as live_module
from nightcrawler.config import Settings
from nightcrawler.speeddesk_kalshi_ws import KalshiMarketWS, MarketState, MarketDataGap
from test_speeddesk_live import make_desk, TICKER

OUT=Path('/workspace/shared/controller-replay.json')
TOTAL=500
T=1791475200.0
logging.disable(logging.CRITICAL)
def sha(data): return hashlib.sha256(data).hexdigest()
def denied(*args,**kwargs): raise AssertionError('Offline replay forbids network/client construction/orders')
def work(seconds):
    until=time.perf_counter()+seconds
    while time.perf_counter()<until: pass

class MemoryLedger:
    """Zero injected latency; persistence/chain durability deliberately not modeled."""
    def __init__(self,*args): self.kv={}; self.receipts=[]; self.saves=0
    def verify_chain(self): return True, None
    def get_kv(self,key): return copy.deepcopy(self.kv.get(key))
    def set_kv(self,key,value): self.kv[key]=copy.deepcopy(value); self.saves+=1
    def set_synchronous(self,value): pass
    def transaction(self): return contextlib.nullcontext()
    def append_receipt(self,kind,payload,**kwargs): self.receipts.append((kind,copy.deepcopy(payload)))
    def close(self): pass

candidate_source=textwrap.dedent(inspect.getsource(KalshiMarketWS._session))
candidate_tree=ast.parse(candidate_source)
baseline_tree=copy.deepcopy(candidate_tree)
removed=baseline_tree.body[0].body[-1].body.pop()
assert ast.unparse(removed)=='await asyncio.sleep(0)'
roundtrip=copy.deepcopy(baseline_tree)
roundtrip.body[0].body[-1].body.append(removed)
assert ast.dump(roundtrip,include_attributes=False)==ast.dump(candidate_tree,include_attributes=False)
namespace={}
exec(compile(ast.fix_missing_locations(baseline_tree),'<offline-without-boundary-yield>','exec'),vars(ws_module),namespace)
baseline=namespace['_session']
payloads=[{'type':'orderbook_delta','sid':7,'seq':i+2,'sending_ts_ms':int(T*1000),
           'msg':{'market_ticker':TICKER,'side':'yes','price_dollars':'.4','delta_fp':'.01','ts_ms':int(T*1000)}} for i in range(TOTAL)]
chunk=b''.join(Frame(OP_TEXT,json.dumps(row,separators=(',',':')).encode()).serialize(mask=False) for row in payloads)
class Transport:
    def __init__(self): self.pauses=self.resumes=0
    def pause_reading(self): self.pauses+=1
    def resume_reading(self): self.resumes+=1
    def set_write_buffer_limits(self,*args): pass
    def write(self,data): denied()

async def scenario(candidate, book_work, account_enabled, replicate):
    directory=Path(f'/workspace/shared/controller-replay-data-{replicate}-{int(candidate)}-{book_work}-{int(account_enabled)}')
    assert not directory.exists(), 'Fresh directory required: do not restore prior fake state'
    old_ledger=live_module.Ledger
    live_module.Ledger=MemoryLedger
    try:
        desk,account,fakeclock=make_desk(directory,mode='paper',confirm=None,keys=False)
    finally: live_module.Ledger=old_ledger
    assert not desk.settings.kalshi_key_id and not desk.settings.kalshi_private_key
    assert desk.settings.speeddesk_kalshi_mode=='paper'
    desk.client_factory=denied
    account.create_order=denied
    account.cancel=denied
    start_wall=time.perf_counter()
    logical_clock=lambda:T+time.perf_counter()-start_wall
    desk.clock=logical_clock
    fakeclock.now=logical_clock
    snapshot=desk.snapshot()
    current_books=dict(snapshot.books)
    desk.snapshot=lambda:replace(snapshot,books=dict(current_books))
    # Exercise real startup/reconciliation/_start_io/_read but leave the paper
    # admission guard closed; all fake account lists start empty.
    if account_enabled: desk.client=account
    transport=Transport()
    connection=Connection(Protocol(Side.CLIENT,max_size=1_000_000),max_queue=16,ping_interval=None)
    connection.connection_made(transport)
    connection.data_received(chunk)
    assert len(connection.recv_messages.frames)==TOTAL
    callbacks=0
    received_ages=[]; sequences=[]; cycles=[]; checkpoints=[]; sent=[]; wake_sets=[]
    feed_stop=threading.Event(); controller_stop=threading.Event()
    original_step=desk.step
    original_checkpoint=desk.checkpoint
    async def observed_step():
        before=time.perf_counter(); before_callbacks=callbacks
        await original_step()
        cycles.append({'started_s':before-start_wall,'completed_s':time.perf_counter()-start_wall,
                       'start_callbacks':before_callbacks,'end_callbacks':callbacks,
                       'wall_ms':(time.perf_counter()-before)*1000,'account_reads':account.reads})
    def observed_checkpoint(*args,**kwargs):
        before=time.perf_counter()
        original_checkpoint(*args,**kwargs)
        checkpoints.append({'at_s':before-start_wall,'callbacks':callbacks,'durable':kwargs.get('durable',False),
                            'wall_ms':(time.perf_counter()-before)*1000})
    desk.step=observed_step; desk.checkpoint=observed_checkpoint
    def on_book(book):
        nonlocal callbacks
        callbacks+=1
        sequences.append((book.sequence,book.side))
        current_books[(book.window,book.side)]=book
        desk.on_book(book)
        if desk.wake.is_set(): wake_sets.append(callbacks)
        if callbacks%2==0: work(book_work)
        if callbacks==TOTAL*2: feed_stop.set()
    feed=KalshiMarketWS(Settings(kalshi_key_id=None,kalshi_private_key=None,speeddesk_kalshi_mode='paper',
                         speeddesk_kalshi_live_confirm=None),tickers=lambda:frozenset({TICKER}),
                       on_book=on_book,on_trade=denied,on_status=lambda row:None,clock=logical_clock,ws_connect=denied)
    feed.connected=True
    feed.state=MarketState(frozenset({TICKER}))
    feed.state.apply({'type':'subscribed','id':1,'msg':{'sid':7,'channel':'orderbook_delta'}},T)
    feed.state.apply({'type':'orderbook_snapshot','sid':7,'seq':1,'msg':{'market_ticker':TICKER,
                      'yes_dollars_fp':[['.4','2.5']],'no_dollars_fp':[['.6','2.5']]}},T)
    class Adapter:
        async def send(self,message): sent.append(json.loads(message))
        async def recv(self):
            message=await connection.recv()
            received_ages.append(logical_clock()-T)
            return message
    original_socket=socket.socket
    socket.socket=denied
    task=asyncio.create_task(desk.run(controller_stop))
    try:
        # Equal pre-feed startup state; for fake-account mode allow real thread
        # results to complete before timing the burst, with bounded readiness.
        deadline=time.perf_counter()+2
        while not cycles:
            await asyncio.sleep(.001)
            assert time.perf_counter()<deadline,'Controller initial step did not finish'
        before_cycles=len(cycles); before_checkpoints=len(checkpoints); before_reads=account.reads
        burst_start=time.perf_counter(); burst_cpu=time.process_time()
        failure=None
        try:
            await (KalshiMarketWS._session if candidate else baseline)(feed,Adapter(),frozenset({TICKER}),feed_stop)
        except MarketDataGap as exc: failure=str(exc)
        burst_end=time.perf_counter(); burst_cpu=time.process_time()-burst_cpu
        cycles_during=copy.deepcopy(cycles[before_cycles:])
        checkpoints_during=copy.deepcopy(checkpoints[before_checkpoints:])
        reads_during=account.reads-before_reads
        # Stop separately after snapshot so shutdown cannot inflate measured work.
        controller_stop.set(); desk.wake.set()
        await asyncio.wait_for(task,3)
        assert callbacks%2==0
        assert all(sequences[i][0]==sequences[i+1][0] and sequences[i][1]=='up' and sequences[i+1][1]=='down'
                   for i in range(0,len(sequences),2))
        assert all(c['start_callbacks']%2==0 and c['end_callbacks']%2==0 for c in cycles)
        assert not account.creates and not account.cancels
        assert desk.book.open_cost_usd==0 and not desk.intents
        return {'candidate':candidate,'book_cpu_work_s':book_work,'fake_account_reconciliation':account_enabled,
                'replicate':replicate,'received_messages':len(received_ages),'completed_messages':callbacks//2,
                'failure':failure,'burst_wall_s':burst_end-burst_start,'burst_cpu_s':burst_cpu,
                'last_message_age_s':received_ages[-1],'max_message_age_s':max(received_ages),
                'received_message_ages_s':received_ages,'completed_controller_cycles_during_burst':len(cycles_during),
                'controller_cycles':cycles_during,'checkpoints_during_burst':checkpoints_during,
                'fake_account_reads_during_burst':reads_during,'cycles_total_including_startup_shutdown':len(cycles),
                'checkpoints_total_including_shutdown':len(checkpoints),'ready_wake_callback_count':len(wake_sets),
                'remaining_buffered_frames':len(connection.recv_messages.frames),
                'callback_sequence_sha256':sha(json.dumps(sequences).encode()),'both_sides_atomic':True,
                'fake_orders':len(account.creates),'fake_cancels':len(account.cancels),
                'last_reason':desk.reason,'source_gate_paper':True}
    finally:
        socket.socket=original_socket
        if not task.done():
            task.cancel(); await asyncio.gather(task,return_exceptions=True)
        desk.close()

async def main():
    signal.alarm(65)
    source_paths=[ROOT/'src/nightcrawler'/name for name in ('speeddesk_live.py','speeddesk_live_model.py',
                  'speeddesk_kalshi_ws.py','speeddesk_model.py','speeddesk_metrics.py','ledger.py','config.py')]
    source_paths+=[ROOT/'tests/test_speeddesk_live.py']
    before={str(p):sha(p.read_bytes()) for p in source_paths}
    started=time.perf_counter(); results=[]
    for replicate in range(2):
        for account_enabled in (False,True):
            for book_work in (0,.005,.0058):
                for candidate in ((False,True) if replicate==0 else (True,False)):
                    row=await scenario(candidate,book_work,account_enabled,replicate)
                    results.append(row)
                    print(json.dumps({k:row[k] for k in ('replicate','candidate','book_cpu_work_s','fake_account_reconciliation',
                        'completed_messages','failure','burst_wall_s','completed_controller_cycles_during_burst',
                        'checkpoints_during_burst','fake_account_reads_during_burst')}),flush=True)
    after={str(p):sha(p.read_bytes()) for p in source_paths}
    out={'script_sha256':sha(Path(__file__).read_bytes()),'python':sys.version,'platform':platform.platform(),
         'websockets':websockets.__version__,'source_commit':'0fc4115616bd85de5caf9c6259828cdccccc5abb',
         'application_commit':'c8e37e5504aad04da0521b3f95c17f86dac42899','sources_before':before,'sources_after':after,
         'source_unchanged':before==after,'candidate_session_source_sha256':sha(candidate_source.encode()),
         'baseline_ast_source_sha256':sha(ast.unparse(baseline_tree).encode()),
         'ast_difference':'Only remove the final complete-message await asyncio.sleep(0); assert AST inverse identity.',
         'actual_controller':'KalshiLiveDesk.run()/step()/on_book()/checkpoint(), not nonexistent KalshiLiveController symbols',
         'parameters':{'frames':TOTAL,'source_timestamp':T,'native_chunk_bytes':len(chunk),'chunk_sha256':sha(chunk),
             'arrival':'same native data_received fully prebuffered burst','MIN_STEP_S':live_module.MIN_STEP_S,
             'IDLE_STEP_S':live_module.IDLE_STEP_S,'SAVE_EVERY_S':live_module.SAVE_EVERY_S,
             'book_cpu_work_s':[0,.005,.0058],'controller_work_injected':False,
             'replicates':2,'order':'baseline/candidate then candidate/baseline','freshness_guard':'unchanged 3seconds',
             'startup':'wait for first real step, exclude from burst counts','shutdown':'exclude from burst counts'},
         'results':results,'total_wall_s':time.perf_counter()-started,
         'limits':['Synthetic prebuffered input, no production ingress timestamps or representative traffic.',
                  'Added per-message book CPU is an explicit stress input, not measured production callback cost.',
                  'Actual controller cycle, callback, model, heartbeat and checkpoint methods are executed; thin wrappers only record observations.',
                  'MemoryLedger replaces persistence and receipts; no latency injection, disk fsync/history cost or crash semantics.',
                  'Empty fake account uses actual thread I/O, startup, reconciliation and paper cancellation/admission gate; no orders, fills, historical ledger load.',
                  'Paper gate closes clock HTTP probe and trading; cannot generalize costs to an active live order path.',
                  'Native Connection private assembler prebuffering is harness-only; reconnect/fallback not executed.',
                  'Controller has real20ms minimum spacing and periodic/dirty checkpoint gates; cycle amplification does not imply checkpoint per message.',
                  'Stale rejection may be from original source age, synthetic callback work and real scheduled work combined; no production causal attribution or chosen fix.']}
    OUT.write_text(json.dumps(out,indent=2)+'\n')
    signal.alarm(0)
    print(json.dumps({'output':str(OUT),'sha256':sha(OUT.read_bytes()),'source_unchanged':before==after,'total_wall_s':out['total_wall_s']}),flush=True)
if __name__=='__main__': asyncio.run(main())
