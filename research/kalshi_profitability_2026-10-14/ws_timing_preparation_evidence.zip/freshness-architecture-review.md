# EXEC-DELAY-001: source-age attribution architecture review

Recorded 2026-10-14 8:56 PM PDT / 2026-10-15 03:56 UTC. Read-only source review by delegated architecture worker; integration and release owner: `/root`. Repository `/workspace/nightcrawler-next-evidence`, immutable HEAD `0fc4115616bd85de5caf9c6259828cdccccc5abb`; app revision `c8e37e5504aad04da0521b3f95c17f86dac42899`. `git diff` between these revisions is empty for the six runtime files reviewed below. Initial `git status --short` was empty. No repository edits, commits, production queries, credentials, account calls, or deployments were made. This shared report is the sole output. No held-out strategy data opened.

## Decision

Current evidence supports retaining both complete-message `sleep(0)` boundaries and adding bounded attribution. It does **not** support a controller scheduling correction, batch size, time budget, event suppression, or reversal of PR56. The 53 source-age warnings remain unresolved. The finite account-resumption and loop-lag result is useful evidence on a different surface, not a freshness pass.

The parent's proposed native `ClientConnection` observer is a reasonable narrow next measurement: complete-message protocol acceptance → successful `recv` return establishes a local library-residence/scheduling lower bound. It must use exact message ordinals, report loss/unknown explicitly, and retain the measurement limits below. Controller-cause and checkpoint-reason observations are additionally needed before attributing that local delay to wake amplification. No production fix is selected here.

## Actual control flow and plausible mechanisms

1. `speeddesk_kalshi_ws.py:327–344` receives one whole message, decodes/applies it, reports status, delivers all book/trade callbacks, then yields. Both outcome callbacks remain in one atomic synchronous region. Coinbase similarly processes every tick from one message on one `received_at` before yielding (`speeddesk_feeds.py:423–438`). Those boundaries let already-ready account work progress. They also let other ready tasks run. Their scheduling effect is not equivalent to a measured increase in actual controller work.

2. Actual controller callbacks set `wake` only on accepted tick / accepted twin book paths (`speeddesk_live.py:1038–1042,1062–1066`); trade callbacks do not directly set it (`1068–1070`). `asyncio.Event` already coalesces repeated sets while set. `run()` clears it before `step()`, waits for the event or a 250 ms timeout after the step, then enforces a 20 ms minimum start interval (`90–91,2507–2521`). Multiple books in one message do not imply multiple controller turns. An event during an awaited step can make the later wait return immediately; an event while already set cannot enqueue another independent event. The existing 20 ms minimum limits nominal turn frequency, but is not an upper bound on a turn's cost or on local queue residence.

3. An actual step performs stop latching, ladder/market/twin/pull observations and unsafe cancellation checks before decision work (`2377–2427`). Reconciliation is separately gated by startup/last-sync/account state (`2401–2406`). More turns can increase synchronous work even with identical input message counts, but a 12 ms-per-Event surrogate does not quantify this path. The actual object, initial state, callback routes and activity must be exercised before selecting a correction.

4. Checkpoints are not one-per-wake. Live heartbeat saves on minute status, five seconds, mandatory stop/owner state, or dirty/pending after one second (`2449–2453,2478–2480`); reconciliation saves immediately for money changes or a mandatory save (`1803–1811`). The full save performs synchronous state construction, ledger transaction, logs, and occasional mirror/panel (`918–1008`). These are real shared-loop costs and cannot be deferred indiscriminately. `_record()` appends pending data (`625–629`), so adding diagnostic records on every turn can itself change save frequency.

5. Practice is an independent source of activity-driven persistence. Every accepted book refreshes the shared snapshot, calls the live companion, and invokes practice `advance()` (`speeddesk.py:279–295`). `decisions()` checkpoints whenever pending is nonempty (`245–246`); regular practice `step()` also checkpoints pending/five-second state (`626–627`). Trade callbacks process maker/practice events (`297–304`). Practice/live twin work can therefore amplify independently of a live controller wake. Do not label practice checkpoint growth as live wake growth.

6. Freshness failures can induce additional work without being caused by that work. Kalshi invalidates the connection before awaiting its close (`speeddesk_kalshi_ws.py:299–315`); gaps cancel practice state and invalidate the live snapshot (`speeddesk.py:328–342`). REST book polling begins when WS books are not fresh (`speeddesk_kalshi.py:260–289`), and REST trade polling when WS maker coverage is absent (`291–333`). Transport changes explicitly invalidate queue priority (`201–211`). A feedback chain is plausible: initial old message → disconnect/gap/fallback → extra work → slower subsequent processing. Count and timestamp fallback and reconnect activity to avoid reversing cause and effect.

7. The existing source-age guard also catches genuinely old provider source data, old provider publication, local kernel/TLS backlog, library buffering, event-loop dispatch delay, parsing delay, or wall-clock offset/jumps. Multiple mechanisms may coexist. The warning alone cannot choose among them.

## Timestamp semantics and limits

Kalshi `_fresh_ms` compares `now - raw_ms/1000` with `[-0.25,3]`, rejects outside it, and clamps accepted slight-future values to `now` (`speeddesk_kalshi_ws.py:68–76`). Optional top-level `sending_ts_ms` is checked first as a publication/network-domain timestamp (`158–159`). Trade `msg.ts_ms` is then checked as `trade_engine` (`162`); book delta `msg.ts_ms` as `book_engine` (`207–208`). Snapshot publication is explicitly not source-book capture time (`181–184`), so a timestamp-free snapshot remains unproven until a timestamped delta (`226–232`). Existing parser restrictions remain appropriate.

At `336`, Python evaluates `json.loads(payload)` **before** `self._clock()`: the current Kalshi guard's `now` is taken after JSON decoding. Book `at` and Trade receipt use that same value (`177–180,236–241`). It is application processing time, not kernel receipt. Coinbase samples `received_at` after `wait_for(ws.recv())` and before JSON decode (`424–427`); TickReceipt's monotonic mark is later, at callback entry (`speeddesk.py:249–259`). Those marks have different scopes. Do not silently move either source guard's clock earlier when adding telemetry.

Even a correctly matched protocol-acceptance stamp occurs only when this event loop processes the incoming frame. It cannot observe time bytes spent in the kernel, TLS transport, pending event-loop dispatch, provider infrastructure, or network. A short acceptance→recv interval therefore **does not prove provider delay**. A long interval does positively establish local delay after the mark. The full age identity uses an uncertain upstream term:

`source→guard age = source→local protocol acceptance (clock/upstream/unobserved local) + acceptance→recv + recv→guard`.

Use monotonic clocks for the local terms. Record paired wall/monotonic marks and a wall-versus-monotonic drift indicator to detect discontinuities; never subtract unrelated monotonic clock domains. Provider sending minus engine time is a provider-timestamp relationship, not measured network latency. Preserve both raw valid numeric stamps on rejected messages even if the first guard prevents the second guard running. Missing/invalid values stay typed missing/invalid, not zero.

## Minimum bounded observability design

### Native transport observer

Use the documented `create_connection` customization point with a small native client subclass. Call the original handshake/frame behavior exactly once. After successful base `process_event`, record a stamp only for a completed data message: FIN TEXT/BINARY, or FIN CONT belonging to a fragmented message. Control frames and handshake responses do not consume message ordinals. Record earliest-fragment acceptance too only if deliberately required; complete-message acceptance alone cannot measure fragment assembly wait before the last fragment.

Keep no payload, prices, credentials, authentication headers or socket state. Store only connection/session epoch, monotonically increasing complete-message ordinal, paired clocks, and diagnostic state. A deque bounded at 256 is an observational retention limit, never a feed capacity. Increment producer ordinals even when a retained stamp must be evicted; count evictions. On every successful `super().recv()` increment the consumer ordinal and match that exact stamp before returning, without any new await. Canceled/failed recv must not pop or advance consumer ordinal. An evicted expected ordinal yields `unknown/lost`; it must never be replaced by the oldest remaining stamp. A mismatch not explained by recorded eviction disables association for the connection. Reset on connection replacement. Observer exceptions must not change the base result or base exception.

The current consumer is serialized and uses `recv`, not `recv_streaming`. Any support for concurrent receivers/streaming must be explicitly implemented and tested or recorded unavailable. Do not claim safety merely because no such callers are expected. No private queue inspection is needed. `max_queue=16` is a flow-control watermark, not a proof that at most 16 messages can be buffered; native tests preload more than 16 frames in one `data_received` invocation.

Important environment limit: this shell's plain Python is 3.12.14 with websockets **16.0**, while `pyproject.toml:14` declares `>=13,<16` and Docker specifies Python 3.12. Source inspection here confirms the proposed hooks on 16.0, not the deployed version. Validate the actual target dependency version and all supported contracts used by the patch; do not rely solely on this interpreter. Python 3.11 versus 3.12 `wait_for` scheduling differences already appear in `tests/test_speeddesk_feed_fairness.py:140–145`.

### Reader and controller records

Capture receive-call start, successful receive return, JSON decode start/end, unchanged guard-now, apply completion/rejection, full callbacks completion, and yield-resumed marks. Keep message kind/source domain, outcome category, connection epoch/ordinal, matched stamp state, raw validated source/publication timestamps and numeric ages. Record rejection metadata without executing callbacks or swallowing/replacing `MarketDataGap`. Do not parse raw JSON twice solely for observation.

Use fixed counters for accepted message/tick/book/trade paths, Event set attempts, unset→set transitions, actual step starts/completions and wait outcomes. Step causes should be bitsets/explicit categories, allowing overlap: initial, event observed after a step, timeout, signal during step, and signal during minimum-step wait. `Event.set` count is not step count. Do not add callback-level financial work to collect them.

Record checkpoint call-site reasons and pending-event category counts: periodic/status, dirty/pending, reconciliation money change, mandatory stop/owner change, startup/shutdown and explicit other existing callers. Reasons can overlap; retain a mask. Track actual fallback requests/completions/errors, transport transitions, and reconnect start/end. These prevent the observed trading-activity confounder from masquerading as a wake effect.

Publish fixed aggregates and a bounded incident ring through existing status/checkpoint publication, **without** appending a new pending receipt for each observation or requesting a checkpoint. Record dropped incident details, producer totals, published totals, connection resets, observer error/disabled state, buffer occupancy, and coverage boundaries. Bounded observation may omit detail; financial messages must never be dropped/coalesced. A ring can include all stale incidents up to its cap plus recent predecessor summaries, but absence claims require retained counters and complete reporting-tail coverage.

Existing WorkTrace is appropriate for synchronous work only. It retains 512 slow spans >=5 ms, caps details at 32, records fixed per-section counts/maxima, and has top-level quiet-work lower-bound bins (`speeddesk_worktrace.py`). Counts do not measure total per-section CPU. Nested spans and whole-span CPU must not be summed; query omissions/evictions stay explicit. Join incident local intervals to the existing overlap/lower-bound output at bounded incident/publication points, not on every message. Do not wrap asynchronous `step()` in `work_span`: other tasks run across awaits, contaminating CPU attribution and shared nesting. Separate wall step durations from truly synchronous chunk work.

## Choosing a later correction

- Large matched acceptance→recv delay plus contained checkpoint/callback work establishes some local contribution. It still does not establish that PR56 caused it. Optimize the identified redundant synchronous operation only after actual-controller replay confirms behavior and costs.
- Large event→step count growth under matched input/account activity, with measured redundant synchronous sections, supports a specific controller-work hypothesis. Preserve immediate cancel, stop, account/reconcile, financial journal and post-delay quote checks; do not introduce generic batch/time caps.
- Fresh acceptance and recv with old engine data but newer publication separates the timestamp domains; it can indicate upstream engine→publication age, subject to provider semantics. It does not justify accepting the stale data.
- Old publication at acceptance with little later delay leaves provider/network/kernel/event-loop-before-acceptance unresolved. Stop the claim there. A separate independent ingress/clock measurement may be needed; do not call it provider latency by subtraction.
- Recurring fallback/reconnect work following the first stale incident identifies possible downstream amplification, not the initiating cause. Keep the initiating event and recovery sequence distinct.

The native surrogate script is an existence proof only. It exercises native reader/market-state with invented 5 ms callback and 12 ms Event-worker costs; the actual controller is different. No rerun is needed to re-establish that limited claim. Any new replay should use real controller/runner paths, pinned initial synthetic account state, deterministic identical arrivals, native framing, no network/key/order access, and compare outputs/state plus observed causes. Synthetic results still do not replace production attribution.

## Concrete validation cases for the proposed measurement

1. Native buffered 1/16/64/300-message sessions: exact ordinal matching and positive queue intervals; overflow yields unknown for evicted ordinals and later recovers exact matches. Verify no stale stamp is reassigned and all native callbacks/state equal unobserved behavior.
2. Fragmented TEXT/BINARY interleaved with PING/PONG/CLOSE, empty data messages and multiple complete messages in one transport invocation: one stamp per actual returned message, control frames consume none. Explicitly test final CONT matching.
3. Cancel/timeout before any data, after partial fragments, and at final-fragment readiness: native recv cancellation safety retained, subsequent message gets its own stamp, no pop on error. Verify malformed UTF-8/connection close cannot leave a seemingly valid association for a later session.
4. Observer clock failure, invalid clock values, deque/method exception, association mismatch and unsupported streaming/concurrent use: diagnostic degrades to explicit unavailable; base frame/recv/callback exceptions and order remain identical, including cancellation.
5. Queue residence versus source age: fresh source enqueued then local delay causes stale rejection; already-old source delivered immediately remains stale with small local delay; fresh sending/old engine, old sending/fresh engine, absent/invalid sending, slight future within skew, too-future, wall jump with monotonic continuity. Never refresh an accepted receipt/source timestamp or change 3 s / 250 ms bounds.
6. Preserve full-message callback atomicity and every event for Coinbase multi-trade messages and Kalshi two-outcome books/trades. Existing fairness, dedup, sequence/reversal, snapshot-unproven, invalidation-before-close and cancellation tests remain required.
7. Actual live `run()` with fake account and native reader: multiple sets before clear, sets during awaited reconcile, timeout-only turns, sets during minimum-step wait; verify cause counters reconcile and controller outputs/cancel checks match the original. No claim that a wake always causes a checkpoint.
8. Actual practice/live persistence: quiet periodic saves, changed account fact within one second, immediate fill/settlement/stop/owner save, journal-before-send, pending practice decisions, status/mirror paths. Observation enabled/disabled must produce identical orders, cancellations, ledger receipts, cash/exposure/fees/losses, stop/resume state and financial checkpoint ordering. Status-only diagnostic payload differences are allowed; extra saves are not.
9. REST fallback after gap versus healthy WS, reconnect and transport change: attempts/completions/cause chronology recorded without making extra requests or preserving stale queue priority.
10. Finite reporting cohort: overflow, disabled observer, omitted work spans, delayed publication and session reset; reconcile producer/detail/publication totals through a bounded tail. Benchmark observer overhead on a pinned supported native runtime, separating instrumentation CPU from business work. Performance numbers are measurements, not invented correctness thresholds.

Tests above are a proposed acceptance set, not executed checks. This review ran source inspection, Git revision/diff/status checks and dependency introspection only. Full tests/mypy/Ruff were not rerun because no application change was made. Root owns implementation, independent exact-patch review, required release checks, exact deployment/restart accounting and repeated complete-window production evidence. EXEC-DELAY-001 stays open; strategy comparison stays unstarted; money limits, stop/resume history and all recorded losses remain unchanged.

## Exact source inventory (SHA256)

See adjacent hash manifest appended below; hashes cover the source actually read, not a future patch. Architecture worker model launch identity/usage/cost receipts are not exposed in this worker context; integration owner should preserve its launch receipt and not infer an Astra label solely from the role name.

```text
1a3c5ccf196784ff5c8dd72c8061af8406c6f0b9584e0c3a36403d72cb0b93ce  AGENTS.md
70dd67f9904715ed522da4e875e4cd5e3a508e4a9ccd04c7b762fa0b1375cfa5  docs/COORDINATION.md
f7c687489bf1718454c4eedbebe20b882e7d0135d8b55daa98158b6e0e7da7ba  docs/MODEL_WORKFLOW.md
a63d53ee88c481c15d721f9baa5a0743434c001f51f65b493be7242d78e32f31  docs/WORKER_HANDOFF_TEMPLATE.md
16db24b6a9fc684b06f1ce0d2a0731fcae5fb1067cec2ba60ae4f6f19df994a4  research/kalshi_profitability_2026-10-14/FEED_FAIRNESS_POSTRELEASE.md
79a8ad7fc10879035297e2af4d87af1bff758b4f89c2adae3464fe812235477d  src/nightcrawler/speeddesk.py
be42df49ce55681676c914757e3870aad4f291abbac9ec8988f058838a77739a  src/nightcrawler/speeddesk_live.py
4a942d649af275cc6ad7b467462236e66c9a629cab0920e1a1adb3c24982dffd  src/nightcrawler/speeddesk_feeds.py
5e0193959c76574ddd7f86c0d7ea0dacdaf9a382e332a21ba34579158411e745  src/nightcrawler/speeddesk_kalshi_ws.py
53727b3d3f2ec6790469d53d8fb330f7501ad1838c558c887ea95c54840d8f82  src/nightcrawler/speeddesk_kalshi.py
cc8b3770d125bed718144b7aaa4d60ea4408ef3142543d115afd5125b85195b2  src/nightcrawler/speeddesk_worktrace.py
41fbf76947a1792fdc1f0c9a51e9352d0d4d160b2b968fc65691f9c0386ec4f8  src/nightcrawler/speeddesk_workbins.py
b6da72d051d8cf6da28929de13d6652ec0124f9467c76ec20f4c2b654e393ca2  tests/test_speeddesk_feed_fairness.py
64d3c7776cd523fa70d510b78b4dd0912784bf6920106ea8e3c7734b654cf35e  tests/test_speeddesk_feed_fairness_independent.py
f1b85cd952b737bfea97fd43edb1c9cc43e1d4f548573ce1d9e7eff5beab76b5  tests/test_speeddesk_live_saves.py
126259e762654b908f49c77f979ab0c1df83b76de04a8ac6f87cd0705071408b  tests/test_speeddesk_kalshi_ws.py
bd3e8ba6bbf97b332c452e13d6cfe34db3bf64c46d3864d9f5048553f46998e6  pyproject.toml
720430ae085b53440493b6443c6df136be9ec00b3ca3e75647310d66245c3043  Dockerfile
eec9ac53e3802fa53b558ae71d342ddbdbec30bcf1cdd95fe7e94be08c0f039f  /workspace/shared/fairness-work-amplification-proof.py
```

## Integration-owner refinement after initial review

Root proposes staging the measurement: first implement native matched receipt plus reader/apply/rejection timings, prior-message work/yield timing, incident WorkTrace overlap, and 60-second native diagnostic counters; leave the controller unchanged until positive local-residence evidence warrants cause-specific measurement. This is acceptable and narrower than implementing all suggested follow-up counters at once. It is sufficient to measure a local contribution, not to identify controller causality or choose a scheduling fix. The controller/checkpoint/REST counters above are conditional next-stage measurements.

Preserve fail-closed sequencing: on a rejected frame, capture only minimal diagnostic facts in memory, rethrow the original exception, invalidate connection/shared snapshot through the existing finally path, and only then query bounded WorkTrace/report the incident in the existing gap-emission path. Do not let diagnostic JSON/logging/query work run before known-stale state is invalidated. Use stored acceptance/apply monotonic marks for the delayed overlap query. Retention loss and omitted details remain explicit.

A periodic native report should include connection epoch, accepted-message total, successful receive total, known/lost/unknown association totals, evictions, observation-disabled/errors, interval boundaries and report publication time. This creates a finite cohort accounting surface rather than relying on unqualified cumulative maxima. Do not route those diagnostics through `_record()`/pending and create extra financial checkpoints. A ring/detail cap is not a trading/event-processing cap.

Exact implementation review is pending code from the integration owner and observer worker; this design report is not acceptance of an unseen patch.
