# Actual controller replay: bounded offline evidence

Base checkout `/workspace/nightcrawler-next-evidence` at `0fc4115616bd85de5caf9c6259828cdccccc5abb`; recorded application source `c8e37e5504aad04da0521b3f95c17f86dac42899`. Relevant source SHA256 hashes before/after match in the result JSON. No repository edits, commits, network, credential reads, account calls, orders or production queries were made by this worker. Other workers may write independently.

The requested `KalshiLiveController._run/_wake/_cycle` names do not exist here. The actual path is `KalshiLiveDesk.run()` (`speeddesk_live.py:2507`) -> `step()` (`:2377`), with `on_book()` (`:1062`) setting `self.wake`; `_heartbeat()` (`:2429`) decides whether to call real `checkpoint()` (`:919`). That actual path runs in this experiment, including normal loop probes. `MIN_STEP_S=0.02`, `IDLE_STEP_S=0.25` and all save gates stay unchanged.

## Result

All 24 scenarios completed all 500 messages with no stale failure, no fake orders/cancels, both-side callback atomicity preserved, and **zero checkpoints during each burst**. Two replicates reverse baseline/candidate order. Baseline removes exactly the final complete-message `await asyncio.sleep(0)` by an AST transform with inverse identity assertion; parser, callbacks, controller and freshness guards stay unchanged.

| Actual path | Explicit synthetic callback CPU/message | Baseline completed cycles during burst | Yielding completed cycles during burst | Baseline burst seconds | Yielding burst seconds |
|---|---:|---:|---:|---:|---:|
| Paper, no account | 0 ms | 0 | 1 | .0266-.0272 | .0305-.0313 |
| Paper, no account | 5 ms | 0 | 83 | 2.5439-2.5494 | 2.5681-2.5735 |
| Paper, no account | 5.8 ms | 0 | 83 | 2.9422-2.9465 | 2.9685-2.9752 |
| Paper, fake account reconciliation | 0 ms | 0 | 1 | .0259-.0274 | .0311-.0318 |
| Paper, fake account reconciliation | 5 ms | 0 | 72-76 | 2.5472-2.5549 | 2.5702-2.5717 |
| Paper, fake account reconciliation | 5.8 ms | 0 | 76 | 2.9394-2.9450 | 2.9800-2.9851 |

The yielding loaded fake-account scenarios each execute eight additional fake-account reads via unchanged `_start_io`/`_read`/thread-worker/startup/reconciliation code, while baseline executes none during the burst. Initial loop startup completes before the burst in both cases; shutdown is measured separately and excluded. At 5 ms callback load the yielding maximum message age is 2.5680-2.5716 seconds (no account) / 2.5709-2.5710 seconds (fake account), compared with baseline 2.5424-2.5475 / 2.5467-2.5546. At 5.8 ms, the largest yielding age is 2.983735 seconds, still below the unchanged three-second stale cutoff. Those ages include bounded initialization/preloading/startup before the burst and therefore differ slightly from burst drain times.

This establishes **real controller-cycle amplification and scheduling/account-read fairness under these controlled inputs**. It does **not** demonstrate checkpoint amplification, reproduce the earlier surrogate's stale failure, attribute production warnings or choose a fix. The quiet state has no fills, intents or changes requiring an immediate save; bursts shorter than five seconds therefore do not reach its quiet periodic save. Any active-order/history scenario could have different save behavior and remains untested. The earlier synthetic 12 ms Event worker is not evidence that the actual controller runs once per message: the real 20 ms minimum spacing and save gates matter.

## Setup and boundaries

- Native websockets 15 `Connection`/`Protocol` parser and assembler, identical 500 complete frames supplied in one offline `data_received` call; high-water 16; no socket or handshake. Harness uses native private queue introspection solely to assert preload/drain, never production code.
- Real `KalshiMarketWS._session`, market-state transitions and freshness guard; source epoch plus real monotonic elapsed clock. All messages have the same source timestamp. This is an invented burst, not observed ingress traffic.
- Actual `KalshiLiveDesk` from test `make_desk` with Settings paper, no keys, no confirmation. Fake-account branch directly installs existing `FakeAccount`; order/create/cancel and client factory are fail-closed assertions. Paper admission and clock-probe gates remain intact. Fake account starts empty.
- `MemoryLedger` is a no-added-latency deep-copy fake substituted only at desk construction; actual checkpoint state-building/heartbeat/model/panel code runs if called. It does not model fsync, receipt-chain verification, disk cost, live history, or crash recovery. Constructor display state and lock files are confined to `/workspace/shared/controller-replay-data-*`.
- Thin step/checkpoint wrappers record observations; no work is injected per cycle. The only added CPU is the explicitly named 0/5/5.8 ms per-complete-message callback workload. No live fills, cancellations, guard overrides, policy changes, fallback/reconnect path or complete practice controller are modeled.
- Cycle wall times include awaits overlapping feed work. **Do not sum them as synchronous controller occupancy or extra CPU**, or subtract paired run wall times as a precise causal CPU estimate. Thread timing and scheduler phase vary.
- Before/after relevant source hashes match. Two reversed-order repeats are checks of this bounded setup, not statistical production benchmarks. These results do not clear EXEC-DELAY-001 or the frozen production verification gate.

Executed command (read-only checkout, only prefixed shared paths written):

```
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src:tests /workspace/shared/nightcrawler-venv/bin/python /workspace/shared/controller-replay.py > /workspace/shared/controller-replay-attempt3.log 2>&1
```

Successful run: 44.740571 seconds wall, exit 0. Executed script SHA256 `ba4350f10380620df48992a6d5b75e058c0fbf4073f8d7ddb4d1fbd4d813c184`; result JSON SHA256 `b2825230060d0d811e5a82f2b0cce747dcf6a0d38cdd9e384f05872052abe86f`. Exact Python/platform/dependency version and source hashes are in `/workspace/shared/controller-replay.json`. `/workspace/shared/controller-replay.log` and `controller-replay-attempt2.log` retain two failed pre-execution attempts caused by incorrect evidence hash filenames; neither ran a scenario or is counted as a pass. Successful stdout is retained in `controller-replay-attempt3.log`.
