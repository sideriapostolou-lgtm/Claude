"""Bounded offline quiet callback density profile; no production state or client."""
from __future__ import annotations

import cProfile
import dataclasses
import hashlib
import json
import logging
import pstats
import socket
import statistics
import subprocess
import tempfile
import threading
import time
from pathlib import Path

ROOT = Path('/workspace/nightcrawler-next-evidence')
OUT = Path('/workspace/shared/practice-report-density-profile.json')

def denied(*args, **kwargs):
    raise RuntimeError('offline diagnostic denies socket/client/thread use')

# Before imports/fixture: prohibit all socket allocation, network and worker threads.
class DeniedSocket(socket.socket):
    def __init__(self, *args, **kwargs):
        denied(*args, **kwargs)

socket.socket = DeniedSocket
socket.create_connection = denied
threading.Thread.start = denied

from test_kalshi_arena_feed import LocalFeeds

from nightcrawler.clock import FakeClock
from nightcrawler.config import Settings
from nightcrawler.speeddesk import SpeedRunner
from nightcrawler.speeddesk_live import Intent, KalshiLiveDesk
from nightcrawler.speeddesk_live_model import ActualFill, LiveIntent
from nightcrawler.speeddesk_model import BitcoinTape, PracticeOrder, Window, utc_day
from datetime import UTC, datetime
from nightcrawler.speeddesk_metrics import LatencyMetrics

logging.disable(logging.CRITICAL)
SLUG = 'KXBTC15M-QUIET-CURRENT'
T0 = 1792016160.0

class Feeds(LocalFeeds):
    def maker_windows(self):
        return {SLUG}


def native(value):
    if dataclasses.is_dataclass(value):
        return native(dataclasses.asdict(value))
    if isinstance(value, dict):
        return {str(key): native(val) for key, val in value.items()}
    if isinstance(value, (list, tuple)):
        return [native(val) for val in value]
    return value


def digest(value):
    return hashlib.sha256(json.dumps(native(value), sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def main():
    results=[]
    with tempfile.TemporaryDirectory(prefix='panel-profile-',dir='/workspace/shared') as directory:
        clock=FakeClock(T0)
        def live_factory(settings,path,snapshot,**kwargs):
            return KalshiLiveDesk(settings,path,snapshot,client_factory=denied,**kwargs)
        runner=SpeedRunner(Settings(data_dir=Path(directory),speeddesk_kalshi_enabled=True,
            speeddesk_kalshi_mode='paper',speeddesk_kalshi_live_confirm=None,
            kalshi_key_id=None,kalshi_private_key=None,kalshi_arena_enabled=False),
            threading.Event(),clock=clock,feed_factory=Feeds,live_factory=live_factory)
        try:
            live=runner.live
            assert live is not None and live.client is None
            fills=[]
            for i in range(200):
                begin=T0-(201-i)*900
                w=Window(f'KXBTC15M-PANEL-{i:04}',begin,begin+900,80000,
                    venue='kalshi',venue_start_price=80000,taker_coefficient=.07,
                    maker_coefficient=0,fee_rounding='kalshi')
                for model in (runner.desk,live.twin,live.book):
                    model.add_window(dataclasses.replace(w))
                for j,side in enumerate(('up','down')):
                    k=i*2+j; key=f'nc-speed-panel-{k}'; at=begin+30+j
                    price=.4 if side=='up' else .5
                    live.book.intents[key]=LiveIntent(key,w.slug,side,'rest',price,1,at-1,price,
                        order_id=f'o{k}')
                    live.intents[key]=Intent(key,w.slug,side,'rest',price,1,.5,at-1,
                        order_id=f'o{k}',terminal=True)
                    fill=ActualFill(f'f{k}',f'o{k}',key,w.slug,side,price,1,0,at,is_taker=False)
                    assert live.book.record_fill(fill)
                    fills.append(dataclasses.asdict(fill))
                    for model in (runner.desk,live.twin):
                        order=PracticeOrder(k+1,w.slug,side,'rest',price,1,1,at-1,at-1,.5,0,0,'fixture',
                            fee_rounding='kalshi',min_trade_qty=.01)
                        model.orders[k+1]=order
                        model._fill(order,1,at)
                        model.next_order_id=k+2
                runner.desk.settle(w.slug,True,w.end+1)
                live.twin.settle(w.slug,True,w.end+1)
                live.book.settle(w.slug,True,w.end+1,f's{i}')
                live.position_sizes[w.slug]=0
            for k in range(400,3350):
                spec=runner.desk.windows[f'KXBTC15M-PANEL-{k%200:04}']
                key=f'nc-speed-panel-{k}'; at=spec.start+10
                live.book.intents[key]=LiveIntent(key,spec.slug,'up','rest',.4,1,at,.4,
                    order_id=f'o{k}',status='canceled',reservation_active=False)
                live.intents[key]=Intent(key,spec.slug,'up','rest',.4,1,.5,at,
                    order_id=f'o{k}',terminal=True)
            runner.on_windows([Window(SLUG,T0-60,T0+840,80000,venue='kalshi',
                venue_start_price=80000,taker_coefficient=.07,maker_coefficient=0,fee_rounding='kalshi')])
            runner.on_tick(80000,T0,T0)
            runner.on_status({'coinbase':'connected','trade_stream':True,'markets':'connected'})
            runner.checkpoint(T0)
            # This is invented offline density, never captured production state.
            assert not OUT.exists(), 'preserve previously closed artifact'
            runner.desk.tape=BitcoinTape()
            for second in range(int(T0)-3700,int(T0)+1):
                runner.desk.tape.tick(80000+(second%17)*.01,float(second))
            stages={}
            days=[utc_day(T0-offset*86400) for offset in range(4)]
            def measure(label):
                methods=(('practice_panel',lambda:runner.panel(T0)),
                         ('practice_summary',lambda:runner.summary(utc_day(T0))),
                         ('practice_daily_reports',lambda:runner.daily_reports(T0)))
                # Warm function paths and initialize prior-day report records outside measurement.
                for _,fn in methods:
                    fn()
                rows=[]
                profiles={}
                for rep in range(4):
                    for name,fn in methods[::1 if rep%2==0 else -1]:
                        wall,cpu=time.perf_counter_ns(),time.thread_time_ns()
                        value=fn()
                        rows.append({'rep':rep,'name':name,'wall_ms':(time.perf_counter_ns()-wall)/1e6,
                            'cpu_ms':(time.thread_time_ns()-cpu)/1e6,'output_sha256':digest(value)})
                for name,fn in methods:
                    prof=cProfile.Profile();prof.enable();fn();prof.disable()
                    profiles[name]=[{'file':key[0],'line':key[1],'function':key[2],'calls':v[1],
                        'self_ms':v[2]*1000,'cumulative_ms':v[3]*1000}
                        for key,v in pstats.Stats(prof).stats.items()]
                fixture={'now':T0,'started_at':runner.started_at,
                    'practice':runner.desk.to_state(),'practice_evidence':runner.evidence.state(),
                    'metrics':runner.metrics.state(),'book':live.book.to_state(),
                    'controller_intents':native(live.intents),'live_evidence':live.evidence.state(),
                    'twin':live.twin.to_state(),'tape':{'started_at':runner.desk.tape.started_at,
                    'prices':runner.desk.tape.prices,'last_at':runner.desk.tape.last_at}}
                stages[label]={'fixture':fixture,'fixture_sha256':digest(fixture),
                    'counts':{'windows':len(runner.desk.windows),'settlements':len(runner.desk.closed),
                    'evidence_fills':len(runner.evidence.fills),'report_days':len(runner.reports),
                    'latency_buckets':sum(len(metrics) for scopes in runner.metrics.days.values() for metrics in scopes.values()),
                    'latency_values':sum(len(bucket['values']) for scopes in runner.metrics.days.values()
                        for metrics in scopes.values() for bucket in metrics.values())},
                    'runs':rows,'profiles':profiles,'medians':{name:{field:statistics.median(
                        row[field] for row in rows if row['name']==name) for field in ('wall_ms','cpu_ms')}
                        for name,_ in methods}}
            measure('warm_tape_empty_practice_evidence_latency')
            # _fill used above does not pass through Runner.decisions: explicitly capture its
            # equivalent fabricated fill fields through the actual evidence API.
            runner.started_at=T0-3*86400
            runner.evidence.started_at=min(window.start for window in runner.desk.windows.values())-1
            for row in fills:
                runner.evidence.fill(row)
            for window in runner.desk.windows.values():
                runner.evidence.first_seen[window.slug]=window.start
                runner.evidence.seconds[window.slug]=max(0,min(T0,window.end)-window.start)
                runner.evidence.fresh_seconds[window.slug]=runner.evidence.seconds[window.slug]
            # Deterministic unsorted latency values; exact actual observer, below/at retention cap.
            for count in (128,4096):
                runner.metrics=LatencyMetrics(T0-4*86400)
                for day in days:
                    at=datetime.strptime(day,'%Y-%m-%d').replace(tzinfo=UTC).timestamp()+3600
                    for venue in ('kalshi','polymarket_us'):
                        for metric in ('btc_exchange_to_decision','btc_receipt_to_decision'):
                            for index in range(count):
                                runner.metrics.observe(venue,metric,at,float((index*37)%997)/10)
                measure(f'practice_fills_prior_days_latency_{count}')
            output={'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
                'stages':stages,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                'limitations':['Synthetic density, not production replay or a performance guarantee.',
                    'One sequentially enriched fixture; four repetitions per method; no confidence interval or causal stage comparison.',
                    '200 fabricated historical Kalshi windows, 400 paired zero-fee fills, 3350 live terminal intents; invented outcomes are not research results.',
                    'Practice evidence captured explicitly after private _fill bypass; coverage maps fabricated fully observed, not obtained from feeds.',
                    'Actual paper Runner/live desk, denied client/socket/thread creation; temporary SQLite writes only.',
                    'Warm 3701-tick tape, no actual active market books or pending live orders; stage profiles separate from unprofiled timings.',
                    'Prior-day reports initialized before timing; timed daily_reports measures revisions/recomputation, not first-record writes.',
                    'Nested profile cumulative times overlap; practice_panel includes live_panel; do not add them.']}
            output['source_sha256']={str(path.relative_to(ROOT)):hashlib.sha256(path.read_bytes()).hexdigest()
                for path in sorted((ROOT/'src/nightcrawler').glob('speeddesk*.py'))}
            OUT.write_text(json.dumps(output,indent=2,allow_nan=False)+'\n')
            for label,stage in stages.items():
                print(label,stage['counts'],stage['medians'])
                for name,rows in stage['profiles'].items():
                    print(name,sorted(rows,key=lambda row:row['cumulative_ms'],reverse=True)[:12])
            print('artifact_sha256',hashlib.sha256(OUT.read_bytes()).hexdigest())
        finally:
            runner.close()

if __name__=='__main__':
    main()
