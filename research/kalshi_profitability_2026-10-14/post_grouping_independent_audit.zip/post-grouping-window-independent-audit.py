import collections,hashlib,json,math,re
from datetime import datetime
from decimal import Decimal
from pathlib import Path
p=Path('/workspace/shared/post-grouping-window-evidence.json');r=json.loads(p.read_text());expected='b58a299363dba8f2f3ce542485b06be59ca84f44d80f905eea4534e3ce4b994a';assert hashlib.sha256(p.read_bytes()).hexdigest()==expected
pattern=re.compile(r'^(\S+) (?:INFO|WARNING|ERROR|DEBUG|CRITICAL) [A-Za-z0-9_.]+: (speeddesk_[a-z0-9_]+) (\{.*\})$',re.S)
for e in r['events']:
 m=pattern.fullmatch(e['original_message']);assert m and m[2]==e['event'];assert json.loads(m[3])==e['payload'];assert m[1]==e['source_wall_utc']
keys=[(e['timestamp_utc'],e['original_message']) for e in r['events']];assert len(set(keys))==len(keys)
assert [e['timestamp_utc'] for e in r['events']]==sorted(e['timestamp_utc'] for e in r['events'])
start=datetime.fromisoformat(r['target_window']['start_utc']).timestamp();end=datetime.fromisoformat(r['target_window']['end_utc']).timestamp();ticker=r['target_window']['ticker']
financial=[e for e in r['events'] if e['payload'].get('window')==ticker]
orders=[e['payload'] for e in financial if e['event']=='speeddesk_live_order'];intents={v['client_order_id']:v for v in orders if v['state']=='durable intent'};acks={v['order_id']:v for v in orders if v['state']=='accepted; waiting for real fills'}
assert len(intents)==len(acks)==7 and {v['client_order_id'] for v in acks.values()}==set(intents)
for ack in acks.values():assert start<=intents[ack['client_order_id']]['at']<=ack['at']<end
fills={e['payload']['fill_id']:e['payload'] for e in financial if e['event']=='speeddesk_live_fill'}
assert len(fills)==2
for fill in fills.values():assert fill['order_id'] in acks and acks[fill['order_id']]['client_order_id']==fill['client_order_id'] and start<=fill['at']<end
cancels=[e['payload'] for e in financial if e['event']=='speeddesk_live_cancel'];assert len(cancels)==7 and {v['order_id'] for v in cancels}==set(acks)
for row in cancels:assert row['client_order_id']==acks[row['order_id']]['client_order_id'] and acks[row['order_id']]['at']<=row['at']<end
settles=[e['payload'] for e in financial if e['event']=='speeddesk_live_settlement'];assert len(settles)==1;s=settles[0];assert end<=s['at']<=s['observed_at']<end+60
cost=sum(Decimal(str(v['price']))*Decimal(str(v['size'])) for v in fills.values());fees=sum(Decimal(str(v['fee_usd'])) for v in fills.values());quantities={side:sum(v['size'] for v in fills.values() if v['side']==side) for side in ('up','down')}
assert quantities=={'up':1,'down':1} and cost==Decimal('.98') and fees==0
assert s['up_shares']==s['down_shares']==s['payout_usd']==1 and s['cost_usd']==float(cost) and s['fee_usd']==0 and s['direction_usd']==0
assert math.isclose(s['pnl_usd'],float(Decimal(str(s['payout_usd']))-cost-fees),abs_tol=1e-15) and s['pnl_usd']==s['locked_usd']
traces=[e['payload'] for e in r['events'] if e['event']=='speeddesk_reconcile_trace' and start<=e['payload']['started_at']<end]
assert len(traces)==4 and sum(len(v['reads']) for v in traces)==20 and sum(bool(v['new_fills']) for v in traces)==2
assert {fill['fill_id'] for trace in traces for fill in trace['new_fills']}==set(fills)
works=[v for trace in traces for v in trace['read_resume_work']];assert sum(v['omitted_spans'] for v in works)==84
for trace in traces:
 assert trace['reads_omitted']==trace['new_fills_omitted']==0 and trace['counts']['suppressed']==0
 for read,work in zip(trace['reads'],trace['read_resume_work'],strict=True):
  assert read['read']==work['read'] and not work['retention_loss'] and not work['all_sync_work_lower_bound']['retention_loss']
  gap=read['marks_ms']['coroutine_resumed']-read['marks_ms']['worker_completed'];assert abs(gap-work['interval_wall_ms'])<.0011
  bins=work['all_sync_work_lower_bound'];assert abs(bins['covered_wall_lower_bound_ms']+bins['unattributed_or_boundary_ms']-work['interval_wall_ms'])<1e-8
worst=max(works,key=lambda v:v['interval_wall_ms']);assert math.isclose(worst['interval_wall_ms'],5131.435,abs_tol=1e-5)
statuses=[e for e in r['events'] if e['event']=='speeddesk_live_status' and start<=e['payload']['as_of']<end];assert len(statuses)==15
previous=None;intervals=[];maxima={}
for e in statuses:
 v=e['payload'];contained=previous is not None and start<=previous<=v['as_of']<end
 intervals.append((previous,v['as_of'],contained))
 assert not v['total_halted'] and not v['day_stop_latched'] and v['integrity_error'] is None
 for name,metric in v['loop']['ms'].items():
  assert metric['n']<=8192
  if contained:maxima[name]=max(maxima.get(name,0),metric['max_ms'])
 previous=v['as_of']
assert sum(row[2] for row in intervals)==14
for name,value in maxima.items():assert r['summary']['fully_contained_interval_maxima'][name]['max_ms']==value
assert maxima['fills_worker_resume']==2762.8 and maxima['list_orders_worker_resume']==2188.7 and maxima['event_loop_lag']==2054
assert not r['parse_errors'] and not r['query_errors'] and all(not v['cap_hit'] and v['returned']<v['limit'] for v in r['queries'])
assert r['complete'] and r['scheduled_queries_finished'] and not r['collector_jobs_running']
result={'source_artifact_sha256':expected,'original_event_messages_reparsed':len(r['events']),'unique_timestamp_message_pairs':len(keys),'target':r['target_window'],
 'counts':{'intents':len(intents),'accepted_orders':len(acks),'cancels':len(cancels),'fills':len(fills)},'cancel_states':dict(collections.Counter(v['state'] for v in cancels)),
 'fill_economics':{'cost':str(cost),'fees':str(fees),'payout':'1','net':'0.02','quantities':quantities},
 'venue_settlement_at':s['at'],'observed_settlement_at':s['observed_at'],'traces':len(traces),'reads':20,'work_details_omitted':84,
 'worst_resume_ms':worst['interval_wall_ms'],'worst_bin_coverage':worst['all_sync_work_lower_bound'],'target_statuses':15,'fully_contained_intervals':14,'contained_maxima':maxima,
 'limitations':['Independent replay of saved original log strings, not independent venue or network acquisition.',
 'Cancel rows retain reservations; counts do not prove liabilities removed. Settlement arithmetic is one target window, not strategy edge.',
 'Selected traces are slow/new-fill/failure population; status intervals are separate worker-return/lag populations. No combined percentile or additive overlap coverage.',
 'Query caps not hit; finite capture ending23:31 cannot rule out later logs or late financial observations.',
 'No multi-second causal attribution to buffered input established by this artifact; execution task remains open.'],
 'audit_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
out=Path('/workspace/shared/post-grouping-window-independent-audit.json');assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));print('audit_result_sha256',hashlib.sha256(out.read_bytes()).hexdigest())
