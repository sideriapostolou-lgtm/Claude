from pathlib import Path
from decimal import Decimal as D
from datetime import datetime, timezone
import json
import re

ROOT = Path(__file__).parent
CAPTURE = ROOT.parent / "cancel-postrelease-20261015"
SIG = re.compile(r'^\S+ (?:INFO|WARNING|ERROR|CRITICAL|DEBUG) nightcrawler\.speeddesk: (speeddesk_live_[a-z_]+) (\{.*\})$')
TOL = D("0.0000001")


def records(path):
    wrapper = json.loads(path.read_text())
    for key in ["value", "result", "response"]:
        if key in wrapper:
            wrapper = wrapper[key]
    assert not wrapper.get("isError", False), path.name
    result = wrapper["structuredContent"]
    assert result["deploymentId"] in {
        "cdf0d895-6eed-403b-9594-4679692a4499",
        "fc0a73e9-f052-435a-94b2-ce7b1272f36e",
    }, path.name
    output = []
    for row in result.get("deploy", []):
        match = SIG.match(row["message"])
        if match:
            output.append({
                "event": match[1],
                **json.loads(match[2], parse_float=D),
                "_publication": row["timestamp"],
                "_raw_message": row["message"],
            })
    return output


def public(row):
    return {key: value for key, value in row.items() if key != "_raw_message"}


originals = {}
for path in sorted((CAPTURE / "queries").glob("*.json")):
    for row in records(path):
        originals[(row["_publication"], row["_raw_message"])] = row
raw = list(originals.values())
tickers = ["KXBTC15M-26OCT150830-30", "KXBTC15M-26OCT150845-45"]
windows = []
for ticker in tickers:
    rows = [row for row in raw if row.get("window") == ticker]
    fills = [row for row in rows if row["event"] == "speeddesk_live_fill"]
    settlements = [row for row in rows if row["event"] == "speeddesk_live_settlement"]
    assert len(settlements) == 1, (ticker, "settlement count")
    settlement = settlements[0]
    intents = {row["client_order_id"]: row for row in rows
               if row["event"] == "speeddesk_live_order" and row.get("state") == "durable intent"}
    accepted = {row["client_order_id"]: row for row in rows
                if row["event"] == "speeddesk_live_order" and row.get("state") == "accepted; waiting for real fills"}
    assert len({row["fill_id"] for row in fills}) == len(fills), (ticker, "duplicate fills")
    for fill in fills:
        intent = intents[fill["client_order_id"]]
        ack = accepted[fill["client_order_id"]]
        assert intent["side"] == fill["side"] and ack["order_id"] == fill["order_id"]
        assert intent["window"] == ack["window"] == fill["window"]
    sides = {side: sum((D(row["size"]) for row in fills if row["side"] == side), D(0))
             for side in ["up", "down"]}
    cost = sum((D(row["price"]) * D(row["size"]) for row in fills), D(0))
    fees = sum((D(row["fee_usd"]) for row in fills), D(0))
    payout = sides["up" if settlement["up_wins"] else "down"]
    pnl = payout - cost - fees
    for name, actual in [("cost_usd", cost), ("fee_usd", fees), ("payout_usd", payout), ("pnl_usd", pnl)]:
        assert abs(actual - D(settlement[name])) < TOL, (ticker, name, actual, settlement[name])
    assert D(settlement["net_payout_usd"]) == 0
    windows.append({"ticker": ticker, "fills": len(fills),
                    "distinct_filled_order_ids": len({row["order_id"] for row in fills}),
                    "accepted": len(accepted), "intents": len(intents),
                    "cost": cost, "fees": fees, "payout": payout, "pnl": pnl, **sides})

before = records(ROOT / "before-status-raw.json")[-1]
after = records(ROOT / "final-status.json")[-1]
startup = [row for row in raw if row["event"] == "speeddesk_live_settlement" and row["window"] not in tickers]
assert len(startup) == 1, "startup settlement count"
startup = startup[0]
next_fills = [row for row in raw if row["event"] == "speeddesk_live_fill" and row["window"] not in tickers]
assert len(next_fills) == 1, "next partial fill count"
next_fill = next_fills[0]
next_intent = [row for row in raw if row["event"] == "speeddesk_live_order" and
               row.get("state") == "durable intent" and row.get("client_order_id") == next_fill["client_order_id"]]
next_ack = [row for row in raw if row["event"] == "speeddesk_live_order" and
            row.get("state") == "accepted; waiting for real fills" and row.get("client_order_id") == next_fill["client_order_id"]]
assert len(next_intent) == len(next_ack) == 1, "next partial joins"
assert next_ack[0]["order_id"] == next_fill["order_id"]
next_cost = D(next_fill["price"]) * D(next_fill["size"]) + D(next_fill["fee_usd"])
trial_pnl = sum((row["pnl"] for row in windows), D(0))
expected_cash = D(before["cash_usd"]) + D(startup["net_payout_usd"]) + trial_pnl - next_cost
expected_pnl = D(before["total"]["pnl_usd"]) + D(startup["pnl_usd"]) + trial_pnl
assert abs(expected_cash - D(after["cash_usd"])) < TOL, "cash arithmetic"
assert abs(expected_pnl - D(after["total"]["pnl_usd"])) < TOL, "cumulative P&L arithmetic"
result = {
    "checked_at_utc": datetime.now(timezone.utc).isoformat(),
    "source_commit": "1bd8f2217025b098adfd2a0e8a9ca3bbe45c97da",
    "deployment": "cdf0d895-6eed-403b-9594-4679692a4499",
    "method": "Root independently re-parsed anchored original raw messages with Decimal, exact client/order/ticker/side joins; nested latest_events excluded. Overlap deduplicated by exact publication/message identity.",
    "windows": windows, "trial_pnl": trial_pnl,
    "cash_reconciliation": {
        "before": before["cash_usd"], "before_event_at": before["at"],
        "startup_prior_window_settlement": public(startup),
        "startup_net_payout_added": startup["net_payout_usd"],
        "fixed_trial_pnl_added": trial_pnl,
        "excluded_next_partial_fill": public(next_fill),
        "excluded_next_partial_fill_joins_intent_ack": True,
        "next_partial_cost_subtracted": next_cost,
        "expected_cash_raw_decimal": expected_cash, "actual_cash": after["cash_usd"],
        "after_event_at": after["at"],
        "pnl_before": before["total"]["pnl_usd"],
        "prior_partial_settlement_pnl_added": startup["pnl_usd"],
        "expected_cumulative_pnl": expected_pnl, "actual_cumulative_pnl": after["total"]["pnl_usd"],
        "absolute_tolerance_usd": str(TOL),
    },
    "limitations": [
        "Selected bot status/original fill/settlement arithmetic; not a full native venue cash-transaction ledger, order terminal-state or stop-anchor export.",
        "Gross paired payout already credited must not be counted twice. Startup and next partial remain excluded from fixed performance cohort.",
        "Venue precision agrees; raw startup net payout is 0.42999999999999994, so cash is not bit-exact decimal identity.",
        "Initial unsaved inline root audit failed an assertion without a message and saved no result; it was not accepted as a pass. This named-assertion reparse and Astra's separate original reparse supply the successful checks.",
        "No causal performance improvement, avoided loss or profitable edge is inferred.",
    ],
}
(ROOT / "cash-reconciliation-root-final.json").write_text(json.dumps(result, indent=2, default=str) + "\n")
print(json.dumps({"windows": windows, "trial_pnl": trial_pnl, "cash_expected_raw": expected_cash,
                  "cash_actual": after["cash_usd"], "cumulative_expected": expected_pnl,
                  "cumulative_actual": after["total"]["pnl_usd"]}, indent=2, default=str))
