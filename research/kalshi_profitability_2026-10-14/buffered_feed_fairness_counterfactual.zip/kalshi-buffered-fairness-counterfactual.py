"""Offline exact one-statement scheduling counterfactual; no repository mutation."""
from __future__ import annotations
import ast
import asyncio
import copy
import dataclasses
import hashlib
import inspect
import json
import logging
from pathlib import Path
import socket
import sys
import textwrap
import threading
import websockets
from websockets.protocol import Protocol, Side
from websockets.frames import Frame, OP_TEXT
from websockets.asyncio.connection import Connection
from nightcrawler.config import Settings
from nightcrawler import speeddesk_kalshi_ws as module
from nightcrawler.speeddesk_kalshi_ws import KalshiMarketWS, MarketState

OUT=Path('/workspace/shared/kalshi-buffered-fairness-counterfactual.json')
T=1792019700.0
TICKER='KXBTC15M-FAKE-FAIRNESS'
ORIGINALS={Path('/workspace/shared/kalshi-buffered-fairness-proof.py'):'6e1a0e8f821624466f6d9100f569c72ed266afd8d1f38c0f24b007289f3bc9b7',
           Path('/workspace/shared/kalshi-buffered-fairness-proof.json'):'6e3d5a5b191fa7205ace7eda66685d8a4ff9c01c6734daa85baedd2a2594b06d'}

def digest(value): return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def native(value):
    if dataclasses.is_dataclass(value): return native(dataclasses.asdict(value))
    if isinstance(value,dict): return {str(k):native(v) for k,v in value.items()}
    if isinstance(value,(tuple,list)): return [native(v) for v in value]
    if isinstance(value,(set,frozenset)): return sorted(native(v) for v in value)
    return value

def denied(*args,**kwargs): raise AssertionError('offline: no sockets, threads or real clients')

baseline_source=textwrap.dedent(inspect.getsource(KalshiMarketWS._session))
tree=ast.parse(baseline_source)
candidate_tree=copy.deepcopy(tree)
loop_node=candidate_tree.body[0].body[-1]
assert isinstance(loop_node,ast.While)
assert isinstance(loop_node.body[-1],ast.For) and loop_node.body[-1].target.id=='trade'
loop_node.body.append(ast.parse('await asyncio.sleep(0)').body[0])
ast.fix_missing_locations(candidate_tree)
namespace={}
exec(compile(candidate_tree,'<offline-one-statement-session-candidate>','exec'),vars(module),namespace)
candidate=namespace['_session']
roundtrip=copy.deepcopy(candidate_tree);roundtrip.body[0].body[-1].body.pop()
assert ast.dump(roundtrip,include_attributes=False)==ast.dump(tree,include_attributes=False)
candidate_source=ast.unparse(candidate_tree)+'\n'

class Transport:
    def __init__(self): self.pauses=0;self.resumes=0
    def pause_reading(self): self.pauses+=1
    def resume_reading(self): self.resumes+=1
    def set_write_buffer_limits(self,*args): pass
    def write(self,data): raise AssertionError('unexpected protocol write')
class AdapterSocket:
    def __init__(self,connection): self.connection=connection;self.sent=[];self.received=0
    async def send(self,message): self.sent.append(json.loads(message))
    async def recv(self):
        value=await self.connection.recv();self.received+=1;return value

async def scenario(total,use_candidate):
    loop=asyncio.get_running_loop();transport=Transport()
    connection=Connection(Protocol(Side.CLIENT,max_size=1_000_000),max_queue=16,ping_interval=None)
    connection.connection_made(transport)
    frames=[];payloads=[];book_seq=1;trade_seq=0
    for index in range(total):
        if index%2==0:
            book_seq+=1
            payload={'type':'orderbook_delta','sid':7,'seq':book_seq,
                'msg':{'market_ticker':TICKER,'side':'yes','price_dollars':'.4',
                       'delta_fp':'.01','ts_ms':int(T*1000)}}
        else:
            trade_seq+=1
            payload={'type':'trade','sid':9,'seq':trade_seq,
                'msg':{'market_ticker':TICKER,'trade_id':f'fake-trade-{trade_seq}',
                       'count_fp':'1.25','yes_price_dollars':'.40','no_price_dollars':'.60',
                       'taker_outcome_side':'yes','taker_book_side':'bid','is_block_trade':False,
                       'ts_ms':int(T*1000)}}
        payloads.append(payload)
        frames.append(Frame(OP_TEXT,json.dumps(payload).encode()).serialize(mask=False))
    connection.data_received(b''.join(frames))
    assert len(connection.recv_messages.frames)==total
    ws=AdapterSocket(connection)
    callbacks=[];events=[];statuses=[];stop=threading.Event();ready=loop.create_future()
    async def account():
        await ready
        events.append({'event':'account_resumed','callbacks':len(callbacks),'messages_received':ws.received,
                       'remaining_buffered_frames':len(connection.recv_messages.frames)})
    account_task=asyncio.create_task(account())
    await asyncio.sleep(0)
    def receive(kind,value):
        callbacks.append({'kind':kind,'value':native(value)})
        if len(callbacks)==1:
            events.append({'event':'synthetic_worker_completed','callbacks':1,'messages_received':ws.received})
            ready.set_result(None)
        if len(callbacks)==total*2: stop.set()
    reader=KalshiMarketWS(Settings(kalshi_key_id=None,kalshi_private_key=None,
        speeddesk_kalshi_mode='paper',speeddesk_kalshi_live_confirm=None),
        tickers=lambda:frozenset((TICKER,)),on_book=lambda book:receive('book',book),
        on_trade=lambda trade:receive('trade',trade),on_status=statuses.append,clock=lambda:T,ws_connect=denied)
    reader.connected=True;reader.state=MarketState(frozenset((TICKER,)))
    reader.state.apply({'type':'subscribed','id':1,'msg':{'sid':7,'channel':'orderbook_delta'}},T)
    reader.state.apply({'type':'subscribed','id':2,'msg':{'sid':9,'channel':'trade'}},T)
    reader.state.apply({'type':'orderbook_snapshot','sid':7,'seq':1,
        'msg':{'market_ticker':TICKER,'yes_dollars_fp':[['.4','1']],'no_dollars_fp':[['.6','1']]}},T)
    method=candidate if use_candidate else KalshiMarketWS._session
    await method(reader,ws,frozenset((TICKER,)),stop)
    await account_task
    assert events[-1]['callbacks']==(2 if use_candidate else total*2)
    assert events[-1]['messages_received']==(1 if use_candidate else total)
    assert ws.received==total and len(callbacks)==2*total
    for index,payload in enumerate(payloads):
        pair=callbacks[index*2:index*2+2]
        assert [entry['value']['side'] for entry in pair]==['up','down']
        assert all(entry['kind']==('book' if payload['type']=='orderbook_delta' else 'trade') for entry in pair)
    state=native(vars(reader.state))
    return {'variant':'candidate' if use_candidate else 'baseline','total_messages':total,
        'single_receive_chunk_bytes':sum(map(len,frames)),'high_water':connection.recv_messages.high,
        'low_water':connection.recv_messages.low,'transport_pauses':transport.pauses,'transport_resumes':transport.resumes,
        'events':events,'callbacks':callbacks,'statuses':statuses,'final_state':state,'subscriptions':ws.sent,
        'callbacks_sha256':digest(callbacks),'final_state_sha256':digest(state),'payloads_sha256':digest(payloads)}

async def main():
    socket.socket=denied;socket.create_connection=denied;threading.Thread.start=denied
    for path,expected in ORIGINALS.items(): assert hashlib.sha256(path.read_bytes()).hexdigest()==expected
    cases=[]
    for total in (16,64):
        old=await scenario(total,False);new=await scenario(total,True)
        for key in ('callbacks','statuses','final_state','subscriptions','payloads_sha256',
                    'transport_pauses','transport_resumes','single_receive_chunk_bytes'):
            assert old[key]==new[key],key
        cases.extend((old,new))
    for path,expected in ORIGINALS.items(): assert hashlib.sha256(path.read_bytes()).hexdigest()==expected
    output={'python':sys.version,'websockets':websockets.__version__,'cases':cases,
        'baseline_session_source':baseline_source,'candidate_session_source':candidate_source,
        'baseline_method_sha256':hashlib.sha256(baseline_source.encode()).hexdigest(),
        'candidate_method_sha256':hashlib.sha256(candidate_source.encode()).hexdigest(),
        'ast_difference':'Exactly one appended await asyncio.sleep(0) after complete books/trades dispatch.',
        'source_file_sha256':hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest(),
        'original_artifacts_verified_unchanged':{str(path):sha for path,sha in ORIGINALS.items()},
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'limitations':['Counterfactual only; source files and classes are not monkeypatched.',
            'Synthetic future readiness; no actual account HTTP task, network, credentials, threads or orders.',
            'Fixed timestamps and alternating single-message book/trade frames; arbitrary real task mutations not modeled.',
            'Scheduling counts, not throughput/latency or production attribution; no wall timing assertions.',
            'Cancellation, timeout, stale-frame and callback-failure paths require independent release tests.']}
    assert not OUT.exists();OUT.write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({'cases':[{key:case[key] for key in ('variant','total_messages','single_receive_chunk_bytes',
         'events','transport_pauses','transport_resumes','callbacks_sha256','final_state_sha256')} for case in cases],
         'script_sha256':output['script_sha256'],'result_sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),
         'baseline_method_sha256':output['baseline_method_sha256'],'candidate_method_sha256':output['candidate_method_sha256'],
         'source_file_sha256':output['source_file_sha256']},indent=2))

if __name__=='__main__':
    logging.disable(logging.CRITICAL);loop=asyncio.new_event_loop()
    try: loop.run_until_complete(main())
    finally: loop.close()
