"""Read-only restart audit using original saved responses and pinned source."""
import hashlib,json,re,subprocess
from decimal import Decimal
from pathlib import Path

ROOT=Path('/workspace/shared')
OLD='86dabbf2-bedb-4686-b6ed-857955e0b521';NEW='fc0a73e9-f052-435a-94b2-ce7b1272f36e'
COMMIT='1e8d0be07b280292fa873a2f5da9b22dd02f28c3'
names=['live-mirror-release-query-1.json','live-mirror-old-status-before-build.json','live-mirror-startup-speeddesk.json']
sha=lambda b:hashlib.sha256(b).hexdigest()
sources=[];events=[];seen=set();duplicates=0
for name in names:
 raw=(ROOT/name).read_bytes();a=json.loads(raw);rows=a['response']['structuredContent']['deploy']
 sources.append({'path':str(ROOT/name),'bytes':len(raw),'sha256':sha(raw),'query':a['query'],'rows':len(rows),'isError':a['response']['isError']})
 assert not a['response']['isError'] and len(rows)<a['query']['limit']
 for r in rows:
  match=re.search(r': (speeddesk_[A-Za-z_]+) (\{.*\})$',r['message'])
  if not match:continue
  key=(r['timestamp'],r['message'],a['query']['deploymentId'])
  if key in seen:duplicates+=1;continue
  seen.add(key)
  events.append({'id':sha((r['timestamp']+'\0'+r['message']).encode()),'timestamp':r['timestamp'],
   'deployment':a['query']['deploymentId'],'event':match.group(1),'payload':json.loads(match.group(2))})
events.sort(key=lambda e:e['timestamp'])
statuses=[e for e in events if e['event']=='speeddesk_live_status']
old=max((e for e in statuses if e['deployment']==OLD),key=lambda e:e['timestamp'])
new=min((e for e in statuses if e['deployment']==NEW),key=lambda e:e['timestamp'])
assert old['timestamp']=='2026-10-15T04:47:48.941173167Z'
assert new['timestamp']=='2026-10-15T04:49:34.104644899Z'
o,n=old['payload'],new['payload']
keys=['mode','configured_mode','status','reason','trading_now','waiting','authenticated','fee_precision_verified','fee_precision_usd','cash_usd','cash_at','reserved_usd','open_risk_usd','open_cost_usd','at_risk_usd','open_orders','positions','total_halted','day_stop_latched','real_orders_available','integrity_error','integrity_reset','cleanup_pending','caps']
paths=keys+['total.'+k for k in sorted(set(o['total'])|set(n['total']))]+['ladder.'+k for k in ['enabled','rung','ladder_rung','change_pending','recheck_pending','effective_from','pending_limits','limits']]
def get(data,path):
 for key in path.split('.'):
  if not isinstance(data,dict) or key not in data:return False,None
  data=data[key]
 return True,data
comparison=[]
for path in paths:
 a,x=get(o,path);b,y=get(n,path)
 comparison.append({'path':path,'old_present':a,'new_present':b,'old':x,'new':y,'exact_equal':a and b and x==y})
top_schema={'old_only':sorted(set(o)-set(n)),'new_only':sorted(set(n)-set(o)),
 'equal_keys':sorted(k for k in o.keys()&n.keys() if o[k]==n[k]),
 'changed_keys':sorted(k for k in o.keys()&n.keys() if o[k]!=n[k])}
fill=next(e for e in events if e['event']=='speeddesk_live_fill' and e['payload']['fill_id']=='0725ca73-b079-8f13-3a0a-cbc76e96a7b0')
f=fill['payload'];client=f['client_order_id'];order=f['order_id']
joined=[e for e in events if e['event'] in ['speeddesk_live_order','speeddesk_live_cancel'] and e['payload'].get('client_order_id')==client]
intent=next(e for e in joined if e['payload'].get('state')=='durable intent')
accepted=next(e for e in joined if e['payload'].get('state','').startswith('accepted;'))
assert accepted['payload']['order_id']==order and intent['payload']['window']==f['window']
assert all(intent['payload'][k]==f[k] for k in ['side','size','price'])
prior_path=ROOT/'ws-timing-two-window-audit-input.json';prior_bytes=prior_path.read_bytes();prior=json.loads(prior_bytes)
prior_fills=[]
for q in prior['queries']:
 for e in q['response']['structuredContent']['deploy']:
  if 'speeddesk_live_fill ' in e['message']:
   p=json.loads(e['message'].split('speeddesk_live_fill ',1)[1])
   if p['window']==f['window']:prior_fills.append({'timestamp':e['timestamp'],'payload':p})
assert len(prior_fills)==1
up=prior_fills[0]['payload'];assert up['side']=='up' and up['size']==5 and f['side']=='down' and f['size']==5
D=lambda x:Decimal(str(x))
buy=D(f['size'])*D(f['price'])+D(f['fee_usd']);credit=min(D(f['size']),D(up['size']))
arithmetic={'additional_fill_cost_decimal':str(buy),'pair_credit_consistent_decimal':str(credit),
 'expected_cash_change_decimal':str(credit-buy),'observed_cash_change_decimal':str(D(n['cash_usd'])-D(o['cash_usd'])),
 'combined_gross_cost_decimal':str(buy+D(up['price'])*D(up['size'])+D(up['fee_usd'])),
 'paired_floor_minus_cost_decimal':str(credit-buy-D(up['price'])*D(up['size'])-D(up['fee_usd'])),
 'fill_count_delta':n['total']['fills']-o['total']['fills']}
assert D(arithmetic['expected_cash_change_decimal'])==D(arithmetic['observed_cash_change_decimal'])
assert abs(float(arithmetic['combined_gross_cost_decimal'])-n['open_cost_usd'])<1e-9
assert arithmetic['fill_count_delta']==1
resets=[e for e in events if e['deployment']==NEW and e['event'] in ['speeddesk_live_resume','speeddesk_live_integrity_reset','speeddesk_live_day_reset']]
assert len(resets)==3 and all(e['payload']['state']=='ignored; this value was already used' for e in resets)
reset_receipts=[{'id':e['id'],'timestamp':e['timestamp'],'event':e['event'],'state':e['payload']['state']} for e in resets]
new_intents=[e for e in events if e['deployment']==OLD and e['timestamp']>old['timestamp'] and e['event']=='speeddesk_live_order' and e['payload'].get('state')=='durable intent']
assert n['total']['maker_orders']-o['total']['maker_orders']==len(new_intents)==5
source_paths=['src/nightcrawler/speeddesk_live.py','src/nightcrawler/speeddesk_live_model.py','src/nightcrawler/speeddesk_kalshi_ws.py']
source_hashes={p:sha(subprocess.check_output(['git','show',COMMIT+':'+p],cwd='/workspace/nightcrawler-next-evidence')) for p in source_paths}
result={'task':'PR58 restart continuity independent bounded audit','source_commit':COMMIT,'source_hashes':source_hashes,
 'old_deployment':OLD,'new_deployment':NEW,'sources':sources,'deduplicated_overlapping_rows':duplicates,
 'old_status_receipt':{k:v for k,v in old.items() if k!='payload'},'new_status_receipt':{k:v for k,v in new.items() if k!='payload'},
 'top_level_schema_comparison':top_schema,'selected_exact_field_comparisons':comparison,
 'missing_selected_fields':[r['path'] for r in comparison if not r['old_present'] or not r['new_present']],
 'prior_up_fill':prior_fills[0],'prior_capture_sha256':sha(prior_bytes),
 'shutdown_fill':fill,'shutdown_fill_intent_ack_cancel_joins':joined,'post_old_status_durable_intents':len(new_intents),
 'cash_and_cost_arithmetic':arithmetic,'one_time_controls':reset_receipts,
 'first_new_status_ready':n['trading_now'],
 'limits':['Cash pair-credit explanation is consistent with application logs and pinned source, not a raw venue cash export.',
 'No raw ledger read or independent on-disk hash-chain audit was performed. Restore and persistence conclusions are bounded by observed receipts and code ordering.',
 'First new status is account-data-stale and does not prove trading readiness.',
 'Historical PnL is not the anchored consumed stop budget; reset/resume anchors or token values are not exported.',
 'Session diagnostics reset across restart and cannot be differenced as persistent financial counters.']}
out=ROOT/'live-mirror-restart-audit.json';out.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'output':str(out),'sha256':sha(out.read_bytes()),'missing':result['missing_selected_fields'],
 'arithmetic':arithmetic,'top_level_schema':top_schema,'controls':reset_receipts},indent=2))
