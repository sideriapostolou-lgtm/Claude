from __future__ import annotations
from pathlib import Path
from datetime import datetime,timezone
from decimal import Decimal
from collections import Counter
import json,re
import math
BASE=Path(__file__).parent
SIG=re.compile(r'^\S+ (?:INFO|WARNING|ERROR|CRITICAL|DEBUG) nightcrawler\.speeddesk: (speeddesk_live_[a-z_]+) (\{.*\})$')
def unwrap(p:Path):
 j=json.loads(p.read_text())
 if 'value' in j:j=j['value']
 if 'result' in j:j=j['result']
 assert not j.get('isError',False)
 return j['structuredContent']
def rows(name):
 j=unwrap(BASE/name);assert j['scope']=='deployment' and j['status'] in {'SUCCESS','REMOVED'}
 assert j['deploymentId'] in {'fc0a73e9-f052-435a-94b2-ce7b1272f36e','cdf0d895-6eed-403b-9594-4679692a4499'}
 records=[]
 for x in j.get('deploy',[]):
  m=SIG.match(x['message'])
  if m:records.append({'event':m[1],**json.loads(m[2]),'_publication':x['timestamp']})
 return records
before=rows('before-status-raw.json')[-1]
after=rows('startup-status-fresh.json')[-1]
assert not after['waiting'] and after['trading_now'] and after['authenticated']
paths=['mode','configured_mode','status','authenticated','fee_precision_verified','fee_precision_usd','cash_usd','open_risk_usd','open_cost_usd','positions','total_halted','day_stop_latched','real_orders_available','integrity_error','integrity_reset','cleanup_pending']
paths += ['caps.'+k for k in before['caps']]
paths += ['total.'+k for k in ['windows','fills','settled_windows','fees_usd','locked_usd','directional_usd','pnl_usd','worst_usd','take_attempts','take_fills','maker_fills','locks','lock_fills']]
paths += ['today.'+k for k in ['windows','fills','settled_windows','fees_usd','locked_usd','directional_usd','pnl_usd','worst_usd']]
paths += ['ladder.'+k for k in ['enabled','rung','ladder_rung','max_window_usd','configured_max_window_usd','top_rung','rung_started_at','start_pnl_usd','change_pending','recheck_pending','effective_from','pending_limits']]
def value(j,path):
 for k in path.split('.'):j=j[k]
 return j
comparisons=[]
for p in paths:
 old,new=value(before,p),value(after,p)
 numeric=isinstance(old,(int,float)) and not isinstance(old,bool) and isinstance(new,(int,float)) and not isinstance(new,bool)
 comparisons.append({'field':p,'before':old,'after':new,'exact_equal':old==new,
                     'consistent':math.isclose(old,new,rel_tol=0,abs_tol=1e-10) if numeric else old==new})
print('exact numeric differences',json.dumps([c for c in comparisons if not c['exact_equal']],indent=2))
assert all(c['consistent'] for c in comparisons)
start,end=before['at'],after['at']
events=[];query_coverage=[]
for scope in ['old','new']:
 for kind in ['orders','fills-settlements','cancels','rejects']:
  name=f'restart-{scope}-{kind}.json';s=unwrap(BASE/name)
  assert len(s.get('deploy',[]))<500
  query_coverage.append({'file':name,'rows':len(s.get('deploy',[])),'deployment':s['deploymentId']})
  events.extend({**e,'_scope':scope} for e in rows(name) if start<=e['at']<=end)
assert not [e for e in events if e['event'] in {'speeddesk_live_fill','speeddesk_live_settlement'}]
orders=[e for e in events if e['event']=='speeddesk_live_order']
intents=[e for e in orders if e.get('state')=='durable intent']
accepted=[e for e in orders if e.get('state')=='accepted; waiting for real fills']
intent_ids={e['client_order_id'] for e in intents};ack_ids={e['client_order_id'] for e in accepted}
assert len(intent_ids)==len(intents) and intent_ids==ack_ids
maker_delta=after['total']['maker_orders']-before['total']['maker_orders'];assert maker_delta==len([e for e in intents if e['kind']=='rest'])
cancels=[e for e in events if e['event']=='speeddesk_live_cancel']
prior=[e for e in before['latest_events'] if e.get('event')=='speeddesk_live_order' and e.get('state')=='accepted; waiting for real fills'][-1]
prior_cancels=[e for e in cancels if e.get('client_order_id')==prior['client_order_id']]
assert prior_cancels and Decimal(str(before['reserved_usd']))==Decimal('.2') and after['reserved_usd']==0 and after['open_orders']==0
controls=rows('startup-used-controls.json');assert len(controls)==3 and all(e['state']=='ignored; this value was already used' for e in controls)
result={
 'source_commit':'1bd8f2217025b098adfd2a0e8a9ca3bbe45c97da','deployment':'cdf0d895-6eed-403b-9594-4679692a4499',
 'before_at_utc':datetime.fromtimestamp(start,timezone.utc).isoformat(),'after_at_utc':datetime.fromtimestamp(end,timezone.utc).isoformat(),
 'compared_fields':comparisons,'all_compared_fields_consistent':True,'numeric_absolute_tolerance':1e-10,
 'expected_changed':{k:{'before':before[k],'after':after[k]} for k in ['reserved_usd','open_orders','at_risk_usd']},
 'maker_order_delta':maker_delta,'original_durable_intents':len(intents),'original_accepted_orders':len(accepted),
 'original_fills_between_snapshots':0,'original_settlements_between_snapshots':0,
 'prior_active_order':prior,'prior_order_cancellations':prior_cancels,
 'cancel_receipts_in_interval':len(cancels),'cancel_receipt_states':dict(Counter(e['state'] for e in cancels)),
 'used_controls':controls,'query_coverage':query_coverage,
 'limitations':['Selected top-level financial fields and original bounded logs, not a raw ledger/cash/stop-anchor export or complete venue/order terminal-history audit.','One ladder P&L start-anchor display differs by about1.8e-15 after restore; exact values retained. Initial strict numeric equality assertion failed on this and was replaced by explicit absolute1e-10 tolerance, not rounded or deleted data.','Cancel requests retain reservations; later reconciled status shows no resting orders/reservations, rather than treating every request as terminal confirmation.','Cold first status remains preserved but is excluded as proof of readiness. Startup partial is excluded from the prospective two-window trial.','The retained loss-budget anchor is not exported here; no proof of every persistent field is claimed.','No profitability, causal speedup or quantified avoided dollars is established.']}
(BASE/'restart-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['before_at_utc','after_at_utc','all_compared_fields_consistent','expected_changed','maker_order_delta','original_durable_intents','original_accepted_orders','original_fills_between_snapshots','original_settlements_between_snapshots','cancel_receipts_in_interval','cancel_receipt_states']},indent=2))
print('equal field count',len(comparisons))
