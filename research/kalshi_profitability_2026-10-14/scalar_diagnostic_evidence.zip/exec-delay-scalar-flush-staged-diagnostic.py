"""Exact arena flush fixture, parent scalar baseline/candidate, sequential ABBA.

Authorized offline experiment only. Arena children are local synthetic practice
workers under /workspace/shared; no service or account is contacted. All runs,
including failed timing gates, are kept. --run-confirmed is required.
"""
from __future__ import annotations

import argparse
import ast
import dataclasses
import gc
import hashlib
import importlib.util
import json
import logging
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

ROOT = Path('/workspace/nightcrawler-next-evidence')
OUT = Path('/workspace/shared')
BASE = '0d93fe3c764d2ac743661e681ca1911ec1bf81a9'
spec = importlib.util.spec_from_file_location('arena_callback_diagnostic', OUT / 'exec-delay-scalar-arena-diagnostic.py')
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)


def deny(*_args: Any, **_kwargs: Any) -> Any:
    raise AssertionError('local-only flush fixture attempted network connect')


def worker(variant: str, ordinal: int, output: Path) -> None:
    import test_kalshi_arena_feed as fixture
    import nightcrawler.ledger as ledger_module
    import nightcrawler.models as models
    from nightcrawler import kalshi_arena

    socket.create_connection = deny
    socket.socket.connect = deny
    socket.socket.connect_ex = deny
    logging.disable(logging.CRITICAL)
    immutable_source = helpers.source_at(BASE, 'src/nightcrawler/models.py')
    current_source = (ROOT / 'src/nightcrawler/models.py').read_text()
    conversion_source = immutable_source if variant == 'baseline' else current_source
    namespace = dict(models.__dict__)
    exec(compile(helpers.definition(conversion_source, 'to_jsonable'), f'<flush-{variant}-converter>', 'exec'), namespace)
    converter = namespace['to_jsonable']
    conversion_calls = 0

    def counted(value: Any) -> Any:
        nonlocal conversion_calls
        conversion_calls += 1
        return converter(value)

    models.to_jsonable = ledger_module.to_jsonable = counted
    arena_source = Path(kalshi_arena.__file__).read_text()
    assert arena_source == helpers.source_at(BASE, 'src/nightcrawler/kalshi_arena.py'), 'ArenaLink source changed: stop comparison'
    # Per-sample records are preallocated; no output-row dicts are built inside timed intervals.
    sample_times = [[0, 0, 0, 0, 0] for _ in range(200)]
    gc_events: list[Any] = [None] * 10000
    event_count = 0
    drops = 0
    phase_label = 'start'
    thresholds_before, enabled_before = gc.get_threshold(), gc.isenabled()
    counts_before, stats_before = gc.get_count(), gc.get_stats()

    def observe_gc(phase: str, info: dict[str, Any]) -> None:
        nonlocal event_count, drops
        wall, cpu = time.perf_counter_ns(), time.thread_time_ns()
        if event_count == len(gc_events):
            drops += 1
            return
        gc_events[event_count] = (phase, info['generation'], wall, cpu,
                                  info.get('collected'), info.get('uncollectable'), phase_label)
        event_count += 1

    gc.callbacks.append(observe_gc)
    input_digest = hashlib.sha256()
    stage_rows = [[None, 0, None, 0, 0, 0, 0, 0, 0, 0, 0] for _ in range(4096)]
    stage_count = 0
    stage_drops = 0
    stage_stack: list[int] = []
    sample_metadata = [[0, 0, 0, 0, 0, 0] for _ in range(200)]
    current_step = -1

    def wrap_stage(name: str, function: Any) -> Any:
        def measured(*args: Any, **kwargs: Any) -> Any:
            nonlocal stage_count, stage_drops
            if phase_label != 'flush':
                return function(*args, **kwargs)
            if stage_count == len(stage_rows):
                stage_drops += 1
                return function(*args, **kwargs)
            index = stage_count
            stage_count += 1
            row = stage_rows[index]
            row[0], row[1], row[2], row[3] = name, index + 1, stage_stack[-1] if stage_stack else None, current_step
            row[8] = len(args[0]) if name == '_send' and args else 0
            row[9] = len(link.pending)
            stage_stack.append(index + 1)
            row[4], row[6] = time.perf_counter_ns(), time.thread_time_ns()
            try:
                value = function(*args, **kwargs)
                if name == 'frame':
                    row[8] = len(value)
                return value
            finally:
                row[7], row[5] = time.thread_time_ns(), time.perf_counter_ns()
                row[10] = len(link.pending)
                stage_stack.pop()
        return measured

    old_frame = kalshi_arena.frame
    with tempfile.TemporaryDirectory(prefix=f'exec-delay-scalar-flush-{ordinal}-{variant}-', dir=OUT) as directory:
        path = Path(directory)
        link = fixture.ArenaLink(fixture.ArenaConfig(data_dir=path))
        try:
            link.start()
            assert link.running and fixture.wait_for(lambda: (path / 'kalshi_arena' / 'panel.json').exists())
            now = time.time()
            window = fixture.Window('KXBTC15M-busy', now - 30, now + 870, None,
                                    taker_coefficient=.07, maker_coefficient=0.0,
                                    venue_start_price=80_000, venue='kalshi', fee_rounding='kalshi')
            ladders = fixture.Ladders(window.slug, depth=25)
            link.proc.poll = wrap_stage('poll', link.proc.poll)
            link._status = wrap_stage('_status', link._status)
            link._encode = wrap_stage('_encode', link._encode)
            link._send = wrap_stage('_send', link._send)
            kalshi_arena.frame = wrap_stage('frame', kalshi_arena.frame)
            for step in range(200):
                current_step = step
                phase_label = 'feed'
                now = time.time()
                input_rows = []
                for _ in range(10):
                    for item in ladders.delta(now):
                        link.feed_book(item)
                        input_rows.append({'window': item.window, 'side': item.side,
                                           'sequence': item.sequence,
                                           'bids': [(level.price, level.size) for level in item.bids],
                                           'asks': [(level.price, level.size) for level in item.asks]})
                trade = fixture.Trade(window.slug, 'up', .45, 2.0, now, f't{step}', 'sell', now)
                link.feed_trade(trade)
                snap = fixture.LiveSnapshot(windows=(window,), bitcoin_price=80_000.0 + step,
                                            bitcoin_at=now, sigma=.0003,
                                            maker_windows=frozenset({window.slug}))
                # Semantic checksum excludes wall timestamps, which the unchanged fixture intentionally varies.
                input_digest.update(json.dumps({'step': step, 'books': input_rows, 'trade': [.45, 2.0, f't{step}', 'sell'],
                                                'bitcoin_price': snap.bitcoin_price, 'sigma': snap.sigma},
                                               separators=(',', ':'), sort_keys=True).encode())
                phase_label = 'flush'
                before_calls = conversion_calls
                meta = sample_metadata[step]
                meta[0], meta[1], meta[2] = len(link.pending), len(link.out), link.seq
                wall_start, cpu_start = time.perf_counter_ns(), time.thread_time_ns()
                link.flush(snap)
                cpu_end, wall_end = time.thread_time_ns(), time.perf_counter_ns()
                row = sample_times[step]
                row[0], row[1], row[2], row[3], row[4] = wall_start, wall_end, cpu_start, cpu_end, conversion_calls - before_calls
                meta[3], meta[4], meta[5] = len(link.pending), len(link.out), link.seq
                phase_label = 'sleep'
                time.sleep(.05)
            phase_label = 'capture'
            telemetry = link.telemetry()
        finally:
            phase_label = 'close'
            link.close(wait_s=10)
            kalshi_arena.frame = old_frame
            gc.callbacks.remove(observe_gc)
        feed = kalshi_arena.panel_state(path, time.time())['feed']
        raw_panel = (path / 'kalshi_arena' / 'panel.json').read_bytes()
        received_ok = feed['received'] == 200 * 21 and feed['dropped'] == 0 and feed['live_flush_us_p99'] is not None
    raw_gc = gc_events[:event_count]
    active = {}
    gc_spans = []
    for event in raw_gc:
        phase, generation, wall, cpu, collected, uncollectable, label = event
        if phase == 'start':
            active[generation] = event
        elif phase == 'stop' and generation in active:
            started = active.pop(generation)
            gc_spans.append({'generation': generation, 'start_wall_ns': started[2], 'end_wall_ns': wall,
                             'wall_ms': (wall - started[2]) / 1e6, 'cpu_ms': (cpu - started[3]) / 1e6,
                             'collected': collected, 'uncollectable': uncollectable,
                             'start_stage': started[6], 'end_stage': label})
    samples = []
    decoded_stages = [{'name': row[0], 'span_id': row[1], 'parent_id': row[2], 'step': row[3],
                       'start_wall_ns': row[4], 'end_wall_ns': row[5],
                       'start_cpu_ns': row[6], 'end_cpu_ns': row[7],
                       'wall_ms': (row[5] - row[4]) / 1e6, 'cpu_ms': (row[7] - row[6]) / 1e6,
                       'wire_bytes': row[8], 'pending_before': row[9], 'pending_after': row[10]}
                      for row in stage_rows[:stage_count]]

    def union_ns(intervals: list[tuple[int, int]]) -> int:
        total = 0
        right = 0
        for left, end in sorted(intervals):
            total += max(0, end - max(left, right))
            right = max(right, end)
        return total

    for index, (wall_start, wall_end, cpu_start, cpu_end, calls) in enumerate(sample_times):
        wall_ms, cpu_ms = (wall_end - wall_start) / 1e6, (cpu_end - cpu_start) / 1e6
        overlaps = [{**span, 'overlap_wall_ms': (min(wall_end, span['end_wall_ns']) - max(wall_start, span['start_wall_ns'])) / 1e6,
                     'cpu_basis': 'full GC CPU, not apportioned'}
                    for span in gc_spans if span['start_wall_ns'] < wall_end and span['end_wall_ns'] > wall_start]
        sections = [row for row in decoded_stages if row['step'] == index]
        covered_cpu_ms = union_ns([(max(cpu_start, row['start_cpu_ns']), min(cpu_end, row['end_cpu_ns'])) for row in sections]) / 1e6
        covered_wall_ms = union_ns([(max(wall_start, row['start_wall_ns']), min(wall_end, row['end_wall_ns'])) for row in sections]) / 1e6
        meta = sample_metadata[index]
        samples.append({'step': index, 'wall_ms': wall_ms, 'cpu_ms': cpu_ms,
                        'wall_minus_cpu_ms': wall_ms - cpu_ms,
                        'start_wall_ns': wall_start, 'end_wall_ns': wall_end,
                        'start_cpu_ns': cpu_start, 'end_cpu_ns': cpu_end,
                        'conversion_calls_during_flush': calls, 'gc_overlap': overlaps,
                        'stages': sections, 'stage_union_wall_ms': covered_wall_ms,
                        'stage_union_cpu_ms': covered_cpu_ms,
                        'unattributed_wall_ms': max(0, wall_ms - covered_wall_ms),
                        'unattributed_cpu_ms': max(0, cpu_ms - covered_cpu_ms),
                        'stage_basis': 'union of nested intervals, not sums; residual includes wrapper/control overhead',
                        'pending_before': meta[0], 'outgoing_bytes_before': meta[1], 'sequence_before': meta[2],
                        'pending_after': meta[3], 'outgoing_bytes_after': meta[4], 'sequence_after': meta[5]})
    cpu_values = [row['cpu_ms'] for row in samples]
    cpu_median = helpers.statistics.median(cpu_values)
    cpu_high = helpers.quantile(cpu_values, .99)
    result = {'ordinal': ordinal, 'variant': variant, 'model_baseline_sha': BASE,
              'models_source_sha256': hashlib.sha256(conversion_source.encode()).hexdigest(),
              'converter_function_sha256': hashlib.sha256(ast.get_source_segment(conversion_source, helpers.definition(conversion_source, 'to_jsonable').body[0]).encode()).hexdigest(),
              'arena_source_sha256': hashlib.sha256(arena_source.encode()).hexdigest(),
              'arena_source_equals_baseline': True,
              'input_semantics_sha256_excluding_wall_timestamps': input_digest.hexdigest(),
              'raw_child_panel_sha256': hashlib.sha256(raw_panel).hexdigest(),
              'summary': {metric: helpers.distribution([row[metric] for row in samples])
                          for metric in ('wall_ms', 'cpu_ms', 'wall_minus_cpu_ms')},
              'legacy_cpu_gate_met': cpu_median < .25 and cpu_high < .5,
              'telemetry': telemetry, 'feed': feed, 'delivery_gate_met': received_ok,
              'conversion_calls_during_all_flushes': sum(row['conversion_calls_during_flush'] for row in samples),
              'gc': {'thresholds_before': thresholds_before, 'thresholds_after': gc.get_threshold(),
                     'enabled_before': enabled_before, 'enabled_after': gc.isenabled(),
                     'counts_before': counts_before, 'counts_after': gc.get_count(),
                     'stats_before': stats_before, 'stats_after': gc.get_stats(), 'events': raw_gc,
                     'spans': gc_spans, 'unmatched_starts': len(active), 'event_drops': drops},
              'stages': {'recorded': stage_count, 'dropped': stage_drops, 'rows': decoded_stages},
              'top_wall_outliers': sorted(samples, key=lambda row: row['wall_ms'], reverse=True)[:20],
              'top_cpu_outliers': sorted(samples, key=lambda row: row['cpu_ms'], reverse=True)[:20],
              'all_samples': samples,
              'limits': ['Exact 200-step/50ms fixture with added wall/GC observation; no test threshold changes.',
                         'Semantic producer checksum omits intentional real timestamps; raw panel checksum includes them and need not match.',
                         'Parent converter baseline/candidate differs; ArenaLink code is identical and no observer hooks wrap flush.',
                         'Arena child code is common current checkout in all variants; this experiment isolates parent hot-path conversion, not whole-release timing.',
                         'Parent converter calls inside flush are explicitly counted; absence of calls rules out a direct converter effect on this method.',
                         'GC callbacks and input hashing add diagnostic allocations outside flush; GC history differs from full-suite execution.',
                         'Temporary stage wrappers also add call/allocation/timer overhead inside flush; interpret gate results as diagnostic, not unchanged-test passes.',
                         'Wall minus thread CPU and GC overlap are observations, not automatic proof of scheduling or GC causation.']}
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'ordinal': ordinal, 'variant': variant, 'summary': result['summary'],
                      'legacy_cpu_gate_met': result['legacy_cpu_gate_met'], 'delivery_gate_met': received_ok,
                      'converter_calls_in_flush': result['conversion_calls_during_all_flushes'], 'output': str(output)}))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-confirmed', action='store_true')
    parser.add_argument('--worker', choices=('baseline', 'candidate'))
    parser.add_argument('--ordinal', type=int, default=0)
    parser.add_argument('--output', type=Path)
    options = parser.parse_args()
    if not options.run_confirmed:
        print('Prepared only: root must confirm the full suite has ended.')
        return
    if options.worker:
        worker(options.worker, options.ordinal, options.output)
        return
    all_results = []
    for ordinal, variant in enumerate(('baseline', 'candidate', 'candidate', 'baseline')):
        output = OUT / f'exec-delay-scalar-flush-staged-{ordinal}-{variant}.json'
        subprocess.run([sys.executable, __file__, '--run-confirmed', '--worker', variant,
                        '--ordinal', str(ordinal), '--output', str(output)], check=True, cwd=ROOT)
        all_results.append(json.loads(output.read_text()))
    result = {'order': [row['variant'] for row in all_results],
              'input_semantics_equal': len({row['input_semantics_sha256_excluding_wall_timestamps'] for row in all_results}) == 1,
              'arena_source_equal': len({row['arena_source_sha256'] for row in all_results}) == 1,
              'runs': [{key: row[key] for key in ('ordinal', 'variant', 'summary', 'legacy_cpu_gate_met', 'delivery_gate_met',
                                                'conversion_calls_during_all_flushes')} for row in all_results]}
    path = OUT / 'exec-delay-scalar-flush-staged-comparison.json'
    path.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'comparison': str(path), **result}, indent=2))


if __name__ == '__main__':
    main()
