"""Prepared offline arena hot-path diagnostic. Does not run without --run-confirmed.

Root must first confirm that the full suite has finished. No test thresholds,
repository files, model state, account operations, or services are changed.
Each variant runs in a fresh sequential child process. ArenaLink.start is never
called for this callback fixture: only its bounded producer queue is exercised.
"""
from __future__ import annotations

import argparse
import ast
import gc
import hashlib
import importlib
import json
import logging
import os
import platform
import socket
import statistics
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

ROOT = Path('/workspace/nightcrawler-next-evidence')
OUT = Path('/workspace/shared')
PRE_OBSERVER = '961c88780c9edaca1daa49d8eb7c75964ba930ce'
OBSERVER = '0d93fe3c764d2ac743661e681ca1911ec1bf81a9'
MODEL_BASE = OBSERVER
GC_CAPACITY = 10000
SAMPLES = 20 * 500


def source_at(commit: str, path: str) -> str:
    return subprocess.check_output(['git', 'show', f'{commit}:{path}'], cwd=ROOT, text=True)


def definition(source: str, name: str) -> ast.Module:
    node = next(node for node in ast.parse(source).body
                if isinstance(node, (ast.ClassDef, ast.FunctionDef)) and node.name == name)
    return ast.Module(body=[node], type_ignores=[])


def denied(*_args: Any, **_kwargs: Any) -> Any:
    raise AssertionError('offline callback diagnostic attempted network access')


def quantile(values: list[float], q: float) -> float:
    ordered = sorted(values)
    return ordered[min(len(ordered) - 1, int(q * len(ordered)))]


def distribution(values: list[float]) -> dict[str, Any]:
    return {'n': len(values), 'mean_ms': statistics.fmean(values),
            'median_ms': statistics.median(values), 'p99_ms': quantile(values, .99), 'max_ms': max(values)}


def worker(variant: str, history: str, output: Path) -> None:
    # Imports happen inside each independent variant; no full-suite process is reused.
    import nightcrawler.ledger as ledger_module
    import nightcrawler.models as models
    import nightcrawler.speeddesk as speeddesk_module
    import test_kalshi_arena_feed as fixture

    socket.create_connection = denied
    socket.socket.connect = denied
    socket.socket.connect_ex = denied
    logging.disable(logging.CRITICAL)

    model_source = source_at(MODEL_BASE, 'src/nightcrawler/models.py')
    model_namespace = dict(models.__dict__)
    exec(compile(definition(model_source, 'to_jsonable'), '<immutable-model-baseline>', 'exec'), model_namespace)
    # Both the module global and ledger's imported alias use this SAME immutable baseline.
    models.to_jsonable = ledger_module.to_jsonable = model_namespace['to_jsonable']

    work_source = source_at(OBSERVER, 'src/nightcrawler/speeddesk_worktrace.py')
    work_namespace: dict[str, Any] = {'__name__': '_immutable_observer_fixture'}
    exec(compile(work_source, '<immutable-worktrace>', 'exec'), work_namespace)
    selected_commit = PRE_OBSERVER if variant == 'baseline' else OBSERVER
    runner_source = source_at(selected_commit, 'src/nightcrawler/speeddesk.py')
    runner_namespace = dict(speeddesk_module.__dict__)
    for name in ('WorkTrace', 'observed', 'work_span'):
        runner_namespace[name] = work_namespace[name]
    exec(compile(definition(runner_source, 'SpeedRunner'), '<immutable-speedrunner>', 'exec'), runner_namespace)
    fixture.SpeedRunner = runner_namespace['SpeedRunner']

    prior_modules = []
    heap_load = []
    if history == 'prior_modules_gc':
        # This is an explicit stress scenario, NOT a reconstruction of preceding pytest execution.
        for path in sorted((ROOT / 'tests').glob('test_kalshi_arena*.py')):
            if path.stem != 'test_kalshi_arena_feed':
                importlib.import_module(path.stem)
                prior_modules.append(path.stem)
        # Keep GC enabled and thresholds unchanged. Natural allocations age some cycles;
        # dropping the holder leaves potential cyclic garbage for normal later collections.
        for index in range(25000):
            cycle: dict[str, Any] = {'index': index, 'payload': [index, str(index)]}
            cycle['self'] = cycle
            heap_load.append(cycle)
        del cycle
        heap_load.clear()

    before_counts = gc.get_count()
    before_stats = gc.get_stats()
    original_thresholds = gc.get_threshold()
    original_enabled = gc.isenabled()
    wall_starts = [0] * SAMPLES
    wall_ends = [0] * SAMPLES
    cpu_starts = [0] * SAMPLES
    cpu_ends = [0] * SAMPLES
    # Preallocated row slots keep our timing-record allocation out of the callback interval.
    gc_events: list[Any] = [None] * GC_CAPACITY
    gc_event_count = 0
    gc_event_drops = 0
    stage = 'prepare'

    def gc_event(phase: str, info: dict[str, Any]) -> None:
        nonlocal gc_event_count, gc_event_drops
        wall, cpu = time.perf_counter_ns(), time.thread_time_ns()
        if gc_event_count >= GC_CAPACITY:
            gc_event_drops += 1
            return
        gc_events[gc_event_count] = (phase, info['generation'], wall, cpu,
                                     info.get('collected'), info.get('uncollectable'), stage)
        gc_event_count += 1

    gc.callbacks.append(gc_event)
    with tempfile.TemporaryDirectory(prefix=f'exec-delay-scalar-arena-{variant}-', dir=OUT) as directory:
        clock = fixture.FakeClock(fixture.T0)
        runner = fixture.runner_at(Path(directory), clock)
        try:
            # Exact test fixture preparation, book/trade factories, 20 blocks, 500 pairs each.
            fixture.prepare(runner, clock)
            link = runner.arena
            assert isinstance(link, fixture.ArenaLink)
            link.running = True
            n = 0
            stage = 'samples'
            for block in range(20):
                runner.arena = link if block % 2 else None
                link.pending.clear()
                for _ in range(500):
                    n += 1
                    clock.advance(.001)
                    now = clock.now()
                    started = time.perf_counter_ns()
                    started_cpu = time.thread_time_ns()
                    runner.on_book(fixture.book(now, n))
                    runner.on_trade(fixture.trade(now, n))
                    ended_cpu = time.thread_time_ns()
                    ended = time.perf_counter_ns()
                    index = n - 1
                    wall_starts[index], wall_ends[index] = started, ended
                    cpu_starts[index], cpu_ends[index] = started_cpu, ended_cpu
            stage = 'capture'
            assert link.puts == 10000
            model_state = runner.desk.to_state()
            semantic_snapshot = {'model': model_state, 'live_calls': dict(runner.live.calls),
                                 'arena_puts': link.puts, 'arena_dropped': link.dropped,
                                 'receipt_chain': runner.ledger.verify_chain()}
            semantic_json = json.dumps(models.to_jsonable(semantic_snapshot), separators=(',', ':'), sort_keys=True)
            observer_status = runner.work_trace.status() if hasattr(runner, 'work_trace') else None
        finally:
            stage = 'close'
            runner.arena = None
            runner.close()
            gc.callbacks.remove(gc_event)

    assert gc.get_threshold() == original_thresholds and gc.isenabled() == original_enabled
    raw_gc = gc_events[:gc_event_count]
    active_gc: dict[int, tuple[Any, ...]] = {}
    gc_spans = []
    for event in raw_gc:
        phase, generation, wall, cpu, collected, uncollectable, event_stage = event
        if phase == 'start':
            active_gc[generation] = event
        elif phase == 'stop':
            begin = active_gc.pop(generation, None)
            if begin is not None:
                gc_spans.append({'generation': generation, 'start_wall_ns': begin[2], 'end_wall_ns': wall,
                                 'start_cpu_ns': begin[3], 'end_cpu_ns': cpu,
                                 'wall_ms': (wall - begin[2]) / 1e6,
                                 'cpu_ms': (cpu - begin[3]) / 1e6,
                                 'collected': collected, 'uncollectable': uncollectable,
                                 'start_stage': begin[6], 'end_stage': event_stage})
    samples = []
    for index in range(SAMPLES):
        start, end = wall_starts[index], wall_ends[index]
        wall_ms, cpu_ms = (end - start) / 1e6, (cpu_ends[index] - cpu_starts[index]) / 1e6
        overlapping = [{**span, 'overlap_wall_ms': (min(end, span['end_wall_ns']) - max(start, span['start_wall_ns'])) / 1e6,
                        'cpu_basis': 'full GC span thread CPU, not apportioned to clipped overlap'}
                       for span in gc_spans if span['start_wall_ns'] < end and span['end_wall_ns'] > start]
        samples.append({'sample': index + 1, 'block': index // 500, 'arena_on': bool((index // 500) % 2),
                        'start_wall_ns': start, 'end_wall_ns': end,
                        'start_cpu_ns': cpu_starts[index], 'end_cpu_ns': cpu_ends[index],
                        'wall_ms': wall_ms, 'cpu_ms': cpu_ms,
                        'wall_minus_cpu_ms': wall_ms - cpu_ms, 'gc_overlap': overlapping})
    summary = {}
    for metric in ('wall_ms', 'cpu_ms', 'wall_minus_cpu_ms'):
        on = [row[metric] for row in samples if row['arena_on']]
        off = [row[metric] for row in samples if not row['arena_on']]
        summary[metric] = {'on': distribution(on), 'off': distribution(off),
                           'on_minus_off_mean_ms': statistics.fmean(on) - statistics.fmean(off),
                           'on_minus_off_p99_ms': quantile(on, .99) - quantile(off, .99)}
    top_wall = sorted(samples, key=lambda row: row['wall_ms'], reverse=True)[:50]
    top_cpu = sorted(samples, key=lambda row: row['cpu_ms'], reverse=True)[:50]
    result = {'variant': variant, 'history': history, 'fixture': 'exact 20x500 callback book/print test',
              'selected_speedrunner_commit': selected_commit, 'model_commit': MODEL_BASE,
              'observer_helper_commit': OBSERVER, 'python': platform.python_version(),
              'pid': os.getpid(), 'independent_process': True, 'no_arena_process_started': True,
              'speedrunner_source_sha256': hashlib.sha256(runner_source.encode()).hexdigest(),
              'models_source_sha256': hashlib.sha256(model_source.encode()).hexdigest(),
              'helper_source_sha256': hashlib.sha256(work_source.encode()).hexdigest(),
              'gc': {'enabled': original_enabled, 'thresholds': original_thresholds,
                     'counts_before': before_counts, 'counts_after': gc.get_count(),
                     'stats_before': before_stats, 'stats_after': gc.get_stats(),
                     'event_drops': gc_event_drops, 'events': raw_gc, 'spans': gc_spans,
                     'unmatched_starts': len(active_gc), 'prior_modules': prior_modules,
                     'prior_cyclic_objects': 25000 if history == 'prior_modules_gc' else 0},
              'summary': summary, 'top_wall_outliers': top_wall, 'top_cpu_outliers': top_cpu,
              'all_wall_samples_above_1ms': [row for row in samples if row['wall_ms'] >= 1],
              'semantic_snapshot_sha256': hashlib.sha256(semantic_json.encode()).hexdigest(),
              'observer_status': observer_status, 'all_samples': samples,
              'legacy_wall_gate_met': summary['wall_ms']['on_minus_off_mean_ms'] < .02
                                     and summary['wall_ms']['on_minus_off_p99_ms'] < .5,
              'limits': ['Timing instrumentation and GC callback add overhead equally; this is a diagnostic, not the unchanged pytest test.',
                         'Pre-observer/current SpeedRunner class bodies loaded from immutable commits; shared dependency modules remain current except immutable model conversion and observer helper.',
                         'History scenario is explicit synthetic cyclic garbage plus prior-module imports, not reconstruction of the prior full suite.',
                         'Wall minus thread CPU does not by itself identify scheduler, process suspension, I/O or GC waiting.',
                         'A GC overlap is correlation; compare actual GC wall/CPU and observer baseline before causal claims.']}
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'variant': variant, 'history': history, 'summary': summary,
                      'legacy_wall_gate_met': result['legacy_wall_gate_met'],
                      'gc_events': gc_event_count, 'gc_event_drops': gc_event_drops, 'output': str(output)}))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-confirmed', action='store_true', help='Root explicitly confirmed full suite ended')
    parser.add_argument('--worker', choices=('baseline', 'observer'))
    parser.add_argument('--history', choices=('fresh', 'prior_modules_gc'), default='fresh')
    parser.add_argument('--output', type=Path)
    options = parser.parse_args()
    if not options.run_confirmed:
        print('PREPARED ONLY. Wait for root full-suite completion; then supply --run-confirmed.')
        return
    if options.worker:
        if options.output is None:
            parser.error('--worker requires --output')
        worker(options.worker, options.history, options.output)
        return
    results = []
    for history in ('fresh', 'prior_modules_gc'):
        for variant in ('baseline', 'observer'):
            output = OUT / f'exec-delay-scalar-arena-{history}-{variant}.json'
            # Sequential fresh processes avoid creating benchmark contention between variants.
            subprocess.run([sys.executable, __file__, '--run-confirmed', '--worker', variant,
                            '--history', history, '--output', str(output)], check=True, cwd=ROOT)
            results.append(json.loads(output.read_text()))
    comparisons = []
    for history in ('fresh', 'prior_modules_gc'):
        baseline = next(row for row in results if row['history'] == history and row['variant'] == 'baseline')
        observer = next(row for row in results if row['history'] == history and row['variant'] == 'observer')
        comparisons.append({'history': history,
                            'semantic_snapshot_equal': baseline['semantic_snapshot_sha256'] == observer['semantic_snapshot_sha256'],
                            'observer_minus_baseline': {
                                metric: {group: {stat: observer['summary'][metric][group][stat] - baseline['summary'][metric][group][stat]
                                                 for stat in ('mean_ms', 'median_ms', 'p99_ms', 'max_ms')}
                                         for group in ('on', 'off')}
                                for metric in ('wall_ms', 'cpu_ms', 'wall_minus_cpu_ms')}})
    path = OUT / 'exec-delay-scalar-arena-comparison.json'
    path.write_text(json.dumps({'comparisons': comparisons, 'result_files': [str(OUT / f'exec-delay-scalar-arena-{row["history"]}-{row["variant"]}.json') for row in results]}, indent=2) + '\n')
    print(json.dumps({'comparisons': comparisons, 'comparison_file': str(path)}, indent=2))


if __name__ == '__main__':
    main()
