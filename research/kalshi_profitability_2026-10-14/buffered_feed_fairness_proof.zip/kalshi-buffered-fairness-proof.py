"""Offline scheduling proof: actual adapter and websocket parser; fabricated market frames."""
from __future__ import annotations
import asyncio
import hashlib
import inspect
import json
import logging
from pathlib import Path
import socket
import sys
import threading
import time
import websockets
from websockets.protocol import Protocol, Side
from websockets.frames import Frame, OP_TEXT
from websockets.asyncio.connection import Connection
from websockets.asyncio.messages import Assembler, SimpleQueue
from nightcrawler.config import Settings
from nightcrawler.speeddesk_kalshi_ws import KalshiMarketWS, MarketState

ROOT=Path('/workspace/nightcrawler-next-evidence')
OUT=Path('/workspace/shared/kalshi-buffered-fairness-proof.json')
T=1792019700.0
TICKER='KXBTC15M-FAKE-FAIRNESS'

def denied(*args,**kwargs):
    raise AssertionError('offline proof prohibits sockets, threads and clients')

class Transport:
    def __init__(self): self.pauses=0;self.resumes=0
    def pause_reading(self): self.pauses+=1
    def resume_reading(self): self.resumes+=1
    def set_write_buffer_limits(self,*args): pass
    def write(self,data): raise AssertionError('unexpected protocol write')

class AdapterSocket:
    def __init__(self,connection): self.connection=connection;self.sent=[]
    async def send(self,message): self.sent.append(json.loads(message))
    async def recv(self): return await self.connection.recv()

async def scenario(total,initial):
    loop=asyncio.get_running_loop()
    transport=Transport()
    connection=Connection(Protocol(Side.CLIENT,max_size=1_000_000),max_queue=16,ping_interval=None)
    connection.connection_made(transport)
    frames=[]
    for index in range(total):
        payload={'type':'orderbook_delta','sid':7,'seq':index+2,
                 'msg':{'market_ticker':TICKER,'side':'yes','price_dollars':'.4',
                        'delta_fp':'0.00','ts_ms':int(T*1000)}}
        frames.append(Frame(OP_TEXT,json.dumps(payload).encode()).serialize(mask=False))
    def supply(begin,end): connection.data_received(b''.join(frames[begin:end]))
    supply(0,initial)
    peak=len(connection.recv_messages.frames)
    assert peak==initial
    callbacks=[];events=[];statuses=[];stop=threading.Event()
    completed=loop.create_future()
    async def account():
        await completed
        events.append({'event':'account_resumed','book_callbacks':len(callbacks),
                       'remaining_buffered_frames':len(connection.recv_messages.frames),
                       'mono_ns':time.perf_counter_ns()})
    account_task=asyncio.create_task(account())
    await asyncio.sleep(0)  # Establish a separately suspended account coroutine before input.
    def on_book(book):
        callbacks.append((book.sequence,book.side))
        if len(callbacks)==1:
            events.append({'event':'synthetic_worker_completed','book_callbacks':1,
                           'mono_ns':time.perf_counter_ns()})
            completed.set_result(None)
            if initial<total:
                loop.call_soon(supply,initial,total)
        if len(callbacks)==total*2: stop.set()
    reader=KalshiMarketWS(Settings(kalshi_key_id=None,kalshi_private_key=None,
        speeddesk_kalshi_mode='paper',speeddesk_kalshi_live_confirm=None),
        tickers=lambda:frozenset((TICKER,)),on_book=on_book,on_trade=denied,
        on_status=statuses.append,clock=lambda:T,ws_connect=denied)
    reader.connected=True
    reader.state=MarketState(frozenset((TICKER,)))
    reader.state.apply({'type':'subscribed','id':1,'msg':{'sid':7,'channel':'orderbook_delta'}},T)
    reader.state.apply({'type':'orderbook_snapshot','sid':7,'seq':1,
        'msg':{'market_ticker':TICKER,'yes_dollars_fp':[['.4','1']],
               'no_dollars_fp':[['.6','1']]}},T)
    ws=AdapterSocket(connection)
    await reader._session(ws,frozenset((TICKER,)),stop)
    await account_task
    assert len(callbacks)==total*2
    assert [sequence for sequence,side in callbacks if side=='up']==[f'kalshi-ws:7:{i+2}' for i in range(total)]
    resumed=events[-1]['book_callbacks']
    assert resumed==initial*2
    return {'total_messages':total,'initial_single_data_received_messages':initial,
            'frame_count_equals_message_count':True,'high_water':connection.recv_messages.high,
            'low_water':connection.recv_messages.low,'initial_buffered_frames':peak,
            'initial_wire_bytes':sum(map(len,frames[:initial])),'transport_pauses':transport.pauses,
            'transport_resumes':transport.resumes,'events':events,'callbacks':callbacks,
            'resumption_gap_ms':(events[-1]['mono_ns']-events[0]['mono_ns'])/1e6,
            'subscription_messages':ws.sent,'status_callbacks':len(statuses)}

async def main():
    # Event-loop infrastructure already exists; deny every later socket/thread allocation.
    socket.socket=denied;socket.create_connection=denied;threading.Thread.start=denied
    cases=[await scenario(16,16),await scenario(16,8),await scenario(64,64)]
    objects=(asyncio.wait_for,Connection.recv,Connection.data_received,Assembler.__init__,
             Assembler.get,SimpleQueue.get,KalshiMarketWS._session)
    sources={obj.__qualname__:{'path':inspect.getsourcefile(obj),
        'line':inspect.getsourcelines(obj)[1],'source':inspect.getsource(obj)} for obj in objects}
    output={'python':sys.version,'websockets':websockets.__version__,'cases':cases,'sources':sources,
        'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest()
                        for p in {Path(inspect.getsourcefile(obj)) for obj in objects}},
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'limitations':['Scheduling counterexample, not reproduction or attribution of any production multi-second gap.',
            'No actual account/HTTP worker: a future models a separately waiting account coroutine becoming ready.',
            'Actual Kalshi _session, MarketState, positive-timeout wait_for, Connection.recv/data_received, Protocol and Assembler.',
            'Fake no-op outbound subscribe; no handshake, credentials, network, worker threads, trading or persistence.',
            'Frames are single unfragmented text messages with one valid synthetic book delta each; no array-of-events fabrication.',
            'max_queue=16 retained exactly; 64-frame case uses one bounded receive chunk (exact byte count recorded per case) and actual flow control.',
            'No artificial CPU delay; elapsed numbers are incidental, ordering is the deterministic assertion.',
            'Empty-buffer control injects second chunk on a later loop turn; shared future readiness precedes that injection.']}
    assert not OUT.exists()
    OUT.write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({'cases':[{k:v for k,v in case.items() if k not in ('callbacks','subscription_messages')}
        for case in cases],'result_sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),
        'script_sha256':output['script_sha256']},indent=2))

if __name__=='__main__':
    logging.disable(logging.CRITICAL)
    loop=asyncio.new_event_loop()
    try: loop.run_until_complete(main())
    finally: loop.close()
