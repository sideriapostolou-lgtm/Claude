"""Bounded offline quiet callback density profile; no production state or client."""
from __future__ import annotations

import cProfile
import dataclasses
import hashlib
import json
import logging
import pstats
import socket
import statistics
import subprocess
import tempfile
import threading
import time
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path('/workspace/nightcrawler-next-evidence')
OUT = Path('/workspace/shared/scorecard-grouping-benchmark.json')

def denied(*args, **kwargs):
    raise RuntimeError('offline diagnostic denies socket/client/thread use')

# Before imports/fixture: prohibit all socket allocation, network and worker threads.
class DeniedSocket(socket.socket):
    def __init__(self, *args, **kwargs):
        denied(*args, **kwargs)

socket.socket = DeniedSocket
socket.create_connection = denied
threading.Thread.start = denied

from test_kalshi_arena_feed import LocalFeeds

from nightcrawler.clock import FakeClock
from nightcrawler.config import Settings
from nightcrawler.speeddesk import SpeedRunner
from nightcrawler.speeddesk_live import Intent, KalshiLiveDesk
from nightcrawler.speeddesk_live_model import ActualFill, LiveIntent
from nightcrawler.speeddesk_model import PracticeOrder, Window

logging.disable(logging.CRITICAL)
SLUG = 'KXBTC15M-QUIET-CURRENT'
T0 = 1792016160.0

class Feeds(LocalFeeds):
    def maker_windows(self):
        return {SLUG}


def native(value):
    if dataclasses.is_dataclass(value):
        return native(dataclasses.asdict(value))
    if isinstance(value, dict):
        return {str(key): native(val) for key, val in value.items()}
    if isinstance(value, (list, tuple)):
        return [native(val) for val in value]
    return value


def digest(value):
    return hashlib.sha256(json.dumps(native(value), sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def main():
    run_started_at = datetime.now(UTC).isoformat()
    import nightcrawler.speeddesk_live as live_module
    namespace = dict(vars(live_module))
    baseline_source = (ROOT / 'tests/fixtures/speeddesk_scorecard_baseline.py.txt').read_text()
    exec(compile(baseline_source, '<frozen-scorecard-baseline>', 'exec'), namespace)  # noqa: S102 - frozen local baseline.
    baseline = namespace['scorecard']
    candidate = KalshiLiveDesk.scorecard
    results=[]
    with tempfile.TemporaryDirectory(prefix='panel-profile-',dir='/workspace/shared') as directory:
        clock=FakeClock(T0)
        def live_factory(settings,path,snapshot,**kwargs):
            return KalshiLiveDesk(settings,path,snapshot,client_factory=denied,**kwargs)
        runner=SpeedRunner(Settings(data_dir=Path(directory),speeddesk_kalshi_enabled=True,
            speeddesk_kalshi_mode='paper',speeddesk_kalshi_live_confirm=None,
            kalshi_key_id=None,kalshi_private_key=None,kalshi_arena_enabled=False),
            threading.Event(),clock=clock,feed_factory=Feeds,live_factory=live_factory)
        try:
            live=runner.live
            assert live is not None and live.client is None
            fills=[]
            for i in range(200):
                begin=T0-(201-i)*900
                w=Window(f'KXBTC15M-PANEL-{i:04}',begin,begin+900,80000,
                    venue='kalshi',venue_start_price=80000,taker_coefficient=.07,
                    maker_coefficient=0,fee_rounding='kalshi')
                for model in (runner.desk,live.twin,live.book):
                    model.add_window(dataclasses.replace(w))
                for j,side in enumerate(('up','down')):
                    k=i*2+j; key=f'nc-speed-panel-{k}'; at=begin+30+j
                    price=.4 if side=='up' else .5
                    live.book.intents[key]=LiveIntent(key,w.slug,side,'rest',price,1,at-1,price,
                        order_id=f'o{k}')
                    live.intents[key]=Intent(key,w.slug,side,'rest',price,1,.5,at-1,
                        order_id=f'o{k}',terminal=True)
                    fill=ActualFill(f'f{k}',f'o{k}',key,w.slug,side,price,1,0,at,is_taker=False)
                    assert live.book.record_fill(fill)
                    fills.append(dataclasses.asdict(fill))
                    for model in (runner.desk,live.twin):
                        order=PracticeOrder(k+1,w.slug,side,'rest',price,1,1,at-1,at-1,.5,0,0,'fixture',
                            fee_rounding='kalshi',min_trade_qty=.01)
                        model.orders[k+1]=order
                        model._fill(order,1,at)
                        model.next_order_id=k+2
                runner.desk.settle(w.slug,True,w.end+1)
                live.twin.settle(w.slug,True,w.end+1)
                live.book.settle(w.slug,True,w.end+1,f's{i}')
                live.position_sizes[w.slug]=0
            for k in range(400,3350):
                spec=runner.desk.windows[f'KXBTC15M-PANEL-{k%200:04}']
                key=f'nc-speed-panel-{k}'; at=spec.start+10
                live.book.intents[key]=LiveIntent(key,spec.slug,'up','rest',.4,1,at,.4,
                    order_id=f'o{k}',status='canceled',reservation_active=False)
                live.intents[key]=Intent(key,spec.slug,'up','rest',.4,1,.5,at,
                    order_id=f'o{k}',terminal=True)
            runner.on_windows([Window(SLUG,T0-60,T0+840,80000,venue='kalshi',
                venue_start_price=80000,taker_coefficient=.07,maker_coefficient=0,fee_rounding='kalshi')])
            runner.on_tick(80000,T0,T0)
            runner.on_status({'coinbase':'connected','trade_stream':True,'markets':'connected'})
            runner.checkpoint(T0)
            fixture={'fills':fills,'book':live.book.to_state(),'practice':runner.desk.to_state(),
                'twin':live.twin.to_state(),'controller_intents':native(live.intents),
                'positions':live.position_sizes,'now':T0,'historical_windows':200,'fill_count':400,'intent_count':3350}
            timing_started_at = datetime.now(UTC).isoformat()
            for rep in range(6):
                variants = [('baseline',baseline),('candidate',candidate)]
                if rep % 2:
                    variants.reverse()
                for variant, method in variants:
                    KalshiLiveDesk.scorecard=method
                    for name,fn in (('panel',live.panel),('checkpoint',lambda:runner.checkpoint(T0))):
                        wall,cpu=time.perf_counter_ns(),time.thread_time_ns(); value=fn()
                        elapsed_wall=(time.perf_counter_ns()-wall)/1e6
                        elapsed_cpu=(time.thread_time_ns()-cpu)/1e6
                        state = runner.ledger.get_kv('speeddesk_state')
                        # Determine saved state through mirror too, without timing its verification.
                        mirror = json.loads(runner.path.read_text())
                        results.append({'rep':rep,'variant':variant,'name':name,'wall_ms':elapsed_wall,
                            'cpu_ms':elapsed_cpu,'output_sha256':digest(value),'mirror_sha256':digest(mirror),
                            'ledger_optional_sha256':digest(state),'receipts_sha256':digest(runner.ledger.receipts()),
                            'receipt_chain':runner.ledger.verify_chain(),
                            'model_sha256':digest((live.book.to_state(),live.twin.to_state(),runner.desk.to_state()))})
            timing_ended_at = datetime.now(UTC).isoformat()
            profiles={}
            for variant, method in (('baseline',baseline),('candidate',candidate)):
                KalshiLiveDesk.scorecard=method
                for name,fn in (('panel',live.panel),('checkpoint',lambda:runner.checkpoint(T0))):
                    prof=cProfile.Profile();prof.enable();fn();prof.disable()
                    profiles[variant+'_'+name]=[{'file':key[0],'line':key[1],'function':key[2],'calls':v[1],
                        'self_ms':v[2]*1000,'cumulative_ms':v[3]*1000}
                        for key,v in pstats.Stats(prof).stats.items()]
            KalshiLiveDesk.scorecard=candidate
            output={'run_started_at':run_started_at, 'timing_started_at':timing_started_at,
                'timing_ended_at':timing_ended_at,'run_ended_at':datetime.now(UTC).isoformat(),
                'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
                'fixture':fixture,'fixture_sha256':digest(fixture),'runs':results,'profiles':profiles,
                'medians':{variant:{name:{field:statistics.median(r[field] for r in results
                    if r['name']==name and r['variant']==variant) for field in ('wall_ms','cpu_ms')}
                    for name in ('panel','checkpoint')} for variant in ('baseline','candidate')},
                'equivalent':{field:len({r[field] for r in results if r['name']==name})==1
                    for name in ('panel','checkpoint') for field in ('mirror_sha256','receipts_sha256','model_sha256')},
                'output_equivalent':{name:len({r['output_sha256'] for r in results if r['name']==name})==1
                    for name in ('panel','checkpoint')},
                'baseline_function_sha256':hashlib.sha256(baseline_source.encode()).hexdigest(),
                'limitations':['Invented historical fixture, not production replay; zero fees, paired one-contract fills .4UP/.5DOWN.',
                    'Actual record_fill/settle/_fill APIs; intents/orders seeded like history tests, not controller send logic.',
                    'Paper mode, no keys/client/threads/network. Cold Bitcoin tape, no live orders, markout waiters or real latency history.',
                    'Started_at current T0: historical daily report creation excluded; scorecards still scan full retained history.',
                    'Six alternating panel/checkpoint unprofiled repetitions, separate one-call cProfile phases.',
                    'Temporary SQLite/mirror writes are real local writes; no persistence method is stubbed.'],
                'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
            output['source_sha256']={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                for p in (ROOT/'src/nightcrawler/speeddesk.py',ROOT/'src/nightcrawler/speeddesk_live.py',
                    ROOT/'src/nightcrawler/speeddesk_live_model.py',ROOT/'src/nightcrawler/speeddesk_model.py')}
            OUT.write_text(json.dumps(output,indent=2,allow_nan=False)+'\n')
            print(output['medians'])
            for name,rows in profiles.items():
                print(name,sorted(rows,key=lambda r:r['cumulative_ms'],reverse=True)[:16])
            print('hash',hashlib.sha256(OUT.read_bytes()).hexdigest())
        finally:
            KalshiLiveDesk.scorecard=candidate
            runner.close()

if __name__=='__main__':
    main()
