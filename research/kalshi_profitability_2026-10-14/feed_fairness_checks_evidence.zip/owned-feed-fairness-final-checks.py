from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

ROOT = Path('/workspace/nightcrawler-next-evidence')
SHARED = Path('/workspace/shared')
PYTHON = '/workspace/shared/nightcrawler-venv/bin/python'
FILES = ['src/nightcrawler/speeddesk_feeds.py', 'src/nightcrawler/speeddesk_kalshi_ws.py',
         'tests/test_speeddesk_feed_fairness.py', 'tests/test_speeddesk_feed_fairness_independent.py']

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def hashes():
    return {name: hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in FILES}

receipt = {'started_utc': now(), 'base_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
           'files_before': hashes(), 'checks': []}
steps = [('pytest', [PYTHON, '-m', 'pytest', '-q']),
         ('mypy', ['/workspace/shared/nightcrawler-venv/bin/mypy', 'src/nightcrawler']),
         ('ruff', ['/workspace/shared/nightcrawler-venv/bin/ruff', 'check', *FILES])]
for name, command in steps:
    log = SHARED / ('owned-feed-fairness-final-' + name + '.log')
    started = now()
    with log.open('w') as stream:
        result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, check=False)
    item = {'name': name, 'command': command, 'started_utc': started, 'ended_utc': now(),
            'returncode': result.returncode, 'log_path': str(log), 'log_bytes': log.stat().st_size,
            'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
    receipt['checks'].append(item)
    print(json.dumps(item), flush=True)
    print('\n'.join(log.read_text().splitlines()[-5:]), flush=True)
receipt['files_after'] = hashes()
receipt['unchanged_during_checks'] = receipt['files_before'] == receipt['files_after']
receipt['ended_utc'] = now()
receipt['runner_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
receipt['passed'] = receipt['unchanged_during_checks'] and all(item['returncode'] == 0 for item in receipt['checks'])
(SHARED/'owned-feed-fairness-final-checks.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps({'passed': receipt['passed'], 'unchanged': receipt['unchanged_during_checks']}), flush=True)
sys.exit(0 if receipt['passed'] else 1)
