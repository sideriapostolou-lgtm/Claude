"""Offline CPU evidence, actual callbacks; no account clients or network."""
import asyncio
import cProfile
import hashlib
import io
import json
import math
from pathlib import Path
import pstats
import resource
import socket
import statistics
import subprocess
import sys
import threading
import time
import tracemalloc

from websockets.client import ClientProtocol
from websockets.datastructures import Headers
from websockets.frames import Frame, Opcode
from websockets.http11 import Response
from websockets.protocol import OPEN
from websockets.uri import parse_uri
import websockets
from nightcrawler.clock import FakeClock
from nightcrawler.config import Settings
from nightcrawler.speeddesk import SpeedRunner
from nightcrawler.speeddesk_model import Window
from nightcrawler.speeddesk_kalshi_ws import MarketState
from nightcrawler.speeddesk_ws_timing import TimingClientConnection

ROOT=Path('/workspace/shared/feed-hotpath-profile-artifacts')
ROOT.mkdir(exist_ok=True)
BASE=1791475200.0
ACTIVE='KXBTC15M-SYNTHETIC-ACTIVE'
NEXT='KXBTC15M-SYNTHETIC-NEXT'
N=1000


def forbidden(*args,**kwargs):
    raise AssertionError('offline hotpath profile forbids network/account clients')
socket.socket.connect=forbidden
socket.create_connection=forbidden


class NoFeeds:
    def __init__(self,*args,**kwargs): pass
    def maker_windows(self): return {ACTIVE,NEXT}


class Transport(asyncio.Transport):
    def set_write_buffer_limits(self,*args,**kwargs): pass
    def pause_reading(self): pass
    def resume_reading(self): pass
    def write(self,data): pass
    def is_closing(self): return False


def setup(history):
    clock=FakeClock(BASE-3601)
    folder=ROOT/f'fixture-{history}-{time.monotonic_ns()}'
    # Explicit constructor, not Settings.from_env; modes remain default paper,
    # all key/token fields empty. Actual ledgers use only this fresh directory.
    runner=SpeedRunner(Settings(data_dir=folder),threading.Event(),clock=clock,feed_factory=NoFeeds)
    runner.live.client_factory=forbidden
    assert runner.live.client is None
    assert runner.live.settings.speeddesk_kalshi_mode=='paper'
    assert runner.live.settings.kalshi_key_id is None and runner.live.settings.kalshi_private_key is None
    for i in range(3602):
        if i: clock.sleep(1)
        now=clock.now()
        runner.on_tick(80000+3*math.sin(i/11),now,now)
    assert clock.now()==BASE
    past=[Window(f'KXBTC15M-SYNTHETIC-CLOSED-{i:04d}',BASE-(history-i+1)*900,
                 BASE-(history-i)*900,80000.,venue_start_price=80000.,venue='kalshi')
          for i in range(history)]
    present=[Window(ACTIVE,BASE,BASE+900,80000.,venue_start_price=80000.,venue='kalshi'),
             Window(NEXT,BASE+900,BASE+1800,80000.,venue_start_price=80000.,venue='kalshi')]
    runner.on_windows(past+present)
    for i,window in enumerate(past):
        # Valid zero-position public-observation history, settled through each
        # model's real API. No invented fills, reservations, P&L or dataclasses.
        assert runner.desk.settle(window.slug,bool(i%2),window.end) is not None
        assert runner.live.book.settle(window.slug,bool(i%2),window.end,f'synthetic-settlement-{i}') is not None
        runner.live.on_settlement(window.slug,bool(i%2),window.end)
    runner.on_status({'coinbase':'connected','markets':'connected','trade_stream':True})
    runner._refresh_live_snapshot()
    assert runner.live_snapshot().sigma is not None
    runner.checkpoint(clock.now())
    runner.live.checkpoint()
    assert not runner.pending and not runner.live.pending
    assert runner.live.client is None
    return runner,clock


def native_connection():
    protocol=ClientProtocol(parse_uri('ws://example.invalid'),state=OPEN)
    conn=TimingClientConnection(protocol)
    conn.connection_made(Transport())
    conn.response=Response(101,'Switching Protocols',Headers())
    return conn


async def workload(runner,clock,kind,count=N):
    conn=native_connection()
    market=MarketState(frozenset({ACTIVE,NEXT}))
    market.apply({'id':1,'type':'subscribed','msg':{'sid':7,'channel':'orderbook_delta'}},clock.now())
    market.apply({'id':2,'type':'subscribed','msg':{'sid':8,'channel':'trade'}},clock.now())
    for seq,ticker in enumerate((ACTIVE,NEXT),1):
        assert market.apply({'type':'orderbook_snapshot','sid':7,'seq':seq,
          'msg':{'market_ticker':ticker,'yes_dollars_fp':[['0.40','20.00']],
                 'no_dollars_fp':[['0.60','20.00']]}},clock.now())==((),())
    # Create payloads before timing so generation/JSON encoding isn't mistaken
    # for received-message processing. Source times match scripted receipts.
    initial=clock.now()
    payloads=[]
    for i in range(count):
        ticker=ACTIVE if i%2==0 else NEXT
        timestamp=round((initial+(i+1)*0.001)*1000)
        if kind=='book':
            raw={'type':'orderbook_delta','sid':7,'seq':i+3,'sending_ts_ms':timestamp,
                 'msg':{'market_ticker':ticker,'side':'yes','price_dollars':'0.40',
                        'delta_fp':'0.01' if (i//2)%2==0 else '-0.01','ts_ms':timestamp}}
        else:
            raw={'type':'trade','sid':8,'seq':i+1,'sending_ts_ms':timestamp,
                 'msg':{'market_ticker':ticker,'yes_price_dollars':'0.40','no_price_dollars':'0.60',
                        'count_fp':'1.00','ts_ms':timestamp,'taker_outcome_side':'yes','taker_book_side':'bid',
                        'is_block_trade':False,'trade_id':f'synthetic-{initial}-{i}'}}
        payloads.append(Frame(Opcode.TEXT,json.dumps(raw,separators=(',',':')).encode()).serialize(mask=False))
    # Last accepted BTC tick is refreshed outside the measured region, leaving
    # coherent fresh BTC for the full one-second batch and default sigma rules.
    runner.on_tick(80000.,clock.now(),clock.now())
    def counts():
        return {'practice_windows':len(runner.desk.windows),'practice_closed':len(runner.desk.closed),
          'twin_windows':len(runner.live.twin.windows),'twin_closed':len(runner.live.twin.closed),
          'live_windows':len(runner.live.book.windows),'live_settled':len(runner.live.book.settled),
          'practice_orders':len(runner.desk.orders),'twin_orders':len(runner.live.twin.orders),
          'live_intents':len(runner.live.intents),'practice_pending':len(runner.pending),
          'live_pending':len(runner.live.pending),'practice_books':len(runner.desk.books),
          'practice_trade_ids':len(runner.desk.seen_trades),
          'tape_seconds':len(runner.desk.tape.prices),'twin_tape_seconds':len(runner.live.twin.tape.prices)}
    before=counts()
    callback_count=0
    wall,cpu,thread=time.perf_counter(),time.process_time(),time.thread_time()
    for i,payload in enumerate(payloads):
        clock.sleep(0.001)
        conn.data_received(payload)
        message=await conn.recv()
        books,trades=market.apply(json.loads(message),clock.now())
        for book in books:
            runner.on_book(book);callback_count+=1
        for trade in trades:
            runner.on_trade(trade);callback_count+=1
    elapsed={'wall_ms':(time.perf_counter()-wall)*1000,'process_cpu_ms':(time.process_time()-cpu)*1000,
             'thread_cpu_ms':(time.thread_time()-thread)*1000}
    assert callback_count==count*2
    assert runner.live.client is None
    assert len(runner.desk.closed)==len(runner.live.twin.closed)==len(runner.live.book.settled)
    assert runner.live.book.realized_pnl==0
    return {**elapsed,'messages':count,'callbacks':callback_count,'before':before,'after':counts(),
            'native_observer':conn.timing_status(),'wire_bytes':sum(map(len,payloads))}


results={'base_sha':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'python':sys.version,'websockets':websockets.__version__,
 'scope':'Offline generated paper state, no account client/network, source flags/rules unchanged',
 'method':'1000 native WS text data frames -> public recv -> json.loads -> MarketState.apply -> 2000 actual runner callbacks per batch; q=0 orders/intents; one buffered frame at a time. Current and next tickers alternate.',
 'history':'Valid zero-position past windows settled through actual practice/live/twin APIs; no trading performance inference.',
 'omissions':['No async _session subscription/yield/status/diagnostic logger flow, socket/TLS/kernel/provider timing or network.',
              'No real orders, fills, queues, positions, intent reconciliation, strategy evaluate/step loop, checkpoint or mirror inside measured callbacks.',
              'No arena: actual default separate arena is absent. Only actual main runner and its paper Kalshi companion.',
              'File-backed SQLite fixtures/checkpoints before timing, no I/O replacement or MemoryLedger; setup I/O omitted from timing.',
              'Fake wall clock for market freshness advances1ms/message; real monotonic/process/thread clocks measure CPU. Instrumented cProfile samples separated from ordinary runs.'],
 'cases':{}}
for history in (0,128,512):
    runner,clock=setup(history)
    case={}
    try:
        for kind in ('book','trade'):
            samples=[asyncio.run(workload(runner,clock,kind)) for _ in range(5)]
            profiler=cProfile.Profile()
            profiler.enable()
            profiled=asyncio.run(workload(runner,clock,kind))
            profiler.disable()
            label=f'history-{history}-{kind}'
            profiler.dump_stats(str(ROOT/f'{label}.prof'))
            stream=io.StringIO()
            pstats.Stats(profiler,stream=stream).strip_dirs().sort_stats('cumulative').print_stats(30)
            (ROOT/f'{label}.txt').write_text(stream.getvalue())
            tracemalloc.start()
            asyncio.run(workload(runner,clock,kind))
            current,peak=tracemalloc.get_traced_memory()
            tracemalloc.stop()
            case[kind]={'samples':samples,'profiled':profiled,'traced_batch_current_bytes':current,'traced_batch_peak_bytes':peak,
              'wall_median_ms':statistics.median(x['wall_ms'] for x in samples),
              'process_cpu_median_ms':statistics.median(x['process_cpu_ms'] for x in samples),
              'thread_cpu_median_ms':statistics.median(x['thread_cpu_ms'] for x in samples),
              'process_rss_peak_kib_so_far':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
            print(history,kind,case[kind]['wall_median_ms'],case[kind]['process_cpu_median_ms'],flush=True)
        results['cases'][str(history)]=case
        (ROOT/'results.json').write_text(json.dumps(results,indent=2,allow_nan=False))
    finally:
        runner.close()
