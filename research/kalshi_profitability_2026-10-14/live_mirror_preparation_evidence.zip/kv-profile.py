"""Offline synthetic profiling only. Never imports account fixtures or runs feeds."""
import copy
import cProfile
import hashlib
import io
import json
import math
from pathlib import Path
import pstats
import socket
import statistics
import sys
import threading
import time

from fakes import FakeClock
from nightcrawler.config import Settings
from nightcrawler.ledger import Ledger, _dumps
from nightcrawler.models import to_jsonable
from nightcrawler.speeddesk import SpeedRunner
from nightcrawler.speeddesk_model import Window

ROOT = Path('/workspace/shared/kv-profile-artifacts')
ROOT.mkdir(exist_ok=True)


def deny_network(*args, **kwargs):
    raise AssertionError('offline profiling forbids network')

socket.socket.connect = deny_network
socket.create_connection = deny_network


class NoFeeds:
    def __init__(self, *args, **kwargs):
        pass

    def maker_windows(self):
        return set()


captured = {}
original_set_kv = Ledger.set_kv
original_dump = json.dump
mirror_capture = {}

def capture_dump(value, stream, *args, **kwargs):
    if isinstance(value, dict) and "book" in value and "twin" in value:
        mirror_capture["full"] = copy.deepcopy(value)
    return original_dump(value, stream, *args, **kwargs)

json.dump = capture_dump


def capture(self, key, value):
    captured[key] = copy.deepcopy(value)
    return original_set_kv(self, key, value)


Ledger.set_kv = capture
clock = FakeClock()
runner = SpeedRunner(Settings(data_dir=ROOT / f'fixture-{time.monotonic_ns()}'), threading.Event(), clock=clock,
                     feed_factory=NoFeeds)
now = clock.now()
runner.on_windows([Window('KXBTC15M-SYNTHETIC', now, now + 900, 80000., venue_start_price=80000., venue='kalshi'),
                   Window('SYNTHETIC-US', now, now + 900, 80000.)])
runner.on_tick(80000., now, now)
runner.live.book.add_window(Window('KXBTC15M-SYNTHETIC', now, now + 900, 80000., venue_start_price=80000., venue='kalshi'))
runner.checkpoint(now)
runner.live.last_mirror = -math.inf
runner.live.checkpoint()
runner.close()
Ledger.set_kv = original_set_kv
json.dump = original_dump
(ROOT / "live_mirror_actual_fixture.json").write_text(json.dumps(mirror_capture["full"], allow_nan=False, separators=(",", ":")))

practice = captured['speeddesk_state'] if 'speeddesk_state' in captured else None
print('capture keys', sorted(captured))
for key, value in captured.items():
    if isinstance(value, dict) and value.get('mode') == 'practice':
        practice = value
    elif isinstance(value, dict) and 'book' in value and 'twin' in value:
        live = value
assert practice is not None


def heavy(state, model_key, scale):
    """Clone only detached native model window/inventory shapes; no engine replay."""
    result = copy.deepcopy(state)
    model = result[model_key]
    windows = model['windows']
    sample_key = next(iter(windows))
    sample = copy.deepcopy(windows[sample_key])
    inventory = copy.deepcopy(model['inventory'][sample_key])
    for i in range(scale):
        key = f'SYNTHETIC-WINDOW-{i:06d}'
        model['windows'][key] = {**sample, 'slug': key}
        model['inventory'][key] = copy.deepcopy(inventory)
    return result


states = {'practice_fixture': practice, 'live_fixture': live,
          'practice_512': heavy(practice, 'model', 512),
          'live_512': heavy(live, 'book', 512),
          'practice_4096': heavy(practice, 'model', 4096),
          'live_4096': heavy(live, 'book', 4096)}


def profile(label, function, repeat):
    profiler = cProfile.Profile()
    profiler.enable()
    for _ in range(repeat):
        function()
    profiler.disable()
    profiler.dump_stats(str(ROOT / f'{label}.prof'))
    stream = io.StringIO()
    pstats.Stats(profiler, stream=stream).strip_dirs().sort_stats('cumulative').print_stats(22)
    (ROOT / f'{label}.txt').write_text(stream.getvalue())


metadata = {}
with Ledger(':memory:') as ledger:
    for name, state in states.items():
        text = _dumps(state)
        metadata[name] = {'bytes_ascii': len(text), 'sha256': hashlib.sha256(text.encode()).hexdigest()}
        (ROOT / f'{name}.json').write_text(text)
        repeat = 8 if '4096' in name else 30
        profile(f'{name}_actual_set_kv', lambda state=state: ledger.set_kv('synthetic', state), repeat)
        samples = []
        for _ in range(9):
            wall, cpu = time.perf_counter(), time.process_time()
            ledger.set_kv('synthetic', state)
            samples.append({'wall_ms': (time.perf_counter()-wall)*1000, 'cpu_ms': (time.process_time()-cpu)*1000})
        metadata[name]['baseline_set_kv_samples'] = samples
        print(name, len(text), 'baseline_set_kv_wall_ms_median', statistics.median(row['wall_ms'] for row in samples))
(ROOT / 'baseline.json').write_text(json.dumps(metadata, indent=2, allow_nan=False))
