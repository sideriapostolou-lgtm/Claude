"""Compare unchanged live mirror encoder vs offline one-write prototype."""
import copy
import cProfile
import hashlib
import io
import json
import os
from pathlib import Path
import pstats
import statistics
import time
ROOT = Path('/workspace/shared/kv-profile-artifacts')
full = json.loads((ROOT / 'live_mirror_actual_fixture.json').read_text())


def enlarge(scale):
    result = copy.deepcopy(full)
    for part in ('windows', 'inventory'):
        source = next(iter(result['book'][part].values()))
        for i in range(scale):
            key = f'KXBTC15M-SYNTHETIC-ARCHIVE-{i:06d}'
            result['book'][part][key] = copy.deepcopy(source)
            if part == 'windows':
                result['book'][part][key]['slug'] = key
    return result


states = {'live_full_fixture': full, 'live_full_512': enlarge(512), 'live_full_4096': enlarge(4096)}

def old(value, stream):
    json.dump(value, stream, allow_nan=False, separators=(',', ':'))


def new(value, stream):
    stream.write(json.dumps(value, allow_nan=False, separators=(',', ':')))


class CountWrites:
    def __init__(self):
        self.calls = 0
        self.stream = io.StringIO()
    def write(self, text):
        self.calls += 1
        return self.stream.write(text)


results = {}
for name, value in states.items():
    counters = []
    for function in (old, new):
        writer = CountWrites()
        function(value, writer)
        counters.append(writer)
    assert counters[0].stream.getvalue() == counters[1].stream.getvalue()
    size = len(counters[0].stream.getvalue())
    results[name] = {'bytes_ascii': size,
                     'sha256': hashlib.sha256(counters[0].stream.getvalue().encode()).hexdigest(),
                     'old_write_calls': counters[0].calls, 'new_write_calls': counters[1].calls}
    for label, function in (('old', old), ('new', new)):
        samples = []
        target = ROOT / f'{name}_{label}_mirror.tmp'
        for _ in range(11):
            wall, cpu = time.perf_counter(), time.process_time()
            with target.open('w', encoding='utf-8') as stream:
                function(value, stream)
            samples.append({'wall_ms': (time.perf_counter()-wall)*1000,
                            'cpu_ms': (time.process_time()-cpu)*1000})
        results[name][label] = {'samples': samples,
                              'wall_median_ms': statistics.median(x['wall_ms'] for x in samples),
                              'cpu_median_ms': statistics.median(x['cpu_ms'] for x in samples)}
        profiler = cProfile.Profile()
        profiler.enable()
        for _ in range(8):
            with target.open('w', encoding='utf-8') as stream:
                function(value, stream)
        profiler.disable()
        profiler.dump_stats(str(ROOT / f'{name}_{label}_mirror.prof'))
        stream = io.StringIO()
        pstats.Stats(profiler, stream=stream).strip_dirs().sort_stats('cumulative').print_stats(20)
        (ROOT / f'{name}_{label}_mirror.txt').write_text(stream.getvalue())
    print(name, 'bytes', size, 'writes', counters[0].calls, '->', counters[1].calls,
          'old_wall', results[name]['old']['wall_median_ms'], 'new_wall', results[name]['new']['wall_median_ms'])


edge_cases = {
    'unicode': {'z': '\\n\u00e9\U0001f680\ud800', 'a': [1, -0.0, 5e-324, 1.7976931348623157e308, True, None]},
    'unsupported': {'bad': object()}, 'nan': {'bad': float('nan')}, 'inf': {'bad': float('inf')},
    'mixed_keys': {'a': 1, 2: True, None: 'none'}, 'tuple': {'tuple': (1, 2)},
}
cycle = []; cycle.append(cycle); edge_cases['cycle'] = cycle
value = []; deep = value
for _ in range(1100):
    new_list = []; deep.append(new_list); deep = new_list
edge_cases['deep'] = value
edge_results = {}
for name, value in edge_cases.items():
    outcomes = []
    for function in (old, new):
        writer = io.StringIO()
        try:
            function(value, writer)
            outcome = ('ok', writer.getvalue())
        except Exception as error:
            outcome = (type(error).__name__, str(error))
        outcomes.append(outcome)
        # Use actual existing mirror workflow. Failed serialization must never
        # reach os.replace; earlier complete display stays intact.
        target = ROOT / f'atomic_failure_{name}.json'
        target.write_text('{"previous":"complete"}')
        temporary = target.with_suffix('.tmp')
        try:
            with temporary.open('w', encoding='utf-8') as stream:
                function(value, stream)
            os.replace(temporary, target)
        except Exception:
            assert target.read_text() == '{"previous":"complete"}'
    if name in ('deep',):
        print('DEEP OUTCOMES', [(item[0], item[1][:100]) for item in outcomes])
    else:
        assert outcomes[0] == outcomes[1], (name, outcomes)
    edge_results[name] = {'outcome_type': outcomes[0][0], 'same_bytes_or_error': outcomes[0] == outcomes[1]}
results['edge_cases'] = edge_results
(ROOT / 'mirror-results.json').write_text(json.dumps(results, indent=2, allow_nan=False))
