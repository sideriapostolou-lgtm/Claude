# Live mirror encoding: focused candidate assessment

Read-only architecture assessment on application `10f7f9d88a9acd51aba041345d569cd9972c4b6c`. No patch reviewed or application edit made here. The 04:15–04:45 UTC production capture and tail through 04:47 remain frozen; no release during it.

## Assessment

Replacing the live display-mirror `json.dump(full, stream, allow_nan=False, separators=(",", ":"))` with `stream.write(json.dumps(full, allow_nan=False, separators=(",", ":")))` inside the **same** temporary-file context is a sound, narrowly scoped candidate, subject to actual-path profiling, memory checks and exact-patch review. It has a stronger source/evidence basis and fewer semantic hazards than a generic KV native-tree fast path.

Practice already uses this single compact write in `speeddesk.py:67–75`, with the stated purpose of avoiding many Python write calls on the shared loop. Live mirror still uses the streaming Python `json.dump` path (`speeddesk_live.py:993–1003`). Keep source formatting options, file-opening position, temporary-path choice, replacement order, last_mirror update, mirror cadence and ledger commit sequence unchanged.

## Matched production evidence

The original timing event logged **2026-10-15T04:13:07.658912823Z** has known rejected-message ordinal **1143**, accepted monotonic **3568691.340348038**, receive monotonic **3568694.071877811**, and measured local residence **2731.5297732129693 ms**. Its bounded `local_work` query runs through apply monotonic **3568694.071941071**. It contains:

| Work | Monotonic start | Monotonic end | Wall ms | Thread CPU ms |
|---|---:|---:|---:|---:|
| live_checkpoint | 3568691.981435875 | 3568692.359329213 | 377.893337980 | 250.797162000 |
| live_ledger, nested | 3568691.997657470 | 3568692.076954054 | 79.296584241 | 43.670900000 |
| live_mirror, nested | 3568692.077023194 | 3568692.357892255 | 280.869060662 | 193.017517000 |

This does establish live-mirror synchronous work within that exact message's local waiting interval. The mirror is a contributor, not the whole 2.7315-second delay, and its time includes building the merged mirror dictionary, `panel()`, encoding, file writes and replacement. Profiling must isolate encoding/write-call overhead before claiming it accounts for the whole 280.9 ms. Parent and nested values must not be added.

Producer caveat: `WeatherWS` inherits the same base logger and session counter. Unidentified timing rows cannot be assumed BTC. This particular incident has a valid `local_work` query from the verified main-runner WorkTrace wiring, anchoring it to that main producer; missing work queries elsewhere do not prove weather. The earlier 53 shared-logger warnings and startup overflow cohorts retain producer ambiguity unless independently identified.

The profile worker reportedly measured a representative 1.77 MB synthetic value at approximately 85.65→15.23 ms and 346744→1 stream writes. Those figures are **reported preliminary offline evidence**, not independently verified by this reviewer yet and not a production improvement estimate. Exact profile artifacts and actual full-checkpoint tests remain required.

## Deep nesting and error contract

The worker found a deep synthetic nested-list input where the old Python `json.dump` raises RecursionError but C-backed `json.dumps` succeeds. This invalidates a universal claim that both paths have identical failure behavior on every Python object. Retain the counterexample and describe the change honestly.

**No new guard/fallback is required solely to reproduce that incidental old encoder recursion failure for out-of-model display data.** A more complex guard has its own cost and compatibility surface. The intended contract is exact output for validated ordinary checkpoint/archive/panel data, preservation of atomic failure boundaries, and unchanged financial authority. Show actual model-generated depth far below the counterexample and retain malformed-input tests. Do not claim universal exception identity or mistake an incidental serializer RecursionError for a designed trading safeguard.

The authoritative ledger is committed before mirror work (`speeddesk_live.py:967–990`). Startup reads ledger `STATE_KEY`; if it is missing beside an existing mirror it raises rather than restoring from that mirror (`481–487`). Therefore a deeper successfully encoded mirror does not supply a new financial recovery source. Keep and test that separation. The public page may read a mirror; JSON readability and normal schema compatibility remain relevant.

Encoding failures can leave different **temporary-file** contents: old chunked dump may leave a partial prefix, new eager dumps may leave an empty truncated temporary file. Both must preserve the prior final target, avoid `os.replace`, and avoid advancing last_mirror. A read-only local probe on Python3.12.14 showed the same ValueError/TypeError categories for NaN, infinity and an unsupported object, with this expected temporary-output difference. No application source changed for the probe.

## Required focused tests

1. Execute both encoders with the exact live checkpoint-generated `full` structure for ordinary state, archived windows/intents, rich panel/history, Unicode keys/values, numeric extremes/signed zero and representative maximum retained history. Compare full serialized bytes, decoded schema and final file contents. Include seeded randomized native JSON trees within the validated shape/depth range.
2. Count write calls and profile **whole live mirror/checkpoint** as well as isolated encoding. Use repeatable identical synthetic state, reversed run order and a real temporary filesystem. Retain wall time, thread CPU, payload size and peak memory. `json.dumps` holds a whole encoded string; quantify peak-memory growth rather than treating the faster encoder as free.
3. NaN/infinity, unsupported objects, cycles and the deep-nesting counterexample: assert correct documented outcome and atomic target preservation where encoding fails. Do not demand identical incidental temporary prefixes. Preserve `allow_nan=False`; no `default=str`, sort order, escaping, loss of floats or skipped fields may be introduced.
4. Inject open, write and replace failures. Verify the previous final mirror remains intact until successful replace, no last_mirror advancement on failure, and no additional checkpoint/retry/network/financial behavior is introduced. Check the already committed ledger and cleared pre-send journal remain valid when mirror output fails, then prove recovery still reads authoritative ledger state.
5. Successful checkpoint/restart equivalence: exact money fields, reservations/uncertain orders, fees/losses, stop/reset/resume history, archive reconstruction and receipt-chain heads match. Mirror replacement never becomes a commit prerequisite or source of restored money.
6. Run existing financial crash, save, stop, ledger and controller tests, full repository checks and independent exact-patch review. After any authorized post-capture release, verify exact deployment and restart accounting, then use repeated complete windows to quantify this **partial** local-work correction. Do not infer that all source-age warnings are resolved from an offline speedup.

The mirror candidate is suitable for narrow implementation work once its profile is verified. It does not justify changing checkpoint frequency, durability, ledger serialization, receiver batch sizes, callback ordering, event retention, stale guards or trading policy.
