import contextlib
import io
import json
from pathlib import Path
import statistics
import time
import tracemalloc
ROOT=Path('/workspace/shared/kv-profile-artifacts')
# Reuse offline artifacts, without re-running constructors or importing network.
namespace={}
source=Path('/workspace/shared/kv-profile-candidate.py').read_text()
exec(source[source.index('def native_finite'):source.index('\ndef candidate')], {'math':__import__('math')}, namespace)
native=namespace['native_finite']
native.__globals__['native_finite']=native
full=json.loads((ROOT/'live_full_4096_new_mirror.tmp').read_text())

def old(value, stream):
    json.dump(value,stream,allow_nan=False,separators=(',',':'))
def new(value, stream):
    stream.write(json.dumps(value,allow_nan=False,separators=(',',':')))
def guarded(value, stream):
    if native(value):
        new(value,stream)
    else:
        old(value,stream)

result={}
for label,method in [('old',old),('new',new),('guarded',guarded)]:
    samples=[]
    for _ in range(11):
        wall,cpu=time.perf_counter(),time.process_time()
        with (ROOT/'extra.tmp').open('w',encoding='utf-8') as stream:
            method(full,stream)
        samples.append({'wall_ms':(time.perf_counter()-wall)*1000,'cpu_ms':(time.process_time()-cpu)*1000})
    tracemalloc.start()
    with (ROOT/'extra.tmp').open('w',encoding='utf-8') as stream:
        method(full,stream)
    current,peak=tracemalloc.get_traced_memory()
    tracemalloc.stop()
    result[label]={'samples':samples,'wall_median_ms':statistics.median(x['wall_ms'] for x in samples),
                   'cpu_median_ms':statistics.median(x['cpu_ms'] for x in samples),'traced_peak_bytes':peak}
    print(label,result[label]['wall_median_ms'],result[label]['cpu_median_ms'],peak)
(ROOT/'mirror-extra-results.json').write_text(json.dumps(result,indent=2))

class Exotic:
    pass
class DictChild(dict):
    pass
cases={'unicode_float': {'z':'é🚀\ud800','a':[1,-0.0,5e-324,1.7976931348623157e308]},
       'nan':{'bad':float('nan')},'inf':[float('inf')], 'mixed_keys':{1:'one','2':'two'},
       'tuple':(1,2),'subclass':DictChild(a=1),'unsupported':Exotic()}
cycle=[];cycle.append(cycle);cases['cycle']=cycle
for depth in (64,100,980,990,1000,1100):
    value=[];cursor=value
    for _ in range(depth):
        child=[];cursor.append(child);cursor=child
    cases[f'depth_{depth}']=value
edge={}
for name,value in cases.items():
    outcomes=[]
    for method in (old,guarded):
        stream=io.StringIO()
        try:
            method(value,stream)
            outcomes.append(('ok',stream.getvalue()))
        except Exception as error:
            outcomes.append((type(error).__name__,str(error)))
    assert outcomes[0]==outcomes[1],(name,[x[0] for x in outcomes])
    edge[name]={'old_guarded_exact_bytes_or_error_equal':True,'outcome':outcomes[0][0]}
result['guarded_edges']=edge
(ROOT/'mirror-extra-results.json').write_text(json.dumps(result,indent=2))
