# WS timing startup: independent early attribution

**Producer-attribution correction:** subsequent source review found `WeatherWS(KalshiMarketWS)` in `weatherwatch_markets.py:359–366`, also using the inherited timing logger and instance-local session counter. Thus the four rows below are valid within-row connection measurements from an **unidentified producer**. They cannot be called BTC/speed-desk backlog, grouped across rows by session number alone, or joined to nearby main-loop work by log time. Presence of a valid main-wired `local_work` query can positively identify the main source under the verified wiring; its absence does not identify weather. The main-only 04:13:07 known-receipt incident was found separately after this startup extraction. Preserve this correction with any reuse of the original report or numeric extraction.

Recorded 2026-10-14 9:15 PM PDT / 2026-10-15 04:15 UTC. Read-only extraction/review; no source edits, production tools, account calls, deployment or financial action. Integration owner `/root` owns the frozen 04:15–04:45 UTC capture and publication tail through 04:47. Preserve that capture unchanged.

## Finding

**The new startup evidence establishes substantial local post-protocol message delay and real accumulated complete-message backlog. It does not establish the local age of any of the four rejected messages or identify the responsible work.** All four rejected-message stamps were evicted by the 256-entry diagnostic ring. The source-age guard correctly remains fail-closed; no behavioral correction is selected from this startup sample.

Original input `/workspace/shared/ws-timing-startup-logs2.json`: SHA256 `1e7cad89235efb6e7a8cb3dc196bd7d6300abba263587d681ad46fdceb58a7e4`, twelve filtered original log rows. Its structured result reports deployment `86dabbf2-bedb-4686-b6ed-857955e0b521`, status SUCCESS. The local HEAD is `10f7f9d88a9acd51aba041345d569cd9972c4b6c`, with unchanged reviewed source hashes:

```text
77989b80dcc8eb452d1fee658b37ecc5bbd1daa77427d6bb104b51c6ef6c1d8b  src/nightcrawler/speeddesk_ws_timing.py
3490a45a97d711797824c6b679f8c9346773cea38922e9d7b43650ae8e63de42  src/nightcrawler/speeddesk_kalshi_ws.py
```

The deployment completion time and pre/post financial comparison were supplied by root; this reviewer did not independently query deployment/account state. This report makes no current-account or profitability claim.

## Exact positive evidence

Times below are original platform log timestamps, rounded for display; the extraction preserves nanosecond strings and the separate application `apply_wall` timestamp. All four events are `orderbook_delta` gaps. “Sending age” is computed from the same saved guard-wall time and raw provider publication stamp; “engine age” uses the saved engine stamp. Those are different source domains, not local receive marks.

| UTC log time | Session / rejected ordinal | Sending age s | Engine age s | Largest known local residence ms, session to date | Prior complete-message yield-resume ms | Already accepted complete messages still unconsumed |
|---|---:|---:|---:|---:|---:|---:|
| 04:11:42.573 | 1 / 1821 | 3.885797 | 3.890797 | 2676.597386 | 1016.982889 | 5263 |
| 04:11:49.933 | 2 / 338 | 3.009699 | 3.014699 | 658.830783 | 22.118215 | 1120 |
| 04:11:57.785 | 3 / 2048 | 3.131698 | 3.137698 | 1199.442929 | 239.304947 | 307 |
| 04:12:08.238 | 4 / 1667 | 4.951196 | 4.956196 | 1842.557982 | 2104.146932 | 1687 |

Session one's known sample proves at least one successfully received message spent **2.676597386 seconds after complete-message protocol acceptance and before native receive return**. Later sessions separately prove known maxima of 0.658831, 1.199443 and 1.842558 seconds. Each is a genuine positive local interval for some known earlier sample in that session. None identifies the rejected ordinal; the current diagnostic stores the numerical maximum without its ordinal/start/end marks. These are lower bounds on full source-to-processing delay, not provider/network estimates and not unbiased latency quantiles.

The prior-yield metric separately proves a ready reader did not resume from its explicit `sleep(0)` for **1.016983 seconds** in session one and **2.104147 seconds** in session four. The timeout-overcount bug was corrected in the deployed reviewed source; idle `recv` timeout loops do not inflate these figures. These intervals may contain other event-loop tasks, operating-system scheduling or process suspension. They do not measure any particular task's CPU. Exact yield start/end marks are not present in the log, only duration and the later receive-call mark.

Already-accepted/unconsumed count is `accepted - received`, using native complete-message accepted and successful complete-message receive counters. With observation enabled and zero errors/unsupported readers, these counts show a real backlog after protocol processing. In session one **7084 - 1821 = 5263** complete messages had already been accepted but not returned to the consumer when the gap report was made. This is stronger evidence than a hypothetical buffered-burst experiment. It does not reveal the ages or eventual contents/outcomes of those messages; the failed connection is invalidated and reset as before.

All four observed counter cohorts reconcile:

| Session | Accepted | Received | Known received | Unknown received | Retained diagnostic stamps | Evicted diagnostic stamps |
|---|---:|---:|---:|---:|---:|---:|
| 1 | 7084 | 1821 | 560 | 1261 | 256 | 6268 |
| 2 | 1458 | 338 | 211 | 127 | 256 | 991 |
| 3 | 2355 | 2048 | 426 | 1622 | 256 | 1673 |
| 4 | 3354 | 1667 | 650 | 1017 | 256 | 2448 |

For each, `received = known + unknown`, and `accepted = known + retained + overflow`. Eviction is lost **diagnostic metadata**, not evidence that market messages were dropped by the observer. Unknown-consumed and evicted populations overlap: never add them as different lost messages. Session one, for example, has 5007 unconsumed accepted messages without retained metadata (`5263 - 256`), plus 1261 already-consumed unknowns, totaling its 6268 evictions.

The configured native high-water value 16 is flow control, not a hard maximum messages-per-callback or messages-in-buffer guarantee. Native parsing may accept many frames from one already-delivered input chunk before pause-reading takes effect. The production counters now directly disprove treating 16 as a metadata capacity bound. They do not by themselves prove all 7084 arrived in one callback; callback/chunk boundaries are not recorded.

## What remains unattributed

All rejected receipt rows say `status=overflow`, with accepted wall/monotonic and residence fields null. Accordingly no `local_work` query appears on any of these four incident rows. Their exact local post-protocol residence is unavailable. The very short failed-message return→apply times (0.181088, 0.027521, 0.041890, 0.049860 ms) show JSON decode/dispatch after recv return was small on those four messages; they say nothing about time before return. Do not subtract the known maximum, prior-yield duration or arbitrary work maxima from the rejected source age: those values concern different or potentially overlapping intervals/messages.

Provider sending-minus-engine differences are only 5, 5, 6 and 5 ms for these raw fields. This describes the provider's two timestamps. It does not show that network delivery was quick, that the provider clocks are accurate, or that the rejected message spent the rest of its age in the local library. Kernel/TLS/event-loop-before-acceptance delay remains unmeasured even when a receipt is known.

The single startup live status payload at application wall **04:11:40.208440 UTC** predates the first incident. It reports four observed practice checkpoints, maximum wall **428.991757 ms**; practice-ledger maximum **331.688802 ms**; practice-step maximum **459.618789 ms**; live-panel maximum **39.801273 ms**. Live-checkpoint count is zero at that snapshot. These are session aggregates, not work matched to any gap. They are nested/overlapping and must not be summed.

Crucially, `_heartbeat()` builds/logs status before executing its status-triggered checkpoint (`speeddesk_live.py:2439–2453`). The zero live-checkpoint count does **not** exclude a costly first live checkpoint immediately after that snapshot and before the 04:11:42 gap. Obtain later original work spans or a measured interval before assigning responsibility. The status's event-loop lag max 1589.5 ms is another sampling surface, not the exact later yield interval. Coinbase's reported offset −722.8 ms with a 1599.6 ms round trip is not precise Kalshi clock evidence and cannot correct Kalshi source ages.

This is startup/reconnect evidence covering approximately 04:11:37–04:12:11 UTC, not the prospective two complete windows. There are no final whole-session summaries for every close. The five displayed session numbers are instance-local and cannot establish five unique connection cohorts across multiple inherited producers. Do not claim full-feed coverage, a before/after causal estimate, or an all-message latency bound. Reconnect/fallback workload may amplify an initial delay; these rows cannot establish that it initiated the problem.

## Next evidence and narrow follow-up options

1. Keep the frozen 04:15–04:45 capture and 04:47 publication tail unchanged. Independently parse actual incident/status/read-trace originals, preserve observer overflow/error coverage and distinguish startup from full windows. Look for any rejected receipt with a known acceptance stamp and its exact `local_work` interval. Join later retained work details only where actual monotonic intervals match; do not infer containment from neighboring logger times.
   Future diagnostic records need an explicit fixed producer label, process/deployment-scoped instance identity and per-instance connection epoch. Do not retrospectively infer producer from session counters, timing magnitude, missing `local_work`, or neighboring messages. The current mixed capture stays mixed where identity cannot be proved.
2. Retain the exact **maximum-known receipt sample** alongside its numerical maximum: one bounded object holding ordinal and paired acceptance/receive clocks. This is a small observability correction, not a scheduling change. It would let an overflowed rejected incident query WorkTrace for a real measured slow interval already known to exist. Because work bins retain 16 seconds and slow details can evict, query/report freshness and retention loss still matter. This candidate needs implementation/review after the current capture, not a claim of complete cause today.
3. Separately repair the known metadata coverage problem if exact rejected residence is still missing. An 8192-entry fixed ring would retain all messages in the largest observed 5263-message outstanding cohort at that moment, with headroom; this sample does not establish 8192 as a future maximum. Measure memory and CPU overhead and preserve explicit overflow. A larger **diagnostic metadata** cap is distinct from an arbitrary feed batch cap and must not alter how financial messages are processed.
4. Range compression is viable only with honest timestamp semantics. Grouping ordinals and assigning them an invented common per-frame acceptance time is wrong. A measured common callback-end timestamp, later than all corresponding native acceptance events but before the reader can resume, can supply a conservative local lower bound for the range; label it as callback-end, not exact per-frame acceptance. Alternatively preserve explicit acceptance bounds. Callback boundaries, fragmentation and the exact base-call order must be verified. Do not introduce private-queue inspection or payload retention simply to compress metadata.
5. Once a slow local interval and responsible synchronous work are actually matched, exercise that path with actual runner/controller state and a representative pinned synthetic history/activity set. Preserve every tick/trade/book/fill, journal-before-send, mandatory financial checkpoint, stale invalidation, cancellation, stop and uncertain-order behavior. If repeated nonessential calculation is proven responsible, optimize that exact operation. The current source-age evidence does not choose batching, event coalescing, a checkpoint delay, or a controller cadence change.

## Focused tests before any follow-up

- Reproduce metadata pressure with native chunks above 16, 256, 8192 and beyond the chosen cap; interleave receives and new arrivals. Verify exact ordinal correspondence, `known+unknown=received`, accepted cohort conservation, explicit loss and bounded memory, with identical application outputs to the unobserved reader.
- Max-sample retention: an earlier known slow message followed by an overflowed rejected message still reports the original ordinal and exact interval. Never substitute that interval for the rejected message. Equal maxima, resets, backwards clocks and diagnostic failure leave truthful state and unchanged native behavior.
- Compression, if chosen: several complete messages per callback; one message spanning callbacks; control frames between fragments; a final fragment followed by more complete messages; cancellation after partial assembly; separate callbacks with no complete messages; overflow and unsupported readers. Verify the range lower bound is no greater than actual per-message residence and never crosses connection epochs.
- Join WorkTrace using stored exact known start/end marks; verify retained/omitted/quiet/nested scopes and lost 16-second bins stay explicit. A wholly contained synthetic synchronous blocker should be attributed once; an overlapping async wait or nested work must not become extra CPU.
- Benchmark observer memory and per-message CPU on the supported native runtime with representative high-volume replay. Distinguish measurement overhead from business work. Repeat full fairness, source guard, atomic callback, cancellation/invalidation, persistence and financial safety checks for the final reviewed patch.

Derived exact numeric extraction: `/workspace/shared/ws-timing-startup-independent-extraction.json`, SHA256 `07bef6fdb2d61e5b4cefefc29d60eeeb3a69327cdbe9a7294be1cf2e43681de3`. No application tests were rerun for this read-only log interpretation. EXEC-DELAY-001 and the original/inverse/no-trade comparison retain their existing open/unstarted states.
