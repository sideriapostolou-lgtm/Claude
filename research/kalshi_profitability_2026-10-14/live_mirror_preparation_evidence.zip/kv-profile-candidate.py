"""Offline-only exact-native finite validator + untouched actual-dumps fallback."""
import dataclasses
import enum
import hashlib
import json
import math
from pathlib import Path
import random
import statistics
import time
from nightcrawler.ledger import Ledger, _dumps
from nightcrawler.hashing import canonical_json, normalize_payload
ROOT = Path('/workspace/shared/kv-profile-artifacts')


def native_finite(value, depth=0):
    kind = type(value)
    if value is None or kind is str or kind is int or kind is bool:
        return True
    if kind is float:
        return math.isfinite(value)
    # Bounded validation handles cyclic/deep values by falling back to the
    # original conversion/encoder. No payload cache; no subtype callbacks.
    if depth >= 64:
        return False
    if kind is list:
        for item in value:
            if not native_finite(item, depth + 1):
                return False
        return True
    if kind is dict:
        for key, item in value.items():
            if type(key) is not str or not native_finite(item, depth + 1):
                return False
        return True
    return False


def candidate(value):
    if native_finite(value):
        # Exactly current KV options, no sort_keys or receipt semantics added.
        return json.dumps(value, separators=(',', ':'), default=str)
    return _dumps(value)


@dataclasses.dataclass
class Dataclass:
    value: object


class IntChild(int): pass
class StrChild(str): pass
class FloatChild(float): pass
class DictChild(dict): pass
class ListChild(list): pass
class Color(enum.Enum):
    RED = 'red'
class Exotic:
    def __str__(self):
        return 'exotic-fixed-repr'
class BadRepr:
    def __str__(self):
        raise RuntimeError('exact-fallback-error')


cases = {'native': {'z': [None, True, 1, -0.0, 5e-324, 1.7976931348623157e308], 'a': 'é🚀\ud800'},
         'mixed_keys': {1: 'number', '1': 'string', None: False},
         'tuple': (1, 2), 'dict_subclass': DictChild(x=1), 'list_subclass': ListChild([1]),
         'int_subclass': IntChild(3), 'str_subclass': StrChild('key'), 'float_subclass': FloatChild(1.5),
         'key_subclass': {StrChild('x'): 3}, 'dataclass': Dataclass((Color.RED, Path('fixed'))),
         'set': {3, 1}, 'frozenset': frozenset({3, 1}), 'enum': Color.RED,
         'nan': {'bad': float('nan')}, 'inf': [float('inf')], 'exotic': Exotic(), 'bad_repr': BadRepr(),
         'huge_int': 10**5000}
cycle=[]; cycle.append(cycle); cases['cycle']=cycle
cycle_dict={}; cycle_dict['self']=cycle_dict; cases['cycle_dict']=cycle_dict
shared=[1, 2]; cases['shared']=[shared, shared]
value=[]; deep=value
for _ in range(1100):
    item=[]; deep.append(item); deep=item
cases['deep']=value


def outcome(function, value):
    try:
        return ('ok', function(value))
    except Exception as error:
        return (type(error).__name__, str(error))


edge_results={}
for name, value in cases.items():
    before, after = outcome(_dumps, value), outcome(candidate, value)
    assert before == after, (name, before[0], after[0])
    edge_results[name]={'native_fast_path': native_finite(value), 'outcome': before[0], 'equal_bytes_or_error': True}

# Deterministic randomized native scalar/container values including special text.
rng=random.Random(20261015)
def generated(depth=0):
    scalar=[None, False, True, -0.0, rng.randrange(-10**20, 10**20), rng.random()*1e90, 'é🚀\\n\ud800']
    if depth>=5 or rng.random()<0.6:
        return rng.choice(scalar)
    if rng.random()<0.5:
        return [generated(depth+1) for _ in range(rng.randrange(5))]
    return {f'key-{i}': generated(depth+1) for i in range(rng.randrange(5))}
for _ in range(1000):
    value=generated(); assert candidate(value)==_dumps(value)

results={'edge_cases': edge_results, 'deterministic_native_cases_equal': 1000,
         'limits': 'offline synthetic; no concurrency proof; no source changes; receipts unchanged'}
for name in ('practice_fixture','live_fixture','practice_512','live_512','practice_4096','live_4096'):
    value=json.loads((ROOT/f'{name}.json').read_text())
    assert candidate(value)==_dumps(value)
    result={'bytes_ascii':len(_dumps(value))}
    for label, function in [('old',_dumps),('new',candidate),('validator',native_finite)]:
        samples=[]
        for _ in range(15):
            wall,cpu=time.perf_counter(),time.process_time()
            function(value)
            samples.append({'wall_ms':(time.perf_counter()-wall)*1000,
                            'cpu_ms':(time.process_time()-cpu)*1000})
        result[label]={'samples':samples, 'wall_median_ms':statistics.median(x['wall_ms'] for x in samples),
                       'cpu_median_ms':statistics.median(x['cpu_ms'] for x in samples)}
    results[name]=result
    print(name,'old_wall',result['old']['wall_median_ms'],'new_wall',result['new']['wall_median_ms'],
          'validate_wall',result['validator']['wall_median_ms'])
(ROOT/'candidate-results.json').write_text(json.dumps(results,indent=2,allow_nan=False))
