"""Offline existence proof: native buffered feed plus a synthetic wake-driven worker."""
from __future__ import annotations

import ast
import asyncio
import copy
import hashlib
import inspect
import json
from pathlib import Path
import platform
import signal
import socket
import sys
import textwrap
import threading
import time

ROOT = Path('/workspace/nightcrawler-next-evidence')
sys.path.insert(0, str(ROOT / 'src'))
import websockets
from websockets.asyncio.connection import Connection
from websockets.frames import Frame, OP_TEXT
from websockets.protocol import Protocol, Side
from nightcrawler import speeddesk_kalshi_ws as module
from nightcrawler.config import Settings
from nightcrawler.speeddesk_kalshi_ws import KalshiMarketWS, MarketState, MarketDataGap

OUT = Path('/workspace/shared/fairness-work-amplification-proof.json')
T = 1792019700.0
TICKER = 'KXBTC15M-FAKE-WAKE-PROOF'
TOTAL = 500
BOOK_WORK_S = .005
CONTROLLER_WORK_S = .012

def sha(data):
    return hashlib.sha256(data).hexdigest()

def denied(*args, **kwargs):
    raise AssertionError('Offline only: socket/thread/client activity prohibited')

def work(seconds):
    until = time.perf_counter() + seconds
    while time.perf_counter() < until:
        pass

candidate_source = textwrap.dedent(inspect.getsource(KalshiMarketWS._session))
candidate_tree = ast.parse(candidate_source)
baseline_tree = copy.deepcopy(candidate_tree)
loop_node = baseline_tree.body[0].body[-1]
assert isinstance(loop_node, ast.While)
removed = loop_node.body.pop()
assert ast.unparse(removed) == 'await asyncio.sleep(0)'
roundtrip = copy.deepcopy(baseline_tree)
roundtrip.body[0].body[-1].body.append(removed)
assert ast.dump(roundtrip, include_attributes=False) == ast.dump(candidate_tree, include_attributes=False)
namespace = {}
exec(compile(ast.fix_missing_locations(baseline_tree), '<offline-without-boundary-yield>', 'exec'), vars(module), namespace)
baseline = namespace['_session']

payloads = [{'type': 'orderbook_delta', 'sid': 7, 'seq': i + 2,
             'sending_ts_ms': int(T * 1000),
             'msg': {'market_ticker': TICKER, 'side': 'yes', 'price_dollars': '.4',
                     'delta_fp': '.01', 'ts_ms': int(T * 1000)}} for i in range(TOTAL)]
chunk = b''.join(Frame(OP_TEXT, json.dumps(row, separators=(',', ':')).encode()).serialize(mask=False)
                 for row in payloads)

class Transport:
    def __init__(self):
        self.pauses = self.resumes = 0
    def pause_reading(self):
        self.pauses += 1
    def resume_reading(self):
        self.resumes += 1
    def set_write_buffer_limits(self, *args):
        pass
    def write(self, data):
        denied()

async def scenario(candidate, controller_work):
    original_socket, original_start = socket.socket, threading.Thread.start
    socket.socket, threading.Thread.start = denied, denied
    try:
        transport = Transport()
        connection = Connection(Protocol(Side.CLIENT, max_size=1_000_000),
                                max_queue=16, ping_interval=None)
        connection.connection_made(transport)
        connection.data_received(chunk)
        assert len(connection.recv_messages.frames) == TOTAL
        sent, received_ages, callback_sequences, controller_turns = [], [], [], []
        wake = asyncio.Event()
        ready = asyncio.get_running_loop().create_future()
        stop = threading.Event()
        start_wall = time.perf_counter()
        start_cpu = time.process_time()
        callbacks = 0
        wake_sets = 0

        def logical_clock():
            return T + time.perf_counter() - start_wall

        class Adapter:
            async def send(self, message):
                sent.append(json.loads(message))
            async def recv(self):
                message = await connection.recv()
                received_ages.append(logical_clock() - T)
                return message

        async def controller():
            while True:
                await wake.wait()
                wake.clear()
                before = time.perf_counter()
                work(controller_work)
                controller_turns.append({'callbacks': callbacks, 'messages_received': len(received_ages),
                                         'elapsed_ms': (time.perf_counter() - before) * 1000})

        account_observation = []
        async def account():
            await ready
            account_observation.append({'callbacks': callbacks, 'messages_received': len(received_ages),
                                        'logical_age_s': logical_clock() - T})

        controller_task = asyncio.create_task(controller())
        account_task = asyncio.create_task(account())
        await asyncio.sleep(0)

        def on_book(book):
            nonlocal callbacks, wake_sets
            callbacks += 1
            callback_sequences.append((book.sequence, book.side))
            wake.set()
            wake_sets += 1
            if callbacks == 1:
                ready.set_result(None)
            if callbacks % 2 == 0:
                work(BOOK_WORK_S)
            if callbacks == TOTAL * 2:
                stop.set()

        feed = KalshiMarketWS(Settings(kalshi_key_id=None, kalshi_private_key=None,
                              speeddesk_kalshi_mode='paper', speeddesk_kalshi_live_confirm=None),
                             tickers=lambda: frozenset({TICKER}), on_book=on_book,
                             on_trade=denied, on_status=lambda row: None, clock=logical_clock,
                             ws_connect=denied)
        feed.connected = True
        feed.state = MarketState(frozenset({TICKER}))
        feed.state.apply({'type': 'subscribed', 'id': 1,
                          'msg': {'sid': 7, 'channel': 'orderbook_delta'}}, T)
        feed.state.apply({'type': 'orderbook_snapshot', 'sid': 7, 'seq': 1,
                          'msg': {'market_ticker': TICKER,
                                  'yes_dollars_fp': [['.4', '2.5']],
                                  'no_dollars_fp': [['.6', '2.5']]}}, T)
        method = KalshiMarketWS._session if candidate else baseline
        failure = None
        try:
            await method(feed, Adapter(), frozenset({TICKER}), stop)
        except MarketDataGap as exc:
            failure = str(exc)
        session_end = time.perf_counter()
        session_cpu = time.process_time() - start_cpu
        turns_before_session_end = len(controller_turns)
        await account_task
        controller_task.cancel()
        await asyncio.gather(controller_task, return_exceptions=True)
        assert callbacks % 2 == 0
        assert all(callback_sequences[i][0] == callback_sequences[i+1][0]
                   and callback_sequences[i][1] == 'up' and callback_sequences[i+1][1] == 'down'
                   for i in range(0, len(callback_sequences), 2))
        return {'condition': ('candidate' if candidate else 'baseline') + ('_with_work' if controller_work else '_zero_work_control'),
                'boundary_yield': candidate, 'controller_work_s_per_turn': controller_work,
                'received_messages': len(received_ages), 'completed_messages': callbacks // 2,
                'callbacks': callbacks, 'wake_set_calls': wake_sets,
                'controller_turns_before_session_end': turns_before_session_end,
                'controller_turns_after_account_observed': len(controller_turns),
                'controller_work_wall_ms': sum(row['elapsed_ms'] for row in controller_turns),
                'controller_turns': controller_turns,
                'account_observation': account_observation, 'failure': failure,
                'session_wall_s': session_end-start_wall, 'session_process_cpu_s': session_cpu,
                'received_message_ages_s': received_ages,
                'remaining_buffered_frames': len(connection.recv_messages.frames),
                'transport_pauses': transport.pauses, 'transport_resumes': transport.resumes,
                'sent_subscriptions': sent, 'callback_sequence_sha256': sha(json.dumps(callback_sequences).encode()),
                'final_yes_quantity': feed.state.depth[TICKER]['yes'][.4]}
    finally:
        socket.socket, threading.Thread.start = original_socket, original_start

def main():
    signal.alarm(25)
    started = time.perf_counter()
    source_paths = [ROOT/'src/nightcrawler/speeddesk_kalshi_ws.py', ROOT/'src/nightcrawler/speeddesk_feeds.py']
    before = {str(p): sha(p.read_bytes()) for p in source_paths}
    results = []
    for controller_work in (CONTROLLER_WORK_S, 0):
        for candidate in (False, True):
            row = asyncio.run(scenario(candidate, controller_work))
            results.append(row)
            print(json.dumps({k: row[k] for k in ('condition','received_messages','completed_messages','controller_turns_before_session_end','failure','session_wall_s','account_observation')}), flush=True)
    after = {str(p): sha(p.read_bytes()) for p in source_paths}
    loaded, yielded, control_baseline, control_candidate = results
    interpretation = {
        'source_unchanged': before == after,
        'loaded_baseline_completes_burst': loaded['completed_messages'] == TOTAL and loaded['failure'] is None,
        'loaded_candidate_rejects_stale_network_timestamp': bool(yielded['failure'] and 'orderbook_delta_network' in yielded['failure']),
        'candidate_runs_more_controller_turns': yielded['controller_turns_before_session_end'] > loaded['controller_turns_before_session_end'],
        'both_zero_work_controls_complete': all(r['completed_messages'] == TOTAL and r['failure'] is None for r in (control_baseline,control_candidate)),
        'candidate_account_observes_first_complete_message': all(r['account_observation'][0]['callbacks'] == 2 for r in (yielded,control_candidate)),
        'not_production_causality': True,
    }
    out = {'script_sha256': sha(Path(__file__).read_bytes()), 'python': sys.version,
           'platform': platform.platform(), 'websockets': websockets.__version__,
           'sources_before': before, 'sources_after': after,
           'candidate_session_source_sha256': sha(candidate_source.encode()),
           'baseline_ast_source_sha256': sha(ast.unparse(baseline_tree).encode()),
           'ast_difference': 'Exactly one removed complete-message await asyncio.sleep(0); freshness and parser unchanged',
           'parameters': {'frames': TOTAL,'arrival': 'identical complete frames prebuffered in one native data_received call',
                          'native_chunk_bytes': len(chunk),'chunk_sha256': sha(chunk),'max_queue_high_water':16,
                          'book_work_s_per_complete_message': BOOK_WORK_S,'controller_work_s_per_wakeup':CONTROLLER_WORK_S,
                          'source_timestamp':T,'clock': 'fixed epoch plus actual monotonic elapsed; real3second freshness unchanged',
                          'maximum_runtime_alarm_s':25},
           'results':results,'observations':interpretation,'total_wall_s':time.perf_counter()-started,
           'limitations':['Fixed synthetic burst, not production arrival trace or throughput estimate.',
                          'Controller is explicitly a synchronous Event.wait/clear workload surrogate, not KalshiLiveDesk execution.',
                          'No claim that per-message callback or controller cost matches production.',
                          'CPU work durations are experiment inputs, not correctness performance thresholds.',
                          'No sockets, network, threads, handshake keys, account clients, orders, repository changes or production queries.',
                          'Native _session tested directly; this experiment does not run reconnect/fallback handling.',
                          'Preload uses native parser/assembler internals solely in offline proof; no installed SDK or production library patch.',
                          'This establishes scheduling/work-amplification possibility only; frozen production gate unchanged.']}
    OUT.write_text(json.dumps(out,indent=2)+'\n')
    signal.alarm(0)
    print(json.dumps({'result_path':str(OUT),'sha256':sha(OUT.read_bytes()),'observations':interpretation,'total_wall_s':out['total_wall_s']}),flush=True)

if __name__ == '__main__':
    main()
