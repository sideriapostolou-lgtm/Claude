"""Completed numeric observations follow all existing checkpoint barriers."""
from __future__ import annotations

import json
import threading
from copy import deepcopy
from pathlib import Path
from typing import Any

import pytest
from fakes import FakeClock
from test_speeddesk_runtime import LocalFeeds

from nightcrawler.config import Settings
from nightcrawler.ledger_timing import FIELDS, publish
from nightcrawler.speeddesk import STATE_KEY as PRACTICE_STATE
from nightcrawler.speeddesk import SpeedRunner
from nightcrawler.speeddesk_live import STATE_KEY, KalshiLiveDesk, LiveSnapshot
from nightcrawler.speeddesk_worktrace import WorkTrace


def numeric(start: float, end: float, completed: float) -> dict[str, int | float]:
    result: dict[str, int | float] = {key: 0 for key in FIELDS}
    result.update(enabled=1, context_start_mono=start, context_end_mono=end, checkpoint_completed_mono=completed)
    return result


def test_worktrace_latest_two_slots_are_copies_and_only_join_intersecting_ledger_intervals() -> None:
    trace = WorkTrace(monotonic=lambda: 20.)
    a, b = numeric(2, 4, 6), numeric(10, 12, 14)
    trace.record_ledger_timing("practice", a)
    trace.record_ledger_timing("live", b)
    a["sql_count"] = 100
    selected = trace.overlap(3, 5)
    assert set(selected["ledger_observations"]) == {"practice"}
    assert selected["ledger_observations"]["practice"]["sql_count"] == 0
    selected["ledger_observations"]["practice"]["sql_count"] = 200
    assert trace.overlap(3, 5)["ledger_observations"]["practice"]["sql_count"] == 0
    assert not trace.overlap(4, 6)["ledger_observations"]  # Completion time isn't the measured interval.
    trace.record_ledger_timing("practice", numeric(15, 16, 18))
    assert len(trace._ledger_timings) == 2
    assert not trace.overlap(3, 5)["ledger_observations"]
    latest = trace.overlap(15, 16)["ledger_observations"]["practice"]
    assert latest["generation"] == 2 and latest["published_mono"] == 20
    assert "older observations may be overwritten" in selected["ledger_observation_scope"]
    assert selected["covered_wall_ms"] == 0  # Publishing creates no WorkTrace occupancy.


@pytest.mark.parametrize("bad", ["field", "string", "nan", "backwards", "role"])
def test_worktrace_rejects_non_numeric_or_unallowlisted_payload_without_disabling_worktrace(bad: str) -> None:
    trace = WorkTrace(monotonic=lambda: 20.)
    value = numeric(2, 4, 6)
    if bad == "field":
        value["secret-token"] = 1
    elif bad == "string":
        value["sql_count"] = "secret-value"
    elif bad == "nan":
        value["sql_count"] = float("nan")
    elif bad == "backwards":
        value["context_end_mono"] = 1
    trace.record_ledger_timing("invalid-role" if bad == "role" else "practice", value)
    assert not trace._ledger_timings
    assert trace.enabled
    assert trace.overlap(1, 10)["ledger_observation_errors"] == 1


def test_live_observation_publishes_after_receipts_commit_journal_clear_and_mirror(
    tmp_path: Path, monkeypatch: Any,
) -> None:
    clock = FakeClock()
    desk = KalshiLiveDesk(Settings(data_dir=tmp_path), tmp_path / "live", LiveSnapshot, clock=clock.now)
    try:
        previous = desk.save_stages["ledger_timing"]
        desk._record("synthetic_checkpoint", value=1)
        desk.journal_on_disk = True
        desk.stopping = True  # Existing shutdown mirror branch; no financial authority.
        original = desk.work_trace.record_ledger_timing
        records: list[dict[str, int | float]] = []
        def record(role: str, value: dict[str, int | float]) -> None:
            assert role == "live" and desk.ledger._depth == 0
            assert not desk.pending and not desk.journal_on_disk and not desk.journal
            assert desk.last_mirror == clock.now()
            assert next(row for row in desk.ledger.receipts() if row.kind == "synthetic_checkpoint").payload["value"] == 1
            assert desk.ledger.get_kv(STATE_KEY)["updated_at"] == clock.now()
            assert desk.path.exists()
            records.append(deepcopy(value))
            original(role, value)
        monkeypatch.setattr(desk.work_trace, "record_ledger_timing", record)
        desk.checkpoint(durable=True)
        value = desk.save_stages["ledger_timing"]
        assert records == [value] and value is not previous
        assert value["begin_count"] == value["commit_count"] == 1
        assert value["sql_count"] >= 4  # receipt SELECT/INSERT, state and journal UPDATE.
        assert value["to_jsonable_count"] == value["json_encode_count"] == 2
        assert value["context_start_mono"] <= value["context_end_mono"] <= value["checkpoint_completed_mono"]
        assert desk.ledger.verify_chain() == (True, None)
    finally:
        desk.close()


def test_practice_publishes_previous_successful_checkpoint_with_one_save_lag(tmp_path: Path) -> None:
    runner = SpeedRunner(Settings(data_dir=tmp_path), threading.Event(), clock=FakeClock(), feed_factory=LocalFeeds)
    try:
        runner.checkpoint(runner.clock.now())
        previous = dict(runner.checkpoint_ledger_timing)
        runner.record("synthetic_checkpoint", {"at": runner.clock.now(), "value": 2})
        runner.checkpoint(runner.clock.now())
        persisted = runner.ledger.get_kv(PRACTICE_STATE)
        displayed = persisted["panel"]["checkpoint_ledger_timing"]
        assert displayed == {"previous_successful_checkpoint": 1, "one_save_lag": 1, **previous}
        assert runner.checkpoint_ledger_timing != previous
        assert runner.ledger.verify_chain() == (True, None)
        assert not runner.pending
        joined = runner.work_trace.overlap(previous["context_start_mono"], previous["context_end_mono"])
        # The next completed practice save replaces the sole retained slot.
        assert "practice" not in joined["ledger_observations"]
    finally:
        runner.close()


@pytest.mark.parametrize("failure", ["mirror", "publication", "snapshot"])
def test_checkpoint_observer_failure_never_changes_mirror_or_commit_behavior(
    tmp_path: Path, monkeypatch: Any, failure: str,
) -> None:
    import nightcrawler.speeddesk_live as live_module
    clock = FakeClock()
    desk = KalshiLiveDesk(Settings(data_dir=tmp_path), tmp_path / "live", LiveSnapshot, clock=clock.now)
    try:
        previous = deepcopy(desk.work_trace._ledger_timings)
        last_save = deepcopy(desk.save_stages)
        before = desk.path.read_bytes()
        clock.sleep(11)
        desk._record("synthetic_checkpoint", value=3)
        if failure == "mirror":
            def fail(*args: Any) -> None:
                raise OSError("mirror replacement failure")
            monkeypatch.setattr(live_module.os, "replace", fail)
            with pytest.raises(OSError):
                desk.checkpoint()
            assert desk.work_trace._ledger_timings == previous
            assert desk.save_stages == last_save
            assert desk.path.read_bytes() == before
        else:
            def diagnostic_fault(*args: Any) -> None:
                raise RuntimeError("diagnostic failure")
            if failure == "publication":
                monkeypatch.setattr(desk.work_trace, "record_ledger_timing", diagnostic_fault)
            else:
                from nightcrawler.ledger_timing import LedgerObservation
                monkeypatch.setattr(LedgerObservation, "snapshot", diagnostic_fault)
            desk.checkpoint()
            assert json.loads(desk.path.read_text())["updated_at"] == clock.now()
        assert next(row for row in desk.ledger.receipts() if row.kind == "synthetic_checkpoint").payload["value"] == 3
        assert desk.ledger.verify_chain() == (True, None)
    finally:
        desk.close()


def test_publication_feature_failure_is_optional() -> None:
    publish(object(), "practice", numeric(1, 2, 3))
    class Fake:
        def record_ledger_timing(self, *args: Any) -> None:
            raise KeyboardInterrupt("observer publication failure")
    publish(Fake(), "practice", numeric(1, 2, 3))


def test_heartbeat_save_snapshot_cannot_mutate_retained_or_published_timing(tmp_path: Path, monkeypatch: Any) -> None:
    clock = FakeClock()
    desk = KalshiLiveDesk(Settings(data_dir=tmp_path), tmp_path / "live", LiveSnapshot, clock=clock.now)
    try:
        old_snapshot = desk.save_stages["ledger_timing"]
        expected = dict(old_snapshot)
        captured: list[dict[str, Any]] = []
        original_record = desk._record
        def record(kind: str, **kwargs: Any) -> None:
            if kind == "speeddesk_live_status":
                captured.append(kwargs["save"])
            original_record(kind, **kwargs)
        monkeypatch.setattr(desk, "_record", record)
        desk.last_status = float("-inf")
        desk._heartbeat()
        assert len(captured) == 1
        assert captured[0]["ledger_timing"] == expected
        assert captured[0]["ledger_timing"] is not old_snapshot
        captured[0]["ledger_timing"]["sql_count"] = 999
        assert old_snapshot == expected
        assert desk.save_stages["ledger_timing"]["sql_count"] != 999
        latest = desk.work_trace._ledger_timings["live"]
        assert latest["sql_count"] != 999
    finally:
        desk.close()


def test_empty_ledger_interval_never_claims_overlap() -> None:
    trace = WorkTrace(monotonic=lambda: 20.)
    trace.record_ledger_timing("practice", numeric(2, 2, 3))
    assert not trace.overlap(1, 4)["ledger_observations"]


def test_older_publication_cannot_replace_newer_completed_observation() -> None:
    trace = WorkTrace(monotonic=lambda: 20.)
    trace.record_ledger_timing("practice", numeric(10, 12, 14))
    trace.record_ledger_timing("practice", numeric(1, 2, 3))
    assert trace._ledger_timings["practice"]["checkpoint_completed_mono"] == 14
    assert trace._ledger_timings["practice"]["generation"] == 1
    assert trace._ledger_timing_errors == 1


@pytest.mark.parametrize("where", ["items", "lookup"])
@pytest.mark.parametrize("error", [RuntimeError("slot fault"), KeyboardInterrupt("slot fault")])
def test_ledger_slot_fault_preserves_original_span_and_bin_evidence(where: str, error: BaseException) -> None:
    from unittest.mock import Mock
    clock = Mock(side_effect=[1., 2.])
    trace = WorkTrace(monotonic=clock, thread_cpu=lambda: 0.)
    with trace.span("live_ledger"):
        pass
    expected = trace.overlap(1., 2.)
    assert expected["spans"]
    assert expected["all_sync_work_lower_bound"]["covered_wall_lower_bound_ms"] > 0
    class Broken(dict):
        def items(self) -> Any:
            if where == "items":
                raise error
            return super().items()
        def __getitem__(self, key: Any) -> Any:
            raise error
    trace._ledger_timings = Broken() if where == "items" else {"live": Broken()}
    actual = trace.overlap(1., 2.)
    assert actual["ledger_observations"] == {}
    assert actual["ledger_observation_errors"] == 1
    assert actual["spans"] == expected["spans"]
    assert actual["all_sync_work_lower_bound"] == expected["all_sync_work_lower_bound"]
    assert actual["covered_wall_ms"] == expected["covered_wall_ms"]
    assert actual["enabled"] and trace.enabled
