"""Diagnostic-only ledger stages preserve persistence order and failure identity."""
from __future__ import annotations

import contextlib
import json
import sqlite3
import threading
from collections.abc import Iterator
from typing import Any, Self

import pytest

import nightcrawler.ledger as module
import nightcrawler.ledger_timing as timing
from nightcrawler.ledger import Ledger, LedgerError
from nightcrawler.ledger_timing import (
    LedgerObservation,
    checkpoint_observation,
    snapshot,
)


class OriginalLedger(Ledger):
    """Relevant pre-observer plumbing, pinned to a165f34; no Git needed."""
    @contextlib.contextmanager
    def _locked(self) -> Iterator[Any]:
        with self._lock:
            if self._conn is None:
                raise LedgerError("ledger is closed")
            try:
                yield self._conn
            except sqlite3.Error as exc:
                raise LedgerError(f"sqlite error: {exc}") from exc

    def _write(self, sql: str, params: Any = ()) -> None:
        with self.transaction(), self._locked() as conn:
            conn.execute(sql, params)

    def set_kv(self, key: str, value: Any) -> None:
        self._write("INSERT INTO kv(key, value, updated_at) VALUES (?, ?, ?) "
                    "ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
                    (key, module._dumps(value), self._now()))

    def set_synchronous(self, full: bool) -> None:
        with self._lock:
            if self._depth:
                raise LedgerError("cannot change durability inside a transaction")
            with self._locked() as conn:
                conn.execute(f"PRAGMA synchronous={'FULL' if full else 'NORMAL'}")

    @contextlib.contextmanager
    def transaction(self) -> Iterator[Ledger]:
        with self._lock:
            begin, commit, rollback = self._tx_statements(self._depth)
            with self._locked() as conn:
                conn.execute(begin)
            self._depth += 1
            try:
                yield self
            except BaseException:
                self._depth -= 1
                self._run_quietly(rollback)
                raise
            self._depth -= 1
            try:
                with self._locked() as conn:
                    conn.execute(commit)
            except LedgerError:
                self._run_quietly(rollback)
                raise

    def _run_quietly(self, statements: Any) -> None:
        with self._lock, contextlib.suppress(sqlite3.Error):
            if self._conn is not None:
                for statement in statements:
                    self._conn.execute(statement)

    def append_receipt(self, kind: str, payload: dict[str, Any], ts: float | None = None) -> Any:
        normalized = module.normalize_payload(payload)
        stamp = round(float(self._now() if ts is None else ts), 3)
        with self.transaction(), self._locked() as conn:
            seq, prev = self._head(conn)
            seq += 1
            digest = module.receipt_hash(prev, seq, stamp, kind, normalized)
            conn.execute(f"INSERT INTO receipts({module._RECEIPT_COLUMNS}) VALUES (?, ?, ?, ?, ?, ?)",
                         (seq, stamp, kind, module.canonical_json(normalized), prev, digest))
        return module.Receipt(seq=seq, ts=stamp, kind=kind, payload=normalized, prev_hash=prev, hash=digest)


class Lock:
    def __init__(self, lock: Any, events: list[Any]) -> None:
        self.lock, self.events = lock, events
    def __enter__(self) -> Self:
        self.events.append("acquire")
        self.lock.__enter__()
        return self
    def __exit__(self, *args: object) -> Any:
        self.events.append("release")
        return self.lock.__exit__(*args)


class Connection:
    def __init__(self, connection: Any, events: list[Any], failure: str | None = None,
                 error: BaseException | None = None, rollback_fail: bool = False) -> None:
        self.connection, self.events, self.failure = connection, events, failure
        self.error, self.rollback_fail = error, rollback_fail
    def execute(self, sql: str, params: Any = ()) -> Any:
        self.events.append((sql, params))
        if self.failure and sql.startswith(self.failure):
            raise self.error
        if self.rollback_fail and sql.startswith("ROLLBACK"):
            raise sqlite3.OperationalError("cleanup fault")
        return self.connection.execute(sql, params)
    def close(self) -> None:
        self.connection.close()


@pytest.mark.parametrize("enabled", [False, True])
def test_original_order_bytes_clock_and_reentrant_lock_calls(monkeypatch: Any, enabled: bool) -> None:
    def run(cls: type[Ledger], observe: bool) -> list[Any]:
        events: list[Any] = []
        class Clock:
            def now(self) -> float:
                events.append("now")
                return 123.5
        class Value:
            def __str__(self) -> str:
                events.append("str")
                return "native-é"
        db = cls(":memory:", Clock())
        db._lock = Lock(db._lock, events)
        db._conn = Connection(db._conn, events)
        original_convert, original_encode = module.to_jsonable, json.dumps
        def convert(value: Any) -> Any:
            events.append("convert")
            return original_convert(value)
        def encode(*args: Any, **kwargs: Any) -> str:
            events.append("encode")
            return original_encode(*args, **kwargs)
        with monkeypatch.context() as patch:
            patch.setattr(module, "to_jsonable", convert)
            patch.setattr(json, "dumps", encode)
            with checkpoint_observation(db) if observe else contextlib.nullcontext():
                db.set_synchronous(False)
                with db.transaction():
                    db.set_kv("synthetic-key", {"z": Value(), 1: (True, -0.0)})
        db.close()
        return events
    assert run(Ledger, enabled) == run(OriginalLedger, False)


@pytest.mark.parametrize("failure", ["BEGIN", "INSERT INTO kv", "COMMIT"])
@pytest.mark.parametrize("rollback_fail", [False, True])
def test_sql_failures_and_cleanup_preserve_original_error_and_statements(failure: str, rollback_fail: bool) -> None:
    primary = sqlite3.OperationalError("original SQL failure")
    def run(cls: type[Ledger], enabled: bool) -> tuple[Any, Any, list[Any]]:
        db = cls(":memory:", type("Clock", (), {"now": lambda self: 123.5})())
        events: list[Any] = []
        db._conn = Connection(db._conn, events, failure, primary, rollback_fail)
        try:
            with checkpoint_observation(db) if enabled else contextlib.nullcontext(), pytest.raises(LedgerError) as error:
                db.set_kv("synthetic-key", {"x": 1})
            assert db._depth == 0
            return type(error.value), error.value.__cause__, events
        finally:
            db.close()
    assert run(Ledger, True) == run(OriginalLedger, False)


@pytest.mark.parametrize("fault_method", ["opened", "begin", "end", "closed"])
@pytest.mark.parametrize("primary_error", [ValueError("primary"), KeyboardInterrupt("primary")])
def test_observer_faults_never_mask_body_error_or_rollback(
    monkeypatch: Any, fault_method: str, primary_error: BaseException,
) -> None:
    with Ledger(":memory:") as db:
        def fail(*args: Any) -> Any:
            raise RuntimeError("observer fault")
        monkeypatch.setattr(LedgerObservation, fault_method, fail)
        with pytest.raises(type(primary_error)) as caught, checkpoint_observation(db), db.transaction():
            db.set_kv("synthetic-key", {"x": 1})
            raise primary_error
        assert caught.value is primary_error
        assert db.get_kv("synthetic-key") is None
        assert db._depth == 0 and db._observation() is None


@pytest.mark.parametrize("stage", ["convert", "encode"])
def test_native_and_exotic_conversion_failures_keep_original_exception(monkeypatch: Any, stage: str) -> None:
    error = TypeError("original conversion error")
    class Exotic:
        def __str__(self) -> str:
            raise error
    with Ledger(":memory:") as db:
        if stage == "convert":
            def fail(value: Any) -> Any:
                raise error
            monkeypatch.setattr(module, "to_jsonable", fail)
        with checkpoint_observation(db) as observation, pytest.raises(TypeError) as caught:
            db.set_kv("synthetic-key", Exotic())
        assert caught.value is error
        assert db.get_kv("synthetic-key") is None
        assert snapshot(observation)["commit_count"] == 0


def test_nested_contexts_transactions_and_outer_lock_are_distinct() -> None:
    with Ledger(":memory:") as db:
        with checkpoint_observation(db) as outer:
            db.set_synchronous(False)
            with db.transaction():
                db.set_kv("outer", 1)
                with checkpoint_observation(db) as inner:
                    db.set_kv("inner", 2)
                assert db._observation() is outer
        a, b = snapshot(outer), snapshot(inner)
        assert a["lock_count"] == 2  # PRAGMA wrapper plus transaction, not its nested _locked.
        assert a["begin_count"] == a["commit_count"] == 1
        assert a["nested_tx_omitted"] == 1
        assert b["lock_count"] == b["begin_count"] == b["commit_count"] == 0
        assert b["nested_tx_omitted"] == b["sql_count"] == 1
        assert db._observation() is None


def test_other_thread_transaction_does_not_hide_outer_acquisition() -> None:
    with Ledger(":memory:") as db, Ledger(":memory:") as other:
        ready, release, entered = threading.Event(), threading.Event(), threading.Event()
        def hold() -> None:
            with db.transaction():
                ready.set()
                assert release.wait(2)
        worker = threading.Thread(target=hold)
        worker.start()
        assert ready.wait(2)
        original = LedgerObservation.begin
        def mark(self: LedgerObservation, stage: str) -> Any:
            if stage == "lock":
                assert db._depth == 1  # Another thread still owns the outer transaction.
                entered.set()
                release.set()
            return original(self, stage)
        from unittest.mock import patch
        try:
            with patch.object(LedgerObservation, "begin", mark), checkpoint_observation(db) as observation:
                other.set_kv("not-observed", 1)
                db.set_kv("observed", 2)
            worker.join(2)
            assert not worker.is_alive() and entered.is_set()
            stats = snapshot(observation)
            assert stats["lock_count"] == stats["begin_count"] == stats["commit_count"] == 1
            assert stats["sql_count"] == stats["json_encode_count"] == 1
        finally:
            release.set()
            worker.join(2)


@pytest.mark.parametrize("fault_at", ["factory", "enter", "exit", "truthy_exit"])
def test_feature_context_faults_never_skip_repeat_or_suppress_body(fault_at: str) -> None:
    calls: list[str] = []
    class Context:
        def __enter__(self) -> None:
            calls.append("enter")
            if fault_at == "enter":
                raise RuntimeError("observer enter failure")
        def __exit__(self, *args: object) -> bool:
            calls.append("exit")
            if fault_at == "exit":
                raise RuntimeError("observer exit failure")
            return True
    class Fake:
        def checkpoint_timing(self) -> Context:
            if fault_at == "factory":
                raise RuntimeError("observer factory failure")
            return Context()
    error = RuntimeError("body failure")
    with pytest.raises(RuntimeError) as caught, checkpoint_observation(Fake()):
        calls.append("body")
        raise error
    assert caught.value is error
    assert calls.count("body") == 1


@pytest.mark.parametrize("bad", [float("nan"), float("inf"), -1.0])
def test_bad_diagnostic_clock_cannot_break_kv_or_emit_nonfinite(monkeypatch: Any, bad: float) -> None:
    with Ledger(":memory:") as db:
        monkeypatch.setattr(timing, "time", type("Clock", (), {"monotonic": staticmethod(lambda: bad),
                                                            "thread_time": staticmethod(lambda: bad)}))
        with checkpoint_observation(db) as observation:
            db.set_kv("key", {"nan-still-allowed-in-KV": float("nan")})
        assert db.get_kv("key") is not None
        value = snapshot(observation)
        json.dumps(value, allow_nan=False)
        assert value["enabled"] == 0


def test_two_threads_observe_only_their_own_operations() -> None:
    with Ledger(":memory:") as db:
        barrier = threading.Barrier(2)
        results: list[dict[str, int | float]] = []
        def worker(key: str) -> None:
            with checkpoint_observation(db) as observation:
                barrier.wait(2)
                db.set_kv(key, [1, 2])
            results.append(snapshot(observation))
        threads = [threading.Thread(target=worker, args=(key,)) for key in ("a", "b")]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(2)
            assert not thread.is_alive()
        assert len(results) == 2
        assert all(row["sql_count"] == row["to_jsonable_count"] == row["begin_count"] == 1 for row in results)
        assert db._observation() is None


def test_sql_error_survives_observer_end_failure_and_failed_rollback(monkeypatch: Any) -> None:
    with Ledger(":memory:") as db:
        primary = sqlite3.OperationalError("original database error")
        db._conn = Connection(db._conn, [], "INSERT INTO kv", primary, rollback_fail=True)
        def fail(*args: Any) -> None:
            raise KeyboardInterrupt("observer failure")
        monkeypatch.setattr(LedgerObservation, "end", fail)
        with pytest.raises(LedgerError) as error, checkpoint_observation(db):
            db.set_kv("synthetic", 1)
        assert error.value.__cause__ is primary
        assert db._depth == 0


def test_snapshots_reject_arbitrary_fields_and_are_independent_copies(monkeypatch: Any) -> None:
    with Ledger(":memory:") as db:
        with checkpoint_observation(db) as observation:
            db.set_kv("secret-key-never-in-telemetry", {"token": "secret-value-never-in-telemetry"})
        first = snapshot(observation)
        first["sql_count"] = 999
        assert snapshot(observation)["sql_count"] == 1
        encoded = json.dumps(snapshot(observation), allow_nan=False)
        assert "secret-key" not in encoded and "secret-value" not in encoded and "INSERT" not in encoded
        monkeypatch.setattr(observation, "snapshot", lambda: {"secret-value": 3})
        assert snapshot(observation) == {"enabled": 0, "errors": 1}


def test_absent_optional_context_and_regressing_clock_are_safe(monkeypatch: Any) -> None:
    with checkpoint_observation(object()) as absent:
        assert absent is None
    with Ledger(":memory:") as db:
        counter = iter([10., 9., 8., 7., 6., 5., 4., 3., 2., 1., 0.])
        monkeypatch.setattr(timing, "time", type("Clock", (), {
            "monotonic": staticmethod(lambda: next(counter, 0.)),
            "thread_time": staticmethod(lambda: 0.),
        }))
        with checkpoint_observation(db) as observation:
            db.set_kv("still-committed", 1)
        assert db.get_kv("still-committed") == 1
        assert snapshot(observation)["enabled"] == 0


@pytest.mark.parametrize("failure", [None, "BEGIN", "INSERT INTO receipts", "COMMIT", "canonical"])
@pytest.mark.parametrize("rollback_fail", [False, True])
def test_pinned_receipt_and_cleanup_order(monkeypatch: Any, failure: str | None, rollback_fail: bool) -> None:
    """Independent a165f34 receipt/rollback bodies, including argument evaluation."""
    primary = sqlite3.OperationalError("original receipt failure")
    def run(cls: type[Ledger], enabled: bool) -> tuple[Any, list[Any]]:
        events: list[Any] = []
        class Clock:
            def now(self) -> float:
                events.append("now")
                return 123.5
        db = cls(":memory:", Clock())
        db._lock = Lock(db._lock, events)
        db._conn = Connection(db._conn, events, failure, primary, rollback_fail)
        originals = {name: getattr(module, name) for name in ("normalize_payload", "receipt_hash", "canonical_json")}
        def wrapped(name: str) -> Any:
            def call(*args: Any, **kwargs: Any) -> Any:
                events.append(name)
                if name == "canonical_json" and failure == "canonical":
                    raise primary
                return originals[name](*args, **kwargs)
            return call
        try:
            with monkeypatch.context() as patch:
                for name in originals:
                    patch.setattr(module, name, wrapped(name))
                try:
                    with checkpoint_observation(db) if enabled else contextlib.nullcontext():
                        receipt = db.append_receipt("synthetic", {"é": [1, -0.0]})
                    result = (receipt.seq, receipt.ts, receipt.hash)
                except (LedgerError, sqlite3.Error) as error:
                    result = (type(error), error.__cause__ if isinstance(error, LedgerError) else error)
            assert db._depth == 0
            return result, events
        finally:
            db.close()
    assert run(Ledger, True) == run(OriginalLedger, False)
