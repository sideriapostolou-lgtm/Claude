"""Offline diagnostic overhead, actual :memory: ledger; no production inference."""
import json
from pathlib import Path
import statistics
import sys
import time
sys.path[:0]=['/workspace/nightcrawler-ledger-timing/src','/workspace/nightcrawler-ledger-timing/tests']
from test_ledger_timing import OriginalLedger
from nightcrawler.ledger import Ledger
from nightcrawler.ledger_timing import checkpoint_observation,snapshot

payloads={'tiny':{'version':1,'values':[1,2,3]},'native_1000':{'version':1,'rows':[
 {'window':f'SYNTHETIC-{i}','levels':[.4,.6],'history':{'shares':0,'at':1234567890.123,'closed':True}}
 for i in range(1000)]}}
result={'scope':'Offline native synthetic :memory: ledger; timing overhead only, no fsync/WAL/production inference',
        'method':'9 batches, each20 outertransactions, oneKVrow pertransaction. Trialorder original,disabled,enabled; no significance claim.',
        'cases':{}}
for label,value in payloads.items():
 case={}
 for variant,cls in [('original',OriginalLedger),('disabled',Ledger),('enabled',Ledger)]:
  with cls(':memory:') as db:
   samples=[];latest=None
   for repeat in range(9):
    wall,cpu=time.perf_counter(),time.thread_time()
    for _ in range(20):
     if variant=='enabled':
      with checkpoint_observation(db) as observation, db.transaction():
       db.set_kv('synthetic',value)
      latest=snapshot(observation)
     else:
      with db.transaction():db.set_kv('synthetic',value)
    samples.append({'wall_us_per_save':(time.perf_counter()-wall)*1e6/20,
                    'thread_cpu_us_per_save':(time.thread_time()-cpu)*1e6/20})
   case[variant]={'samples':samples,
       'median_wall_us_per_save':statistics.median(row['wall_us_per_save'] for row in samples),
       'median_thread_cpu_us_per_save':statistics.median(row['thread_cpu_us_per_save'] for row in samples)}
   if latest:
    case[variant]['snapshot_fields']=len(latest)
    case[variant]['snapshot_json_bytes']=len(json.dumps(latest,separators=(',',':')).encode())
    case[variant]['practice_panel_added_json_bytes']=len(json.dumps({'checkpoint_ledger_timing':{'previous_successful_checkpoint':1,'one_save_lag':1,**latest}},separators=(',',':')).encode())
 case['input_json_bytes']=len(json.dumps(value,separators=(',',':')))
 result['cases'][label]=case
 print(label,[(name,round(row['median_wall_us_per_save'],2)) for name,row in case.items() if isinstance(row,dict)])
Path('/workspace/shared/ledger-timing-overhead.json').write_text(json.dumps(result,indent=2,allow_nan=False))
