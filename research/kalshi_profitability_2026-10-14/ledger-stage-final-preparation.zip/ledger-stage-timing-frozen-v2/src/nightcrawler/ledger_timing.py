"""Optional bounded numeric checkpoint timings; never a persistence authority.

Stages are child measurements, not additional WorkTrace occupancy. Receipt
normalization/hash, PRAGMAs and rollback are omitted. Nested savepoint/release
operations are counted as omitted; their data SQL is still observed.
"""
from __future__ import annotations

import math
import sys
import time
from collections.abc import Iterator
from contextlib import contextmanager
from typing import Any

STAGES = ("to_jsonable", "json_encode", "lock", "begin", "sql", "commit")
FIELDS = ("enabled", "errors", "context_failed", "nested_tx_omitted", "context_start_mono", "context_end_mono") + tuple(
    f"{stage}_{suffix}" for stage in STAGES for suffix in ("count", "wall_ms", "thread_cpu_ms")
)


class LedgerObservation:
    def __init__(self) -> None:
        self._last_clock: tuple[float, float] | None = None
        self.start_mono = self.end_mono = 0.0
        self.enabled = True
        self.errors = 0
        self.context_failed = 0
        self.nested_omitted = 0
        self.values = {stage: [0, 0.0, 0.0] for stage in STAGES}

    def _clocks(self) -> tuple[float, float]:
        wall, cpu = time.monotonic(), time.thread_time()
        if (type(wall) not in (int, float) or type(cpu) not in (int, float)
                or not math.isfinite(wall) or not math.isfinite(cpu) or wall < 0 or cpu < 0
                or (self._last_clock is not None
                    and (wall < self._last_clock[0] or cpu < self._last_clock[1]))):
            raise ValueError("invalid diagnostic clock")
        self._last_clock = wall, cpu
        return wall, cpu

    def opened(self) -> None:
        self.start_mono = self._clocks()[0]

    def closed(self) -> None:
        self.end_mono = self._clocks()[0]

    def begin(self, stage: str) -> tuple[float, float] | None:
        return self._clocks() if self.enabled else None

    def end(self, stage: str, token: tuple[float, float] | None) -> None:
        if not self.enabled or token is None:
            return
        finish, used = self._clocks()
        wall, cpu = finish - token[0], used - token[1]
        bucket = self.values[stage]
        bucket[0] += 1
        bucket[1] += wall * 1000
        bucket[2] += cpu * 1000
        if not all(math.isfinite(value) for value in bucket):
            raise ValueError("invalid diagnostic aggregate")

    def snapshot(self) -> dict[str, int | float]:
        result: dict[str, int | float] = {
            "enabled": int(self.enabled), "errors": self.errors, "context_failed": self.context_failed,
            "context_start_mono": self.start_mono, "context_end_mono": self.end_mono,
            "nested_tx_omitted": self.nested_omitted,
        }
        for stage in STAGES:
            count, wall, cpu = self.values[stage]
            result.update({f"{stage}_count": int(count), f"{stage}_wall_ms": wall,
                           f"{stage}_thread_cpu_ms": cpu})
        return result


def fault(observation: LedgerObservation | None) -> None:
    # Only observer faults are contained, including faults during unwinding a
    # primary BaseException. No application exception is caught by this helper.
    try:
        if observation is not None:
            observation.enabled = False
            observation.errors += 1
    except BaseException:  # noqa: BLE001, S110 - diagnostics never mask or log application failures.
        pass


def begin(observation: LedgerObservation | None, stage: str | None) -> tuple[float, float] | None:
    try:
        return observation.begin(stage) if observation is not None and stage is not None else None
    except BaseException:  # noqa: BLE001 - optional diagnostics cannot mask primary failures.
        fault(observation)
        return None


def end(observation: LedgerObservation | None, stage: str | None,
        token: tuple[float, float] | None) -> None:
    if observation is not None and stage is not None and token is not None:
        try:
            observation.end(stage, token)
        except BaseException:  # noqa: BLE001 - optional diagnostics cannot mask primary failures.
            fault(observation)


@contextmanager
def measure(observation: LedgerObservation | None, stage: str | None) -> Iterator[None]:
    token = begin(observation, stage)
    try:
        yield
    finally:
        end(observation, stage, token)


@contextmanager
def checkpoint_observation(ledger: Any) -> Iterator[LedgerObservation | None]:
    """Feature-detect fakes; enter/exit faults never skip or suppress the body."""
    context = observation = None
    entered = False
    try:
        factory = getattr(ledger, "checkpoint_timing", None)
        if callable(factory):
            context = factory()
            candidate = context.__enter__()
            entered = True
            if type(candidate) is LedgerObservation:
                observation = candidate
    except BaseException:  # noqa: BLE001 - optional diagnostics cannot mask primary failures.
        fault(observation)
    try:
        yield observation
    finally:
        if entered and context is not None:
            try:
                context.__exit__(*sys.exc_info())
            except BaseException:  # noqa: BLE001 - optional diagnostics cannot mask primary failures.
                fault(observation)


def snapshot(observation: LedgerObservation | None) -> dict[str, int | float]:
    try:
        result: dict[str, int | float]
        if observation is None:
            return {"enabled": 0, "errors": 0}
        raw = observation.snapshot()
        if type(raw) is not dict or set(raw) != set(FIELDS):
            raise ValueError("invalid diagnostic fields")
        result = {}
        for key in FIELDS:
            value = raw[key]
            if type(value) not in (int, float) or not math.isfinite(value) or value < 0:
                raise ValueError("invalid diagnostic value")
            result[key] = value
        completed = time.monotonic()
        if (type(completed) not in (int, float) or not math.isfinite(completed)
                or completed < result.get("context_end_mono", 0)):
            raise ValueError("invalid diagnostic completion clock")
        result["checkpoint_completed_mono"] = completed
        return result
    except BaseException:  # noqa: BLE001 - optional diagnostics cannot mask primary failures.
        fault(observation)
        return {"enabled": 0, "errors": 1}


def publish(trace: Any, role: str, value: dict[str, int | float]) -> None:
    """Best effort after checkpoint barriers; no callback runs inside Ledger."""
    try:
        method = getattr(trace, "record_ledger_timing", None)
        if callable(method):
            method(role, value)
    except BaseException:  # noqa: BLE001, S110 - diagnostics never mask or log application failures.
        pass
