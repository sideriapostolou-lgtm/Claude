# Exact independent ledger-stage diagnostic review

**Accepted within the diagnostic scope; no outstanding blocking defect found in frozen-v2.** This is an independent source/test review, not full-suite completion, a production release decision, selection of a performance correction, or clearance of EXEC-DELAY-001. Parent owns full checks, release timing and post-release verification. The active production capture remains source1e8d0be through its fixed05:32 tail.

## Findings and their resolution

1. Root identified that extracting new ledger slots inside the existing broad `WorkTrace.overlap` exception handler could let a ledger-only metadata fault disable the original WorkTrace observer and discard existing span/bin evidence. Final `_ledger_overlap` contains its own optional extraction faults, increments only the ledger-observation error counter and returns an empty ledger-observation mapping. Original spans/bins/coverage remain available.
2. Independent review identified a false-positive regression setup: `[1.,1.,2.,2.]` supplied identical wall times to the single span's begin/end, creating zero-duration quiet work. Frozen-v2 uses `[1.,2.]` and explicitly asserts nonempty baseline spans and positive full-bin lower-bound coverage before injecting `.items()` and item-lookup failures, each with RuntimeError and KeyboardInterrupt. This was a test defect, not a demonstrated production behavior defect. Superseded bundle1a097bf10de7e3d703d3aa1332e0f7ed1b4867adbccb397a7a486a193a3047a5 is not the accepted bundle.
3. Independent review noted that the first baseline differential inherited candidate receipt/rollback bodies. Final tests pin independent original receipt insertion and rollback bodies, then compare method/argument/clock/lock/SQL order and error identity for success, BEGIN/receipt INSERT/COMMIT/canonical conversion failures and failed rollback. This tightened validation; no financial source defect was observed.

## Exact identity and independent checks

Base HEAD `86013da3cabb28d56a829c99b0771ebdbd54b047`; source baseline `a165f34fb8992192a33befcd6a5e8e4a09bc9dd3` (app1e8d0be). Independently checked base advancement touches only docs/COORDINATION.md, docs/WORKLOG.md and a research JSON. All seven worktree files byte-match frozen-v2 copies and the SHA256 manifest.

Bundle SHA256, manifest order path+NUL+bytes+NUL: `668ba5b47e8ba142d0f61bc00953e264163b4b2d282acd58a8015dec59de78e9`.
Patch SHA256: `dda8bf2e65a4c8a565e25535b64229e476f6b3a8d652b26d38b45b8db02ea143`.
Manifest: `/workspace/shared/ledger-stage-timing-frozen-v2/manifest.json`.

| File | SHA256 |
|---|---|
| `src/nightcrawler/ledger.py` | `32230b507ea32455a1c18ddd998438e8fa2fc87be0a7483918b7f4a347e87d50` |
| `src/nightcrawler/ledger_timing.py` | `e9927e94583847d8f1a954f83e87ad775e918e312a6ef4e3a058ffb8c794b99e` |
| `src/nightcrawler/speeddesk.py` | `bf4ce2fcc3f10c730a6851abd0d49ddfc5ba9ae391fd70ff3dabc9af4f260e05` |
| `src/nightcrawler/speeddesk_live.py` | `26c9a0c5d2cecbc7ece0a7de10edd05304ddc3115b9436d2ea4119314e2bdb47` |
| `src/nightcrawler/speeddesk_worktrace.py` | `22604f9ed87cbd831967d66faf078be6f00fa8119afc6195f470e35447f99b2a` |
| `tests/test_ledger_timing.py` | `be06e0daf229a4bf7ee615f76377ba6b978edc169ab4b0c22f22a9f4b41722ff` |
| `tests/test_checkpoint_ledger_timing.py` | `03cf5fb3ed8723346478e6305c885bb08b348a3a97e570a03a0e19fd75f436b4` |

Independent exact-bundle command, cwd `/workspace/nightcrawler-ledger-timing`:

```
PYTHONPATH=src:tests /workspace/shared/nightcrawler-venv/bin/pytest -q tests/test_ledger_timing.py tests/test_checkpoint_ledger_timing.py
```

Result: **60passed in0.34s** on the shared Python3.12 environment. Worker manifest separately records175targeted tests passed in7.12s, Ruff on7files and mypy on5sources passed. Those broader checks are worker receipts, not represented as independently rerun here. Parent full-suite result was still pending at acceptance.

## Persistence and failure preservation

- Existing set_synchronous, transaction, BEGIN/savepoint/release/COMMIT/rollback, SQL and KV serialization order is preserved. RLock remains the connection/transaction authority. Thread-local lock nesting measures only the calling thread's outer acquisition; another thread's `_depth` cannot suppress that acquisition's timing.
- Observation is per-Ledger and per-thread. Nested contexts restore the parent; another Ledger's operations are excluded. No global callback or asynchronous writer is introduced. No callbacks/logging/SQL-value publication run inside the ledger lock.
- `_dumps` keeps the original conversion then compact default=str encoding contract. The observed path splits `to_jsonable` and encoding; the original path remains when absent. Native/exotic conversions, NaN KV behavior, primary BaseException and SQLite-to-LedgerError cause identity are tested. Optional feature factory/enter/exit faults do not skip, repeat or suppress the protected body.
- Existing financial receipt/hash and complete saved state, archival chunks, journal clear, durability selection, restore authority and checkpoint cadence remain unchanged. `_journal_intent` is untouched. No order/risk/budget/stop/resume or coalescing/pruning policy changes exist in the patch.
- Live publication occurs after commit, journal/pending/archive bookkeeping, any required mirror replacement and original checkpoint bookkeeping. Mirror failure retains the previous successful observation and preserves original exception/committed-ledger behavior. Practice publication similarly follows logs, successful mirror and last_checkpoint update.
- Practice panel explicitly describes the previous successful observation with one-save lag. That adds bounded numeric diagnostic bytes to the saved display panel; it is not a financial authority. Live status copies the nested timing snapshot to prevent deferred status payload aliasing. Neither publication adds a separate ledger sink or per-checkpoint log stream.

## Measurement contract and interpretation

Fixed allowlisted numeric count/wall/threadCPU aggregates cover KV `to_jsonable`, KV JSON encoding, outer calling-thread RLock acquisition, outer BEGIN, measured data SQL and outer COMMIT. No SQL strings/keys/values, receipt metadata, credentials or arbitrary labels enter the snapshots. Receipt normalization/hash, PRAGMAs, rollback and nested savepoint/release are deliberately omitted; nested transaction omissions are counted. The measured context still spans omitted ledger work, so stage sums are not complete coverage.

WorkTrace retains exactly one latest completed numeric copy per fixed role, practice/live, with measured context start/end, checkpoint completion, publication timestamp and generation. Only intersecting positive context intervals from enabled successful observations are returned. Empty intervals and older publication are rejected/excluded. Earlier completed checkpoints can be overwritten; absence is not evidence of no ledger work. These measurements overlap parent spans and must not be added to WorkTrace/bin occupancy. The context interval is ledger-scoped, not whole-checkpoint time.

High wall with low threadCPU can distinguish pure calling-thread CPU from elapsed time but cannot by itself separate WAL auto-checkpoint/fsync, SQLite contention, another thread/GIL contention or scheduling. BEGIN/COMMIT/SQL/RLock splitting is the next evidence step; no SQLite pragma/durability or writer-thread change is justified merely by a large aggregate. Practice daily-report CPU is outside these new ledger child stages and remains observable in existing WorkTrace.

## Bounded overhead evidence and remaining limits

Reviewed saved offline synthetic `:memory:` and file FULL/WAL overhead artifacts in frozen-v2. They include enabled/disabled/original paths,9batches of20transactions per case, fixed original→disabled→enabled trial order, exact file KV-byte comparisons and no production inference. Tiny in-memory original/disabled/enabled median wall18.99/46.64/76.45microseconds shows the wrappers are not free even without an active observer. Native1000-row (~103KB) in-memory medians3.590/3.584/3.621ms are noisy context, not a proven overhead bound. Added practice-panel JSON in these samples is about856–875bytes. Local FULL/WAL storage timings are not Railway fsync or saturation evidence.

The test suite and fault firewall do not make diagnostics costless or prove they will capture every incident. Latest-only retention can miss the responsible completed checkpoint, failed checkpoints do not publish successful observations, selected detail limits remain, and the256receipt ring still overflows. Post-release originals must establish what is actually measured before a next correction is chosen. Preserve all financial losses and fixed observation windows independently of this review.
