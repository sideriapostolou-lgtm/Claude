# Ledger checkpoint timing candidate frozen v2 2026-10-15 05:25:34 UTC

Base a165f34fb8992192a33befcd6a5e8e4a09bc9dd3. No commit/push/release or production access performed. Seven-file exact candidate, per-file hashes, patch and raw evidence: `/workspace/shared/ledger-stage-timing-frozen-v2/manifest.json`. Root full suite and independent exact-bundle Astra acceptance remain required.

Validation: 175 targeted tests passed in 7.12 seconds, including 60 new focused cases; Ruff seven changed files passed; mypy five changed source files passed. Targets: new ledger/checkpoint timing tests, existing ledger, live mirror, worktrace and worktrace integration, runtime, practice sync, live crash tests. Differential fixture copies original a165f34 relevant lock/transaction/KV/receipt/rollback method bodies statically; no Git/network dependency at test runtime. Unchanged initialization/head/schema/hash helpers remain inherited/shared, so this is plumbing differential coverage, not a separate entire legacy ledger implementation. Tests compare original SQL parameters/order, lock calls, serialization/receipt argument evaluation and _now order, bytes, storage/serialization/cleanup failure identity and rollback state.

All new timings are numeric optional diagnostic stages. Lock timing is elapsed outer instrumented RLock acquisition, not a pure contention measurement. Receipt normalization/hash, PRAGMAs and rollback timing are omitted; nested transaction SAVEPOINT/release statements are explicitly counted as omitted. Child stages overlap existing synchronous checkpoint WorkTrace spans and are not added to occupancy. Completed checkpoint snapshots have 25 numeric fields. Latest practice panel diagnostic explicitly denotes previous successful checkpoint and one-save lag. Publication follows existing checkpoint barriers; retained WorkTrace slots are only latest completed per fixed practice/live role. Query output explicitly says older observations may be overwritten, absence does not establish no work, and values are not additive to spans. Detached copies prevent panel/query consumers mutating retained diagnostic snapshots. Slot extraction failures now independently return empty/error and preserve original span/bin evidence, including injected observer-only KeyboardInterrupt failures.

## Offline overhead receipt

Unchanged pinned original plumbing, candidate unobserved, candidate observed each ran nine batches of twenty outer transactions with one KV row per save. Synthetic native JSON tiny and 1,000-row payloads only. Actual file Ledger default FULL (PRAGMA synchronous=2) and WAL were verified; serialized KV value bytes were compared exactly to original options. Raw samples, scripts and hashes are preserved in frozen evidence. Wall is perf_counter; CPU is thread_time, not process CPU. Snapshot creation included once per observed save; no production WorkTrace publication or panel rendering is included. Trial order was fixed original, disabled, enabled, no randomization/significance estimate; local filesystem/caches and other work can affect results. No production latency/cause/financial inference or performance assertion follows.

File-backed median microseconds per save:

| Payload | Original wall / thread CPU | Disabled wall / thread CPU | Observed wall / thread CPU |
| --- | --- | --- | --- |
| tiny | 584.90 / 119.23 | 525.98 / 142.20 | 650.01 / 190.32 |
| native 1,000 rows | 4227.85 / 3620.96 | 4225.49 / 3680.45 | 4505.12 / 3907.46 |

Memory-backed median microseconds per save:

| Payload | Original wall / thread CPU | Disabled wall / thread CPU | Observed wall / thread CPU |
| --- | --- | --- | --- |
| tiny | 18.99 / 19.02 | 46.64 / 46.65 | 76.45 / 76.47 |
| native 1,000 rows | 3589.96 / 3590.02 | 3583.82 / 3583.89 | 3621.06 / 3620.97 |

Diagnostic overhead is measurable, not zero. Actual final numeric snapshot JSON examples were 775–794 bytes, and practice panel wrapper examples 856–875 bytes. Those are measurements for the samples, not universal byte upper bounds; fixed field count and two retained roles bound the number of values.

V2 supersedes preserved first freeze 1a097: only the slot-fault test changed, correcting a zero-duration clock fixture to a real one-second span and asserting nonempty spans and positive work-bin coverage before injected faults. Five source bytes are identical. Current worktree HEAD at freeze includes root docs-only 86013da; original application baseline remains a165f34.
