"""Offline bounded observer microbenchmark; no network, threads, trading or persistence."""
import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import sys
import time
import types

ROOT = Path('/workspace/nightcrawler-next-evidence')
sys.path.insert(0, str(ROOT / 'src'))
from nightcrawler.speeddesk_worktrace import WorkTrace
BASE = '67c54a6'
old = subprocess.check_output(['git', 'show', BASE + ':src/nightcrawler/speeddesk_worktrace.py'], cwd=ROOT, text=True)
module = types.ModuleType('immutable_worktrace')
exec(compile(old, '<immutable67c54a6-worktrace>', 'exec'), module.__dict__)
CLASSES = {'baseline': module.WorkTrace, 'candidate': WorkTrace}
N = 3000

def measure(kind):
    trace = CLASSES[kind]()
    before_cpu, before_wall = time.thread_time_ns(), time.perf_counter_ns()
    for _ in range(N):
        with trace.span('feed_book'):
            pass
        with trace.span('feed_trade'):
            pass
    wall, cpu = time.perf_counter_ns() - before_wall, time.thread_time_ns() - before_cpu
    assert trace.enabled and trace.completed == 2 * N
    return {'wall_ns_per_pair': wall / N, 'cpu_ns_per_pair': cpu / N, 'completed': trace.completed}

measure('baseline')
measure('candidate')
rows = []
for i in range(8):
    order = ('baseline', 'candidate') if i % 2 == 0 else ('candidate', 'baseline')
    row = {'order': order}
    for kind in order:
        row[kind] = measure(kind)
    rows.append(row)
result = {'base': BASE, 'baseline_source_sha256': hashlib.sha256(old.encode()).hexdigest(),
          'candidate_files': {p: hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in
                              ('src/nightcrawler/speeddesk_worktrace.py', 'src/nightcrawler/speeddesk_workbins.py')},
          'pairs_per_sample': N, 'samples': rows,
          'median_wall_ns_per_pair': {k: statistics.median(r[k]['wall_ns_per_pair'] for r in rows) for k in CLASSES},
          'median_cpu_ns_per_pair': {k: statistics.median(r[k]['cpu_ns_per_pair'] for r in rows) for k in CLASSES},
          'limits': ['Synthetic empty span pairs, not real feed callbacks or production timing.',
                     'Real clocks, normal GC; instrumentation overhead included equally.',
                     'Eight alternating AB/BA pairs in one sequential process; no heavy concurrent jobs requested.',
                     'Does not replace unchanged full-suite performance gates.']}
path = Path('/workspace/shared/exec-delay-workbins-overhead.json')
path.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k:result[k] for k in ('median_wall_ns_per_pair','median_cpu_ns_per_pair','candidate_files')}))
