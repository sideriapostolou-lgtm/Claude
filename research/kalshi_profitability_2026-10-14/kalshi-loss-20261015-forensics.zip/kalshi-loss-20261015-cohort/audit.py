"""Offline exact-original log parser. Never traverses status/latest_events."""
import hashlib
import json
import re
from collections import Counter
from datetime import datetime, timedelta, timezone
from decimal import Decimal as D
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DEPLOYMENT = 'fc0a73e9-f052-435a-94b2-ce7b1272f36e'
PATTERN = re.compile(r'^\S+ INFO nightcrawler\.speeddesk: (speeddesk_live_(?:settlement|fill|order|cancel|reject|markout)) (\{.*\})$')
START = datetime(2026, 10, 15, 5, 30, tzinfo=timezone.utc)
END = datetime(2026, 10, 15, 11, 15, tzinfo=timezone.utc)

def main():
    originals, events, queries = [], [], []
    for path in sorted(ROOT.glob('*.json')):
        if path.name in {'audit.json', 'manifest.json'}:
            continue
        wrapper = json.loads(path.read_text())
        if 'query' not in wrapper:
            continue
        response = wrapper['response']
        data = response.get('structuredContent')
        q = {'file': path.name, 'query': wrapper['query'], 'error': response.get('isError', False)}
        if data:
            assert data['scope'] == 'deployment' and data['deploymentId'] == DEPLOYMENT
            q.update({k: data.get(k) for k in ('scope', 'deploymentId', 'serviceId', 'environmentId', 'status')})
            rows = data.get('deploy', [])
            q['rows'] = len(rows)
            q['capped'] = len(rows) >= wrapper['query']['limit']
            for row in rows:
                originals.append(row)
                match = PATTERN.fullmatch(row['message'])
                if match:
                    events.append({'event': match[1], 'timestamp': row['timestamp'], 'data': json.loads(match[2], parse_float=D)})
        queries.append(q)
    settlements = {}
    excluded = []
    expected = []
    cursor = START + timedelta(minutes=15)
    while cursor <= END:
        local = cursor - timedelta(hours=4)
        expected.append((f'KXBTC15M-26OCT15{local:%H%M}-{local:%M}', cursor))
        cursor += timedelta(minutes=15)
    for event in events:
        if event['event'] != 'speeddesk_live_settlement':
            continue
        d = event['data']
        if d['window'] not in dict(expected):
            excluded.append({'window': d['window'], 'reason': 'outside fixed cohort; prior boundary settlement'})
            continue
        assert d['window'] not in settlements, 'duplicate original settlement'
        settlements[d['window']] = d
    windows = []
    for ticker, ending in expected:
        entry = {'ticker': ticker, 'start_utc': (ending-timedelta(minutes=15)).isoformat(), 'end_utc': ending.isoformat()}
        d = settlements.get(ticker)
        if not d:
            entry['status'] = 'missing original settlement; not inferred zero'
        else:
            assert abs(d['payout_usd'] - d['cost_usd'] - d['fee_usd'] - d['pnl_usd']) < D('0.0000001')
            assert abs(d['locked_usd'] + d['direction_usd'] - d['pnl_usd']) < D('0.0000001')
            entry.update(d)
            entry.update(status='original settlement; fills unavailable', pairs=min(d['up_shares'], d['down_shares']), leftover_shares=abs(d['up_shares']-d['down_shares']), both_sides=d['up_shares'] > 0 and d['down_shares'] > 0, fill_count=None, maker_count=None, taker_count=None, fill_join='unknown: log transport failed')
        windows.append(entry)
    observed = [x for x in windows if 'pnl_usd' in x]
    result = {'scope': {'deployment': DEPLOYMENT, 'source': '1e8d0be07b280292fa873a2f5da9b22dd02f28c3', 'start': START.isoformat(), 'end': END.isoformat(), 'publication_tail': '2026-10-15T11:18:00Z'}, 'queries': queries, 'original_rows': len(originals), 'anchored_events': len(events), 'excluded': excluded, 'expected_windows': len(expected), 'observed_settlements': len(observed), 'missing_settlements': len(expected)-len(observed), 'observed_only_totals': {k: sum((x[k] for x in observed), D(0)) for k in ['cost_usd', 'fee_usd', 'payout_usd', 'pnl_usd', 'locked_usd', 'direction_usd', 'pairs', 'leftover_shares']}, 'wins': sum(x['pnl_usd'] > D('0.0000001') for x in observed), 'losses': sum(x['pnl_usd'] < -D('0.0000001') for x in observed), 'both_sides': sum(x['both_sides'] for x in observed), 'worst': min(observed, key=lambda x:x['pnl_usd'])['ticker'], 'best': max(observed, key=lambda x:x['pnl_usd'])['ticker'], 'windows': windows}
    (ROOT/'audit.json').write_text(json.dumps(result, indent=2, default=str)+'\n')
    table = ['| UTC window | Ticker | Up / Down | Cost | Fees | Payout | P&L | Locked | Direction |', '| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for x in windows:
        period = x['start_utc'][11:16]+'–'+x['end_utc'][11:16]
        if 'pnl_usd' not in x:
            table.append(f"| {period} | {x['ticker']} | UNKNOWN | | | | | | |")
        else:
            values = ' | '.join(f"{x[k]:.6f}" for k in ('cost_usd', 'fee_usd', 'payout_usd', 'pnl_usd', 'locked_usd', 'direction_usd'))
            table.append(f"| {period} | {x['ticker']} | {x['up_shares']} / {x['down_shares']} | {values} |")
    (ROOT/'table.md').write_text('\n'.join(table)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in {'queries', 'windows'}}, indent=2, default=str))

if __name__ == '__main__':
    main()
