"""Read-only original-event join; no nested traversal or venue access."""
import json,re,hashlib
from pathlib import Path
from decimal import Decimal as D
from collections import Counter,defaultdict
P=Path(__file__).resolve().parent
RX=re.compile(r'^\S+ INFO nightcrawler\.speeddesk: (speeddesk_live_\w+) (\{.*\})$')
def dump(path,x):path.write_text(json.dumps(x,indent=2,default=str)+'\n')
def main():
 events=defaultdict(list);seen=set();queries=[]
 for p in sorted(P.glob('*.json')):
  if p.name in {'audit.json','manifest.json','run-summary.json','static-decomposition-totals.json'}:continue
  w=json.loads(p.read_text());q=w.get('query');r=w.get('response',{});s=r.get('structuredContent')
  if not q:continue
  if not s:queries.append({'file':p.name,'error':True});continue
  assert s['scope']=='deployment' and s['deploymentId']=='fc0a73e9-f052-435a-94b2-ce7b1272f36e'
  rows=s.get('deploy',[]);cap=len(rows)>=500
  queries.append({'file':p.name,'query':q,'metadata':{k:s.get(k) for k in ['scope','deploymentId','serviceId','environmentId','status']},'rows':len(rows),'capped':cap,'used':not cap})
  if cap:continue
  for row in rows:
   ident=(row['timestamp'],row['message'])
   if ident in seen:continue
   seen.add(ident);m=RX.fullmatch(row['message']);assert m,'unanchored phrase row'
   d=json.loads(m[2],parse_float=D);d['_publication']=row['timestamp'];events[m[1]].append(d)
 intents={};acks={};not_sent={};fills={};settled={};excluded=[]
 for o in events['speeddesk_live_order']:
  if o['state'].startswith('durable intent'):intents[o['client_order_id']]=o
  elif o['state'].startswith('accepted;'):acks[o['client_order_id']]=o
  elif o['state'].startswith('not sent;'):not_sent[o['client_order_id']]=o
 for f in events['speeddesk_live_fill']:
  assert f['fill_id'] not in fills
  fills[f['fill_id']]=f
 for s in events['speeddesk_live_settlement']:
  if s['window']=='KXBTC15M-26OCT150130-30':excluded.append(s['window']);continue
  assert s['window'] not in settled;settled[s['window']]=s
 expected=[x['ticker'] for x in json.loads((P.parent/'audit.json').read_text())['windows']]
 missing=[];rows=[];joined=[];outside=[]
 for f in fills.values():
  if f['window'] not in expected:outside.append(f);continue
  i=intents.get(f['client_order_id']);a=acks.get(f['client_order_id']);problems=[]
  if i is None:problems.append('missing durable intent')
  elif any(i[k]!=f[k] for k in ['window','side']):problems.append('intent mismatch')
  if a is None:problems.append('missing accepted order')
  elif a['order_id']!=f['order_id']:problems.append('ack order_id mismatch')
  entry={'fill':f,'intent':i,'ack':a,'problems':problems};joined.append(entry)
  if problems:missing.append(entry)
 for t in expected:
  fs=[f for f in fills.values() if f['window']==t];s=settled.get(t)
  holdings={side:{'shares':sum((f['size'] for f in fs if f['side']==side),D(0)),'cost':sum((f['size']*f['price'] for f in fs if f['side']==side),D(0)),'fees':sum((f['fee_usd'] for f in fs if f['side']==side),D(0))} for side in ['up','down']}
  up,down=holdings['up'],holdings['down'];cost=up['cost']+down['cost'];fees=up['fees']+down['fees'];pairs=min(up['shares'],down['shares']);locked=pairs*(1-(up['cost']+up['fees'])/up['shares']-(down['cost']+down['fees'])/down['shares']) if pairs else D(0)
  result={'ticker':t,'fill_count':len(fs),'holdings':holdings,'cost':cost,'fees':fees,'pairs':pairs,'leftover_shares':abs(up['shares']-down['shares']),'both_sides':bool(up['shares'] and down['shares']),'maker_fills':sum(f['is_taker'] is False for f in fs),'taker_fills':sum(f['is_taker'] is True for f in fs),'lock_fills':sum(intents.get(f['client_order_id'],{}).get('kind')=='lock' for f in fs),'intents':sum(i['window']==t for i in intents.values()),'acks':sum(a['window']==t for a in acks.values()),'settlement':s,'status':'unknown absent settlement' if s is None else 'reconciled'}
  if s:
   payout=up['shares'] if s['up_wins'] else down['shares'];pnl=payout-cost-fees
   checks={'up_shares':up['shares'],'down_shares':down['shares'],'cost_usd':cost,'fee_usd':fees,'payout_usd':payout,'pnl_usd':pnl,'locked_usd':locked,'direction_usd':pnl-locked}
   result['recomputed']=checks;result['mismatches']={k:{'computed':v,'reported':s[k]} for k,v in checks.items() if abs(v-s[k])>D('.0000001')}
   assert not result['mismatches'],(t,result['mismatches'])
   maker_cost=maker_fees=maker_payout=lock_cost=lock_fees=lock_payout=D(0)
   for f in fs:
    leg_payout=f['size'] if (f['side']=='up')==s['up_wins'] else D(0)
    if intents[f['client_order_id']]['kind']=='lock':
     lock_cost+=f['size']*f['price'];lock_fees+=f['fee_usd'];lock_payout+=leg_payout
    else:
     maker_cost+=f['size']*f['price'];maker_fees+=f['fee_usd'];maker_payout+=leg_payout
   result['static_leg_decomposition']={'maker_recorded_inventory_payout':maker_payout,'maker_cost':maker_cost,'maker_fees':maker_fees,'maker_conditional_pnl':maker_payout-maker_cost-maker_fees,'actual_lock_payout':lock_payout,'actual_lock_cost':lock_cost,'actual_lock_fees':lock_fees,'actual_lock_signed_contribution':lock_payout-lock_cost-lock_fees}
   assert abs(result['static_leg_decomposition']['maker_conditional_pnl']+result['static_leg_decomposition']['actual_lock_signed_contribution']-pnl)<D('.0000001')
  rows.append(result)
 rejected={r.get('client_order_id') for r in events['speeddesk_live_reject']}
 cohort_intents={cid:i for cid,i in intents.items() if i['window'] in expected}
 cohort_acks={cid:a for cid,a in acks.items() if a['window'] in expected}
 cohort_not_sent={cid:a for cid,a in not_sent.items() if a['window'] in expected}
 roles={str(role):{'count':sum(j['fill']['is_taker']==role for j in joined),'cost':sum((j['fill']['size']*j['fill']['price'] for j in joined if j['fill']['is_taker']==role),D(0)),'fees':sum((j['fill']['fee_usd'] for j in joined if j['fill']['is_taker']==role),D(0))} for role in [False,True]}
 result={'queries':queries,'population':{k:len(v) for k,v in events.items()},'intents':len(intents),'acks':len(acks),'not_sent':len(not_sent),'cohort_intents':len(cohort_intents),'cohort_acks':len(cohort_acks),'cohort_not_sent':len(cohort_not_sent),'cohort_rejected':sum(cid in rejected for cid in cohort_intents),'unexplained_intents':[i for cid,i in intents.items() if cid not in acks and cid not in not_sent and cid not in rejected],'join_errors':missing,'joined_fills':len(joined),'roles_is_taker':roles,'outside_cohort_fills':outside,'excluded_settlements':excluded,'windows':rows,'joined':joined,'rejects':events['speeddesk_live_reject'],'sampled_cancels':events['speeddesk_live_cancel']}
 dump(P/'audit.json',result)
 print(json.dumps({k:v for k,v in result.items() if k not in ['queries','windows','joined','sampled_cancels','outside_cohort_fills']},default=str,indent=2))
main()
