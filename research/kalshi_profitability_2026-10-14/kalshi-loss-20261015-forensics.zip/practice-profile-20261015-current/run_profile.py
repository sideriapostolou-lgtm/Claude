"""Offline current-source method profiling; no runtime factories or production state."""
import asyncio  # initialize before denying socket creation
import socket,threading,dataclasses,json,time,statistics,cProfile,pstats,hashlib,tempfile,sys,copy
from pathlib import Path
ROOT=Path('/workspace/nightcrawler-mirror-speed')
sys.path.insert(0,str(ROOT/'src'))
from nightcrawler import speeddesk as sd,speeddesk_model as model
from nightcrawler.clock import FakeClock
from nightcrawler.speeddesk_metrics import WindowEvidence,LatencyMetrics
from nightcrawler.speeddesk_worktrace import WorkTrace
from nightcrawler.ledger import Ledger

def denied(*a,**kw): raise RuntimeError('offline: network/thread denied')
socket.socket=denied
socket.create_connection=denied
threading.Thread.start=denied
OUT=Path(__file__).parent
original=dataclasses.asdict
fields={cls:tuple(f.name for f in dataclasses.fields(cls)) for cls in (model.Window,model.Settlement,model.PracticeOrder,model.Holding)}
scalar_types=(int,float,str,bool,type(None))
def fast(value):
    names=fields.get(type(value))
    if names is not None:
        result={name:getattr(value,name) for name in names}
        if all(type(v) in scalar_types for v in result.values()): return result
    return original(value)

def digest(v):return hashlib.sha256(json.dumps(v,allow_nan=False,separators=(',',':'),sort_keys=True).encode()).hexdigest()
source=json.loads(Path('/workspace/shared/practice-report-density-profile.json').read_text())
fixture=source['stages']['practice_fills_prior_days_latency_4096']['fixture']
now=fixture['now']
r=object.__new__(sd.SpeedRunner)
r.clock=FakeClock(now);r.work_trace=WorkTrace();r.desk=model.PracticeDesk.from_state(copy.deepcopy(fixture['practice']))
r.started_at=fixture['started_at'];r.reports={};r.observed={};r.feed_latency={};r.venue_coverage={};r.venue_reporting_started_at=r.started_at
r.metrics=LatencyMetrics(now,copy.deepcopy(fixture['metrics']));r.evidence=WindowEvidence(now,copy.deepcopy(fixture['practice_evidence']))
r.enabled_venues={'kalshi','polymarket_us'};r.feed_status={'trade_stream':True};r.problem=None;r.live=None;r.live_problem=None;r.last_live_panel={};r.pending=[];r.opening_logged=set();r._first_save_synced=False
methods={'summary':lambda:r.summary(model.utc_day(now)),'daily_reports':lambda:r.daily_reports(now),'panel':lambda:r.panel(now),'to_state':r.desk.to_state,'checkpoint':lambda:r.checkpoint(now)}
with tempfile.TemporaryDirectory(dir=OUT) as folder:
    r.path=Path(folder)/'state.json';r.ledger=Ledger(Path(folder)/'receipts.db',r.clock);r.ledger.set_synchronous(False)
    r.checkpoint(now)
    runs=[];profiles={};outputs={}
    for rep in range(8):
        # ABBA-style repeated alternation, output fingerprints outside timings.
        modes=('old','fast') if rep%2==0 else ('fast','old')
        for mode in modes:
            sd.asdict=model.asdict=original if mode=='old' else fast
            for name,fn in methods.items():
                wall=time.perf_counter_ns();cpu=time.thread_time_ns();value=fn()
                row={'rep':rep,'mode':mode,'method':name,'wall_ms':(time.perf_counter_ns()-wall)/1e6,'cpu_ms':(time.thread_time_ns()-cpu)/1e6}
                if name=='checkpoint': value=r.ledger.get_kv(sd.STATE_KEY)
                elif name=='daily_reports': value={'reports':r.reports,'pending':r.pending}
                outputs.setdefault(name,{})[mode]=digest(value)
                runs.append(row)
    for mode in ('old','fast'):
        sd.asdict=model.asdict=original if mode=='old' else fast
        for name,fn in methods.items():
            p=cProfile.Profile();p.enable();fn();p.disable()
            profiles[mode+'_'+name]=sorted([{'file':k[0],'line':k[1],'function':k[2],'calls':v[1],'self_ms':v[2]*1000,'cumulative_ms':v[3]*1000} for k,v in pstats.Stats(p).stats.items()],key=lambda row:row['cumulative_ms'],reverse=True)[:25]
    r.ledger.close()
sd.asdict=model.asdict=original
assert all(v['old']==v['fast'] for v in outputs.values()),outputs
# Independent value/failure contracts for generic fast-path proposal.
@dataclasses.dataclass
class ExtendedWindow(model.Window): extra:list=dataclasses.field(default_factory=lambda:[1])
class TrickyFloat(float):
    def __deepcopy__(self,memo): raise ValueError('deepcopy contract')
cases=[]
w=model.Window('hand',1,2);w.start_price=[{'mut':[]}]
for label,value in [('window_mutable',w),('subclass',ExtendedWindow('extra',1,2)),('bad_float',model.Window('bad',TrickyFloat(1),2)),('not_dataclass',object())]:
    results=[]
    for fn in (original,fast):
        try:
            got=fn(value);results.append(('ok',got))
            if label=='window_mutable':
                assert got['start_price'] is not value.start_price
                assert got['start_price'][0]['mut'] is not value.start_price[0]['mut']
            if label=='subclass': assert got['extra'] is not value.extra
        except Exception as exc:results.append((type(exc).__name__,str(exc)))
    assert results[0]==results[1],(label,results)
    cases.append({'case':label,'result':str(results[0])})
result={'fixture_origin':'Existing preserved synthetic density fixture, not production runtime state','fixture_sha256':digest(fixture),'source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'src/nightcrawler/speeddesk.py',ROOT/'src/nightcrawler/speeddesk_model.py')},'counts':{'windows':len(r.desk.windows),'closed':len(r.desk.closed),'reports':len(r.reports)},'runs':runs,'profiles':profiles,'output_hashes':outputs,'contracts':cases,'medians':{mode:{name:{field:statistics.median(row[field] for row in runs if row['mode']==mode and row['method']==name) for field in ('wall_ms','cpu_ms')} for name in methods} for mode in ('old','fast')},'limitations':['Invented 200 historical windows and 400 fills; not a production replay or causal estimate.','No real companion; live_panel returns existing unavailable status. Production panel includes separately expensive real companion work.','Fixture restore cancels pending orders according to actual PracticeDesk.from_state; no active orders here.','Fast path is monkeypatched at module asdict names as a bounded prototype; proposed production call sites need narrower scope.','Existing historical reports warmed before timing, all day rechecks retained. Actual local SQLite commit/JSON mirror methods; no change to durability.','Eight alternating repetitions, same process, no confidence intervals; cProfile overhead excluded from unprofiled timing.']}
(OUT/'result.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps(result['medians'],indent=2));print('contracts',cases)
print('old daily profile',profiles['old_daily_reports'][:12])
