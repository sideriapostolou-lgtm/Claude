"""Bounded offline quiet callback density profile; no production state or client."""
from __future__ import annotations

import cProfile
import dataclasses
import hashlib
import json
import logging
import pstats
import socket
import statistics
import subprocess
import tempfile
import threading
import time
from pathlib import Path

ROOT = Path('/workspace/nightcrawler-mirror-speed')
OUT = Path('/workspace/shared/practice-profile-20261015-current/position-result.json')

def denied(*args, **kwargs):
    raise RuntimeError('offline diagnostic denies socket/client/thread use')

# Before imports/fixture: prohibit all socket allocation, network and worker threads.
class DeniedSocket(socket.socket):
    def __init__(self, *args, **kwargs):
        denied(*args, **kwargs)

socket.socket = DeniedSocket
socket.create_connection = denied
threading.Thread.start = denied

from test_kalshi_arena_feed import LocalFeeds

from nightcrawler.clock import FakeClock
from nightcrawler.config import Settings
from nightcrawler.speeddesk import SpeedRunner
from nightcrawler.speeddesk_live import Intent, KalshiLiveDesk
from nightcrawler.speeddesk_live_model import ActualFill, LiveIntent
from nightcrawler.speeddesk_model import BitcoinTape, PracticeOrder, Window, utc_day
from datetime import UTC, datetime
from nightcrawler.speeddesk_metrics import LatencyMetrics

logging.disable(logging.CRITICAL)
SLUG = 'KXBTC15M-QUIET-CURRENT'
T0 = 1792016160.0

class Feeds(LocalFeeds):
    def maker_windows(self):
        return {SLUG}


def native(value):
    if dataclasses.is_dataclass(value):
        return native(dataclasses.asdict(value))
    if isinstance(value, dict):
        return {str(key): native(val) for key, val in value.items()}
    if isinstance(value, (list, tuple)):
        return [native(val) for val in value]
    return value


def digest(value):
    return hashlib.sha256(json.dumps(native(value), sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def main():
    results=[]
    with tempfile.TemporaryDirectory(prefix='panel-profile-',dir='/workspace/shared') as directory:
        clock=FakeClock(T0)
        def live_factory(settings,path,snapshot,**kwargs):
            return KalshiLiveDesk(settings,path,snapshot,client_factory=denied,**kwargs)
        runner=SpeedRunner(Settings(data_dir=Path(directory),speeddesk_kalshi_enabled=True,
            speeddesk_kalshi_mode='paper',speeddesk_kalshi_live_confirm=None,
            kalshi_key_id=None,kalshi_private_key=None,kalshi_arena_enabled=False),
            threading.Event(),clock=clock,feed_factory=Feeds,live_factory=live_factory)
        try:
            live=runner.live
            assert live is not None and live.client is None
            fills=[]
            for i in range(200):
                begin=T0-(201-i)*900
                w=Window(f'KXBTC15M-PANEL-{i:04}',begin,begin+900,80000,
                    venue='kalshi',venue_start_price=80000,taker_coefficient=.07,
                    maker_coefficient=0,fee_rounding='kalshi')
                for model in (runner.desk,live.twin,live.book):
                    model.add_window(dataclasses.replace(w))
                for j,side in enumerate(('up','down')):
                    k=i*2+j; key=f'nc-speed-panel-{k}'; at=begin+30+j
                    price=.4 if side=='up' else .5
                    live.book.intents[key]=LiveIntent(key,w.slug,side,'rest',price,1,at-1,price,
                        order_id=f'o{k}')
                    live.intents[key]=Intent(key,w.slug,side,'rest',price,1,.5,at-1,
                        order_id=f'o{k}',terminal=True)
                    fill=ActualFill(f'f{k}',f'o{k}',key,w.slug,side,price,1,0,at,is_taker=False)
                    assert live.book.record_fill(fill)
                    fills.append(dataclasses.asdict(fill))
                    for model in (runner.desk,live.twin):
                        order=PracticeOrder(k+1,w.slug,side,'rest',price,1,1,at-1,at-1,.5,0,0,'fixture',
                            fee_rounding='kalshi',min_trade_qty=.01)
                        model.orders[k+1]=order
                        model._fill(order,1,at)
                        model.next_order_id=k+2
                runner.desk.settle(w.slug,True,w.end+1)
                live.twin.settle(w.slug,True,w.end+1)
                live.book.settle(w.slug,True,w.end+1,f's{i}')
                live.position_sizes[w.slug]=0
            for k in range(400,3350):
                spec=runner.desk.windows[f'KXBTC15M-PANEL-{k%200:04}']
                key=f'nc-speed-panel-{k}'; at=spec.start+10
                live.book.intents[key]=LiveIntent(key,spec.slug,'up','rest',.4,1,at,.4,
                    order_id=f'o{k}',status='canceled',reservation_active=False)
                live.intents[key]=Intent(key,spec.slug,'up','rest',.4,1,.5,at,
                    order_id=f'o{k}',terminal=True)
            runner.on_windows([Window(SLUG,T0-60,T0+840,80000,venue='kalshi',
                venue_start_price=80000,taker_coefficient=.07,maker_coefficient=0,fee_rounding='kalshi')])
            runner.on_tick(80000,T0,T0)
            runner.on_status({'coinbase':'connected','trade_stream':True,'markets':'connected'})
            runner.checkpoint(T0)
            # This is invented offline density, never captured production state.
            assert not OUT.exists(), 'preserve previously closed artifact'
            runner.desk.tape=BitcoinTape()
            for second in range(int(T0)-3700,int(T0)+1):
                runner.desk.tape.tick(80000+(second%17)*.01,float(second))
            import inspect,textwrap
            from position_helper import position_count
            original=KalshiLiveDesk.panel
            source=textwrap.dedent(inspect.getsource(inspect.unwrap(original)))
            source=source[source.index('def panel'):]
            oldexpr='sum(abs(value) > EPS for key, value in self.position_sizes.items()\n                 if key in {intent.window for intent in self.intents.values()})'
            import re
            source,n=re.subn(r'sum\(abs\(value\) > EPS for key, value in self.position_sizes.items\(\)\s+if key in \{intent.window for intent in self.intents.values\(\)\}\)', 'position_count(self.position_sizes, self.intents)',source)
            assert n==1
            namespace=dict(inspect.unwrap(original).__globals__);namespace['position_count']=position_count
            exec(compile(source,'<offline-panel-position-prototype>','exec'),namespace)
            from nightcrawler.speeddesk_worktrace import observed
            improved=observed('live_panel')(namespace['panel'])
            rows=[];profiles={};hashes={}
            # Four actual fill/settle APIs above; synthetic history density retained.
            for count in (0,1,5,20,200):
                live.position_sizes={slug:(1 if i==0 else 0) for i,slug in enumerate(list(live.book.windows)[:count])}
                for rep in range(10):
                    for mode in (('old','grouped') if rep%2==0 else ('grouped','old')):
                        KalshiLiveDesk.panel=original if mode=='old' else improved
                        wall,cpu=time.perf_counter_ns(),time.thread_time_ns();value=runner.panel(T0)
                        rows.append({'positions_returned':count,'rep':rep,'mode':mode,'wall_ms':(time.perf_counter_ns()-wall)/1e6,'cpu_ms':(time.thread_time_ns()-cpu)/1e6})
                        hashes.setdefault(str(count),{})[mode]=digest(value)
                for mode in ('old','grouped'):
                    KalshiLiveDesk.panel=original if mode=='old' else improved
                    prof=cProfile.Profile();prof.enable();runner.panel(T0);prof.disable()
                    profiles[str(count)+'_'+mode]=sorted([{'file':k[0],'line':k[1],'function':k[2],'calls':v[1],'self_ms':v[2]*1000,'cumulative_ms':v[3]*1000} for k,v in pstats.Stats(prof).stats.items()],key=lambda row:row['cumulative_ms'],reverse=True)[:30]
            KalshiLiveDesk.panel=original
            assert all(v['old']==v['grouped'] for v in hashes.values())
            output={'source':'current exact panel body with ONLY position expression changed in memory','rows':rows,'profiles':profiles,'hashes':hashes,'fixture_counts':{'historical_windows':200,'fills':400,'intents':3350},'medians':{str(count):{mode:{field:statistics.median(row[field] for row in rows if row['positions_returned']==count and row['mode']==mode) for field in ('wall_ms','cpu_ms')} for mode in ('old','grouped')} for count in (0,1,5,20,200)},'limitations':['Synthetic paired zero-fee fills and manually seeded terminal intents; not actual production histories.','Real client filters unsettled positions; counts above 1 are sensitivity scenarios, not observed production map lengths.','Actual full practice and companion panel/twin/scorecard/risk/ladder/markout-status calls preserved, paper gates, denied sockets/client/thread creation.','No market books or pending markout quotes. Markout status is constant-time counter copying.','Ten alternating measurements per count; same process; no production causal/performance claim.','Prototype exact-native type guards require adversarial review; no persistent cache, no clock/recheck call removed.']}
            OUT.write_text(json.dumps(output,indent=2,allow_nan=False)+'\n')
            print(json.dumps(output['medians'],indent=2))
        finally:
            runner.close()

if __name__=='__main__':
    main()
