from nightcrawler.speeddesk_live import Intent,EPS

def position_count(positions,intents):
    # Prototype: original evaluation location and fallback; no state retained.
    if type(positions) is dict and positions and type(intents) is dict:
        if (all(type(key) is str and type(value) in (int,float,bool) for key,value in positions.items())
            and all(type(intent) is Intent and type(intent.window) is str for intent in intents.values())):
            windows={intent.window for intent in intents.values()}
            return sum(abs(value)>EPS for key,value in positions.items() if key in windows)
    return sum(abs(value)>EPS for key,value in positions.items()
               if key in {intent.window for intent in intents.values()})
