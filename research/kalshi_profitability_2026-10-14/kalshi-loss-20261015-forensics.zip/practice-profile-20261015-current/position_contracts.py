import sys
sys.path.insert(0,'/workspace/nightcrawler-mirror-speed/src')
from position_helper import position_count
from nightcrawler.speeddesk_live import Intent,EPS
from dataclasses import replace
from collections import UserDict

def intent(key,window):return Intent(key,window,'up','rest',.4,1,.5,1)
def original(positions,intents):
    return sum(abs(value)>EPS for key,value in positions.items() if key in {i.window for i in intents.values()})
def outcome(fn,p,i):
    try:return ('ok',fn(p,i))
    except Exception as e:return (type(e).__name__,str(e))
i={'a':intent('a','a'),'b':intent('b','b')}
p={'a':2,'b':-3,'foreign':50,'flat':0}
assert position_count(p,i)==2
p['a']=0; assert position_count(p,i)==1
p['a']=float('nan'); assert position_count(p,i)==1
p['a']=float('inf'); assert position_count(p,i)==2
i['a'].window='foreign';assert position_count(p,i)==2
p['foreign']=0;assert position_count(p,i)==1
i.pop('b');assert position_count(p,i)==0
class NoValues(dict):
    def values(self):raise AssertionError('must stay lazy')
assert position_count({},NoValues())==0
class StrangeFloat(float):
    def __abs__(self):raise RuntimeError('abs failure')
cases=[({'a':1},{'a':intent('a',[])}),({'a':StrangeFloat(1)},{'a':intent('a','a')}),
       (UserDict({'a':1}),i),({'a':1},UserDict(i)),({'a':1},{'a':object()}),
       ({'a':1},{'x':intent('x','foreign')}),({},NoValues())]
for p,i in cases:
    assert outcome(original,p,i)==outcome(position_count,p,i),(p,i)
print('7 bounded failure/lazy cases plus 8 independent count/mutation assertions passed')
