"""Run final regression cases against the untouched base method, in memory only."""
import ast
import subprocess
import sys
import pytest
sys.path.insert(0, '/workspace/nightcrawler-cancel-freshness/src')
from nightcrawler import speeddesk_live
source = subprocess.check_output(['git', 'show', '3c757ba369a0f2b5ca010f617d39c61eea3e5a66:src/nightcrawler/speeddesk_live.py'], text=True)
cls = next(node for node in ast.parse(source).body if isinstance(node, ast.ClassDef) and node.name == 'KalshiLiveDesk')
method = next(node for node in cls.body if isinstance(node, ast.AsyncFunctionDef) and node.name == '_cancel_unsafe')
namespace = dict(vars(speeddesk_live))
exec(compile(ast.Module(body=[method], type_ignores=[]), '<untouched-base-cancel-unsafe>', 'exec'), namespace)
speeddesk_live.KalshiLiveDesk._cancel_unsafe = namespace['_cancel_unsafe']
raise SystemExit(pytest.main(['-q', 'tests/test_speeddesk_cancel_freshness.py', '-k',
                             'remaining and not no_cancel and not unchanged and not shutdown']))
